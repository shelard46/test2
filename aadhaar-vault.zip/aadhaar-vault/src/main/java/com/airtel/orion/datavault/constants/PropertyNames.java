package com.airtel.orion.datavault.constants;

public interface PropertyNames {

	String HSM_PASSWORD = "hsm.password";
	String KEY_ALIAS_NAME = "key.alias.name";
	String VALIDATE_UID_CHECK_DIGIT = "validate.uid.check.digit";
	String HSM_HA_SLOT_LABEL = "hsm.ha.slot.label";
	String MAX_HSM_LOGIN_FAILURE_ATTEMPTS = "max.hsm.login.failure.attempts";

}
