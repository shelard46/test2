package com.airtel.orion.datavault.dto;

import java.io.Serializable;

public class ApplicationKeyTO implements Serializable{

	private static final long serialVersionUID = 1554317371215037089L;
	
	private String name;
	
	private String key;

	public String getName() {
		return name;
	}

	public void setName(String appName) {
		this.name = appName;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String appKey) {
		this.key = appKey;
	}
	
}
