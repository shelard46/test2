package com.airtel.orion.datavault.utils;

import java.util.Map;

public class ConfigMasterUtil {

	private static Map<String, String> configValues;


	public static Map<String, String> getConfigValues() {
		return configValues;
	}

	public static void setConfigValues(Map<String, String> configValues) {
		ConfigMasterUtil.configValues = configValues;
	}


	public static String getConfigValue(String key) {
		return configValues.get(key);
	}
	
	public static void addConfigValue(String key, String value){
		configValues.put(key, value);
	}
	
}
