package com.airtel.orion.datavault.dao.impl;

import com.airtel.orion.datavault.dao.ConfigMasterDAO;
import com.airtel.orion.datavault.dto.ConfigValueTO;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ConfigMasterDAOImpl implements ConfigMasterDAO {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigMasterDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String getConfigValue(String keyName) {
		try {
			LOGGER.debug("getting value for key : {} from database", keyName);
			String configQuery = "SELECT key FROM config_master WHERE name = ?";
			String value = jdbcTemplate.queryForObject(configQuery, new Object[] { keyName },
					String.class);
			if (!StringUtils.isEmpty(value)) {
				LOGGER.debug("value : {} against keyName : {} fetched from database", value,
						keyName);
				return value;
			}
			return null;
		} catch (Exception e) {
			LOGGER.error(" Exception occurred while fetching value from config master for key : {}",
					keyName, e);
		}
		return null;
	}

	@Override
	public List<ConfigValueTO> getConfigValues() {
		try {
			LOGGER.debug("getting config values from database");
			String configQuery = "SELECT * FROM config_master";
			List<ConfigValueTO> configValues = jdbcTemplate.query(configQuery,
					new BeanPropertyRowMapper<ConfigValueTO>(ConfigValueTO.class));
			return configValues;
		} catch (Exception e) {
			LOGGER.error("exception occurred while fetching values from database :",
					 e);
		}
		return null;
	}
	
}
