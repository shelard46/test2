package com.airtel.orion.datavault.request;

import com.airtel.orion.datavault.utils.ReferenceMaskUtil;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;

public class AadhaarNumberRequest implements Serializable {
	
	private static final long serialVersionUID = 1387041021042015327L;

	private String referenceKey;

	private String apiKey;

	private String requestId;

	public String getReferenceKey() {
		return referenceKey;
	}

	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("referenceKey", ReferenceMaskUtil.maskPlainReferenceKeyForLog(referenceKey)).append("apiKey", apiKey)
				.append("requestId", requestId).toString();
	}

}
