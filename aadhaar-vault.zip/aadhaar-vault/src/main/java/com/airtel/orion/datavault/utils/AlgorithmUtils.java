package com.airtel.orion.datavault.utils;

import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;

/**
 * @author Mithil
 *
 */

public final class AlgorithmUtils {
	
	 private static final int[][] D_TABLE = new int[][] { 
	        {0,  1,  2,  3,  4,  5,  6,  7,  8,  9}, 
	        {1,  2,  3,  4,  0,  6,  7,  8,  9,  5}, 
	        {2,  3,  4,  0,  1,  7,  8,  9,  5,  6}, 
	        {3,  4,  0,  1,  2,  8,  9,  5,  6,  7}, 
	        {4,  0,  1,  2,  3,  9,  5,  6,  7,  8}, 
	        {5,  9,  8,  7,  6,  0,  4,  3,  2,  1}, 
	        {6,  5,  9,  8,  7,  1,  0,  4,  3,  2}, 
	        {7,  6,  5,  9,  8,  2,  1,  0,  4,  3}, 
	        {8,  7,  6,  5,  9,  3,  2,  1,  0,  4}, 
	        {9,  8,  7,  6,  5,  4,  3,  2,  1,  0}}; 
	 
	    /** P - permutation table */ 
	    private static final int[][] P_TABLE = new int[][] { 
	        {0,  1,  2,  3,  4,  5,  6,  7,  8,  9}, 
	        {1,  5,  7,  6,  2,  8,  3,  0,  9,  4}, 
	        {5,  8,  0,  3,  7,  9,  6,  1,  4,  2}, 
	        {8,  9,  1,  6,  0,  4,  3,  5,  2,  7}, 
	        {9,  4,  5,  3,  1,  2,  6,  8,  7,  0}, 
	        {4,  2,  8,  6,  5,  7,  3,  9,  0,  1}, 
	        {2,  7,  9,  3,  8,  0,  6,  4,  1,  5}, 
	        {7,  0,  4,  6,  9,  1,  3,  2,  5,  8}}; 
	 
	    /** inv: inverse table */ 
	    private static final int[] INV_TABLE = new int[] 
	        {0,  4,  3,  2,  1,  5,  6,  7,  8,  9}; 

	/**
	 * Generates the check digit using the Luhn's Algorithm
	 * 
	 * @param number
	 * @return the check digit
	 */
	public static  String getLuhnCheckDigit(final String number) {
		if (number == null)
			return null;
		String digit;
		/* convert to array of int */
		int[] digits = new int[number.length()];
		for (int i = 0; i < number.length(); i++) {
			digits[i] = Character.getNumericValue(number.charAt(i));
		}

		/* double every other starting from right - jumping from 2 in 2 */
		for (int i = digits.length - 1; i >= 0; i -= 2) {
			digits[i] += digits[i];

			/*
			 * taking the sum of digits greater than 10
			 */
			if (digits[i] >= 10) {
				digits[i] = digits[i] - 9;
			}
		}

		int sum = 0;
		for (int i = 0; i < digits.length; i++) {
			sum += digits[i];
		}
		/* multiply by 9 step */
		sum = sum * 9;

		/* convert to string to be easier to take the last digit */
		digit = sum + "";
		return digit.substring(digit.length() - 1);
	}

    /**
     * Calculate the checksum. 
     * 
     * @param code The code to calculate the checksum for. 
     * @param includesCheckDigit Whether the code includes the Check Digit or not. 
     * @return The checksum value 
     */ 
	public static String getVerhoeffCheckDigit(final String code) {
		int checksum = 0; 
        for (int i = 0; i < code.length(); i++) { 
            int idx = code.length() - (i + 1); 
            int num = Character.getNumericValue(code.charAt(idx));
			int pos = i + 1;
            checksum = D_TABLE[checksum][P_TABLE[pos % 8][num]]; 
        }
		return Integer.toString(INV_TABLE[checksum]); 
	}

	
	/**Calculates the unique number using the Cantor function
	 * @param k1
	 * @param k2
	 * @return unique number
	 */
	public static long generateCantorUniqueNumber(final long k1, final long k2) {
		if (k1 < 0 || k2 < 0) {
			throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_REF_KEY_GENERATED, "Invalid Cantor numbers generated ");
		}
		long n1 = k1 + k2;
		long n2 = k1 + k2 + 1;
		long k = ((n1 * n2) >> 1) + k2;
		return k ;
	}
	
}
