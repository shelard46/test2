package com.airtel.orion.datavault.listener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.airtel.orion.datavault.constants.PropertyNames;
import com.airtel.orion.datavault.dao.ConfigMasterDAO;
import com.airtel.orion.datavault.dto.ConfigValueTO;
import com.airtel.orion.datavault.utils.ConfigMasterUtil;

@Component("configLoader")
public class ConfigMasterLoader implements InitializingBean {

	public final Logger LOGGER = LoggerFactory.getLogger(ConfigMasterLoader.class);

	@Autowired
	ConfigMasterDAO configMasterDao;

	@Autowired
	Environment environment;

	@Override
	public void afterPropertiesSet() throws Exception {
		LOGGER.info("Reading properties from database");
		try {
			Map<String, String> configValueMap = new HashMap<>();
			List<ConfigValueTO> configValues = configMasterDao.getConfigValues();
			for (ConfigValueTO configValueTO : configValues) {
				configValueMap.put(configValueTO.getKey(), configValueTO.getValue());
			}
			ConfigMasterUtil.setConfigValues(configValueMap);
			addProperties();
		} catch (Exception e) {
			LOGGER.error("Error while loading config values in memory", e);
		}
	}

	private void addProperties() {
		String slotLabelkey = PropertyNames.HSM_HA_SLOT_LABEL;
		String slotLabelvalue = environment.getProperty(slotLabelkey);
		String key = PropertyNames.MAX_HSM_LOGIN_FAILURE_ATTEMPTS;
		String value = environment.getProperty(key);
		ConfigMasterUtil.addConfigValue(slotLabelkey, slotLabelvalue);
		ConfigMasterUtil.addConfigValue(key, value);
	}

}
