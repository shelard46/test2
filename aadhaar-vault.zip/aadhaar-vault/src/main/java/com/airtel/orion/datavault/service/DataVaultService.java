package com.airtel.orion.datavault.service;

import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.request.ReferenceKeyRequest;
import com.airtel.orion.datavault.response.ResponseDTO;

public interface DataVaultService {
	
	public String getAadhaarNumber(AadhaarNumberRequest request) throws DataVaultRuntimeException;
	
	public String getReferenceKey(ReferenceKeyRequest request) throws DataVaultRuntimeException;

	public ResponseDTO removeAadhaarByReferenceKey(AadhaarNumberRequest request);
	
}