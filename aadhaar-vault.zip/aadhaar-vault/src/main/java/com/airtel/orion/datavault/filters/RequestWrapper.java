package com.airtel.orion.datavault.filters;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.naming.AuthenticationException;
import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RequestWrapper extends HttpServletRequestWrapper {

	private final String payload;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestWrapper.class);

	public RequestWrapper(HttpServletRequest request) throws AuthenticationException {
		super(request);
		StringBuilder stringBuilder = new StringBuilder();
		try {
			InputStream inputStream = request.getInputStream();
			if (inputStream != null) {
				StringWriter stringWriter = new StringWriter();
				IOUtils.copy(inputStream, stringWriter, "UTF-8");
				stringBuilder.append(stringWriter.toString());
			} else {
				stringBuilder.append("");
			}
		} catch (IOException ex) {
			LOGGER.error("I/O Error on wrapping request ", ex.getMessage(), ex);
			throw new AuthenticationException("Error reading the request payload");
		}
		payload = stringBuilder.toString();
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(payload.getBytes());
		ServletInputStream inputStream = new ServletInputStream() {
			public int read() throws IOException {
				return byteArrayInputStream.read();
			}

			@Override
			public boolean isFinished() {
				return false;
			}

			@Override
			public boolean isReady() {
				return false;
			}

			@Override
			public void setReadListener(ReadListener listener) {
			}
		};
		return inputStream;
	}

	public String getPayload() {
		return payload;
	}

}
