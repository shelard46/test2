package com.airtel.orion.datavault.request;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.airtel.orion.datavault.utils.AadhaarMaskUtil;

public class ReferenceKeyRequest implements Serializable {
	
	private static final long serialVersionUID = 1387041021042015327L;

	private String uid;

	private String apiKey;

	private String requestId;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	@Override
	public String toString() {
		return new ToStringBuilder(this).append("uid", AadhaarMaskUtil.maskAadhaarForLog(uid)).append("apiKey", apiKey)
				.append("requestId", requestId).toString();
	}


}
