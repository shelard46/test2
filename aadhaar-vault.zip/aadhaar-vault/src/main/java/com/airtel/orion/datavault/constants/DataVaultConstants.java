package com.airtel.orion.datavault.constants;

import java.util.regex.Pattern;

public interface DataVaultConstants {
	
	public Pattern DIGIT_PATTERN = Pattern.compile("\\d*");
	public int AADHAAR_NUMBER_LENGTH = 12;
	public int REFERENCE_KEY_LENGTH = 12;
	public String PASS_PHRASE = "s2D3R4ty29O";
	public String SIGNATURE_HEADER = "Message_Signature";
	public int STATUS_CODE = 403;
	public String HSM_USERNAME="test";
	String HSM_PASSWORD="test";
	String HSM_SLOT="slot1";
	String KEY_ALIAS="datavault_key";

	public int REQUEST_PASS = 0;
	public int REQUEST_FAIL = 1;
	
}
