package com.airtel.orion.datavault.utils;

import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import com.safenetinc.luna.LunaSlotManager;
import com.safenetinc.luna.provider.LunaProvider;
import com.safenetinc.luna.provider.key.LunaKey;

public class AESKeyInj {

	private static String KEY_ALIAS = null;
	private static String PASSWORD = null;
	private static KeyStore lunaks = null;

	private static final byte[] salt = { (byte) 0xA8, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34,
			(byte) 0xE3, (byte) 0x03 };

	private static final byte[] iv = { (byte) 0x76, (byte) 0x80, (byte) 0x6B, (byte) 0xE2, (byte) 0xFE, (byte) 0x2,
			(byte) 0x5D, (byte) 0xAF, (byte) 0xC, (byte) 0x9F, (byte) 0x4A, (byte) 0x9E, (byte) 0x5C, (byte) 0xAA,
			(byte) 0xDC, (byte) 0x20 };

//	public static void main(String[] args) {
//		try {
//			KEY_ALIAS = args[0];
//			PASSWORD = args[1];
//			System.out.println("Loading AES-256 Key in Luna KeyStore with Alias " + KEY_ALIAS);
//			Security.addProvider(new LunaProvider());
//			LunaSlotManager slotm = LunaSlotManager.getInstance();
//			slotm.login(PASSWORD);
//			slotm.setSecretKeysExtractable(true);
//			lunaks = KeyStore.getInstance("Luna");
//			lunaks.load(null, null);
//			setKey(KEY_ALIAS, false);
//			if (args.length > 2)
//				System.out.println("Encrypted String :" + encrypt(args[2]));
//			if (args.length > 3)
//				System.out.println("Decrypted String :" + decrypt(args[3]));
//			HSMLogout();
//
//		} catch (Exception e) {
//			System.err.println("Error Injecting Key in Luna Keystore");
//			e.printStackTrace(System.out);
//		}
//	}

	private static void deleteKey(String keyName) {
		try {
			lunaks.deleteEntry(keyName);
		} catch (Exception e) {
			System.err.println("Error Deleting Key from Luna Keystore");
			e.printStackTrace(System.out);
		}
	}

	private static void setKey(String keyAlias, boolean isAuto)
			throws KeyStoreException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeySpecException {
		boolean isKeyPresent = lunaks.containsAlias(keyAlias);
		System.out.println("Key Present :: " + isKeyPresent);
		System.out.println("Keystore has " + lunaks.size() + " objects");
		SecretKey aesKey = null;
		if (!isKeyPresent) {
			if (isAuto) {
				KeyGenerator keyGen = KeyGenerator.getInstance("AES", "LunaProvider");
				keyGen.init(256);
				aesKey = keyGen.generateKey();
				System.out.println("Key Generation is Auto");
			} else {
				KeySpec keySpec = new PBEKeySpec("s2D3R4ty29O".toCharArray(), salt, 30, 256);
				SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1","LunaProvider");
				byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
				aesKey = new SecretKeySpec(keyBytes, "AES");
				System.out.println("Key Generation is Not Auto");

			}
			lunaks.setKeyEntry(keyAlias, aesKey, null, null);
			LunaKey lkey2 = LunaKey.LocateKeyByAlias(keyAlias);
			lkey2.MakePersistent(keyAlias);
			System.out.println("Keystore now has " + lunaks.size() + " objects");
		}

	}

	private static Key getKey(String keyAlias, String password)
			throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException {
		SecretKey key = (SecretKey) lunaks.getKey(keyAlias, password.toCharArray());
		return key;
	}

	private static String encrypt(String str) throws Exception {
		try {
			Cipher ecipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			IvParameterSpec ivParams = new IvParameterSpec(iv);
			SecretKey key = (SecretKey) getKey(KEY_ALIAS, PASSWORD);
			ecipher.init(Cipher.ENCRYPT_MODE, key, ivParams);
			byte[] utf8 = str.getBytes("UTF8");
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception e) {
			throw e;
		}
	}

	public static String decrypt(String str) throws Exception {
		try {
			SecretKey key = (SecretKey) getKey(KEY_ALIAS, PASSWORD);
			IvParameterSpec ivParams = new IvParameterSpec(iv);
			Cipher dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, key, ivParams);
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, "UTF8");

		} catch (Exception e) {
			throw e;

		}
	}

	public static void HSMLogout() {
		Security.addProvider(new LunaProvider());
		LunaSlotManager slotm = LunaSlotManager.getInstance();
		slotm.logout();
		slotm.getLunaAPI().Finalize();
	}

}
