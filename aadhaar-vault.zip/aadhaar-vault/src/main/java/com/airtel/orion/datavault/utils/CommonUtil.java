package com.airtel.orion.datavault.utils;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.response.Meta;
import com.airtel.orion.datavault.response.ResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * @author Hitesh Khatri
 * @date 14/06/21
 */
public final class CommonUtil {

    public static Meta getMeta(ResponseErrorCode code, int status) {
        return Meta.builder().code(code.getStatusCode()).description(code.getMessage()).status(status).build();
    }

    public static ResponseEntity<ResponseDTO> getResponseEntityForRemoveAadhaar(ResponseErrorCode errorCode) {
        ResponseDTO responseDTO = new ResponseDTO(getMeta(errorCode, DataVaultConstants.REQUEST_FAIL), null);
        return new ResponseEntity<>(responseDTO, errorCode.getHttpStatus());
    }

}
