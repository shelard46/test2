
package com.airtel.orion.datavault.utils;

import org.apache.commons.lang.StringUtils;

/**
 * The Class AadhaarMaskUtil.
 *
 * @author Airtel Product Engineering Team
 */

public class AadhaarMaskUtil {

	/**
	 * Masks Aadhaar with format XXXXXXXX1234 by masking first 8 digits as X and
	 * displays last 4 as it is.
	 * 
	 * @param aadhaarNumber
	 *            aadhaarNumber to mask. If param is null masking would not be done.
	 * 
	 * @return masked aadhaar Number
	 */
	public static String maskAadhaarForLog(String aadhaarNumber) {

		String aadhaarRegex = "\\d(?=\\d{4})";
		String aadhaarRegexValue = "X";
		if (StringUtils.isNotEmpty(aadhaarNumber)) {
			return aadhaarNumber.replaceAll(aadhaarRegex, aadhaarRegexValue);
		}
		return aadhaarNumber;
	}
}