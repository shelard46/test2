package com.airtel.orion.datavault.adapter;

import java.security.Key;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

public interface IHSMAdapter {

	Key getKey() throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, Exception;

}
