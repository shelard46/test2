package com.airtel.orion.datavault.exceptions;

import com.airtel.orion.datavault.constants.ResponseErrorCode;

public class DataVaultRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 7570791736155203353L;

	private ResponseErrorCode errorCode;

	public DataVaultRuntimeException(ResponseErrorCode errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public DataVaultRuntimeException(ResponseErrorCode errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public DataVaultRuntimeException(ResponseErrorCode errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode;
	}

	public DataVaultRuntimeException(ResponseErrorCode errorCode, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
	}

	protected DataVaultRuntimeException(ResponseErrorCode errorCode, String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		this.errorCode = errorCode;
	}

	public ResponseErrorCode getErrorCode() {
		return errorCode;
	}
}
