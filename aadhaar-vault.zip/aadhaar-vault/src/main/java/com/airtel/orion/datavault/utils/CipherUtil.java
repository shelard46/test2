package com.airtel.orion.datavault.utils;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;

public final class CipherUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CipherUtil.class);

	private static final byte[] salt = { (byte) 0xA8, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34,
			(byte) 0xE3, (byte) 0x03 };

	public static String decryptData(final String str, String passPhrase) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}

		int iterationCount = 20;
		if (StringUtils.isEmpty(passPhrase)) {
			passPhrase = DataVaultConstants.PASS_PHRASE;
		}
		try {
			KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher dcipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, key);
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, "UTF8");
		} catch (Exception e) {
			LOGGER.error("Inside CipherUtil.decryptData : with error {}", e);
			throw new DataVaultRuntimeException(ResponseErrorCode.DECRYPTION_ERROR, e.getMessage());
		}

	}

	public static String encryptData(final String str, String passPhrase) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}
		if (StringUtils.isEmpty(passPhrase)) {
			passPhrase = DataVaultConstants.PASS_PHRASE;
		}
		int iterationCount = 20;
		try {
			KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher ecipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] utf8 = str.getBytes("UTF8");
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception e) {
			LOGGER.error("Inside CipherUtil.decryptData : with error {}", e);
			throw new DataVaultRuntimeException(ResponseErrorCode.ENCRYPTION_ERROR, e.getMessage());
		}
	}

//	public static void main(String[] args) {
//		System.out.println(salt.length);
//		System.out.println("Encrypted Data :: " + encryptData("722AXnOn+mbz", DataVaultConstants.PASS_PHRASE));
//		System.out.println("Decrypted Data :: " + decryptData("7U1KPliPWWu1Vh9m1eih5w==", DataVaultConstants.PASS_PHRASE));
//	}
}
