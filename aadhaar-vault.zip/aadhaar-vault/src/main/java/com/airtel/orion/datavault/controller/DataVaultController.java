package com.airtel.orion.datavault.controller;

import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.request.ReferenceKeyRequest;
import com.airtel.orion.datavault.response.AadhaarNumberResponse;
import com.airtel.orion.datavault.response.ReferenceKeyResponse;
import com.airtel.orion.datavault.response.ResponseDTO;
import com.airtel.orion.datavault.response.Result;
import com.airtel.orion.datavault.service.DataVaultService;
import com.airtel.orion.datavault.utils.CommonUtil;
import com.airtel.orion.datavault.utils.ResponseEntityBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/orion/uid/vault")
public class DataVaultController {

    @Autowired
    private DataVaultService vaultService;

    @Autowired
    private ResponseEntityBuilder responseEntityBuilder;

    private static final Logger LOGGER = LoggerFactory.getLogger(DataVaultController.class);

    @PostMapping(value = "/aadhaar", produces = "application/json")
    public ResponseEntity<AadhaarNumberResponse> getAadhaarNumber(@RequestBody AadhaarNumberRequest request) {
        LOGGER.info("Request {} received for fetching aadhaar number ", request);
        AadhaarNumberResponse response = new AadhaarNumberResponse();
        ResponseErrorCode responseCode = null;
        Result result = null;
        try {
            String uid = vaultService.getAadhaarNumber(request);
            response.setUid(uid);
            responseCode = ResponseErrorCode.SUCCESS;
        } catch (DataVaultRuntimeException e) {
            responseCode = e.getErrorCode();
            LOGGER.error("Error while fetching aadhaar number {} ", e.getMessage(), e);
        } catch (Exception e) {
            responseCode = ResponseErrorCode.UNKNOWN_SERVICE_ERROR;
            LOGGER.error("Error while fetching aadhaar number {} ", e.getMessage(), e);
        }
        result = ResponseEntityBuilder.getResult(responseCode);
        response.setResult(result);
        response.setRequestId(request.getRequestId());
        LOGGER.info("Sending the response {} for fetch aadhaar number request ", response);
        return responseEntityBuilder.getResponse(response, responseCode, request.getApiKey());
    }

    @PostMapping(value = "/referenceKey", produces = "application/json")
    public ResponseEntity<ReferenceKeyResponse> getReferenceNumber(@RequestBody ReferenceKeyRequest request) {
        LOGGER.info("Request {} received for fetching reference number ", request);
        ReferenceKeyResponse response = new ReferenceKeyResponse();
        ResponseErrorCode responseCode = null;
        Result result = null;
        try {
            String referenceKey = vaultService.getReferenceKey(request);
            response.setReferenceKey(referenceKey);
            responseCode = ResponseErrorCode.SUCCESS;
        } catch (DataVaultRuntimeException e) {
            responseCode = e.getErrorCode();
            LOGGER.error("Error while fetching reference number {} ", e.getMessage(), e);
        } catch (Exception e) {
            responseCode = ResponseErrorCode.UNKNOWN_SERVICE_ERROR;
            LOGGER.error("Error while fetching reference number {} ", e.getMessage(), e);
        }

        result = ResponseEntityBuilder.getResult(responseCode);
        response.setResult(result);
        response.setRequestId(request.getRequestId());
        LOGGER.info("Sending the response {} for fetch reference number request ", response);
        return responseEntityBuilder.getResponse(response, responseCode, request.getApiKey());
    }

    @DeleteMapping(value = "/aadhaarReference", produces = "application/json")
    public ResponseEntity<?> removeAadhaar(@RequestBody AadhaarNumberRequest request) {
        LOGGER.debug("This is a Request received in order to permanently delete the corresponding aadhaar for this reference key :: {} ", request);
        ResponseEntity<?> response = null;
        try {
            ResponseDTO responseDTO = vaultService.removeAadhaarByReferenceKey(request);
            if (ResponseErrorCode.SUCCESS.getMessage().equals(responseDTO.getMeta().getDescription())) {
                response = new ResponseEntity<>(request.getReferenceKey(), HttpStatus.OK);
            } else {
                response = new ResponseEntity<>(responseDTO, HttpStatus.NOT_FOUND);
            }
        } catch (DataVaultRuntimeException e) {
            response = CommonUtil.getResponseEntityForRemoveAadhaar(e.getErrorCode());
            LOGGER.error("Error DataVaultRuntimeException while marking aadhaar number as null :: {}, Exception :: {} ", e.getMessage(), e);
        } catch (Exception e) {
            response = CommonUtil.getResponseEntityForRemoveAadhaar(ResponseErrorCode.UNKNOWN_SERVICE_ERROR);
            LOGGER.error("Error Exception while marking aadhaar number as null :: {}, Exception :: {} ", e.getMessage(), e);
        }
        LOGGER.debug("Sending the response for removing aadhaar number request of this Reference-No :{}: and the response is :{}:", request.getReferenceKey(), response);
        return response;
    }

}