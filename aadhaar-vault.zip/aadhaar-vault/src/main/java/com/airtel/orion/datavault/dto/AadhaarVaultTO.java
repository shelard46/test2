package com.airtel.orion.datavault.dto;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

public class AadhaarVaultTO implements Serializable{
	
	private static final long serialVersionUID = 8981099271770999827L;
	
	private String uid;
	
	private String referenceKey;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getReferenceKey() {
		return referenceKey;
	}

	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("uid", uid).append("referenceKey", referenceKey).toString();
	}
	
}
