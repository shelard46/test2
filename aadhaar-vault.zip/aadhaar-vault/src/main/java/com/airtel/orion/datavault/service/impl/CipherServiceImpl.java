package com.airtel.orion.datavault.service.impl;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtel.orion.datavault.adapter.IHSMAdapter;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.service.CipherService;

@Service
public class CipherServiceImpl implements CipherService, InitializingBean {

	@Autowired
	private IHSMAdapter hsmAdapter;

//	private IvParameterSpec ivParams;

//	private Cipher dcipher;

//	private Cipher ecipher;

//	private Key key;

	private static final Logger LOGGER = LoggerFactory.getLogger(CipherServiceImpl.class);

	private static final byte[] iv = { (byte) 0x76, (byte) 0x80, (byte) 0x6B, (byte) 0xE2, (byte) 0xFE, (byte) 0x2,
			(byte) 0x5D, (byte) 0xAF, (byte) 0xC, (byte) 0x9F, (byte) 0x4A, (byte) 0x9E, (byte) 0x5C, (byte) 0xAA,
			(byte) 0xDC, (byte) 0x20 };

	private void initialize() throws Exception {
//		initKeySpecs();
//		initCiphers();
	}

//	private void initKeySpecs() throws Exception {
//		LOGGER.info("Initializing Key Specs");
//		ivParams = new IvParameterSpec(iv);
//		key = (SecretKey) hsmAdapter.getKey();
//	}

//	private void initCiphers() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
//			InvalidAlgorithmParameterException {
//		LOGGER.info("Initializing Ciphers");
//		ecipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//		dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//		ecipher.init(Cipher.ENCRYPT_MODE, key, ivParams);
//		dcipher.init(Cipher.DECRYPT_MODE, key, ivParams);
//	}

	public String encrypt(String str) {
		try {
			SecretKey key = (SecretKey)hsmAdapter.getKey();
			IvParameterSpec ivParams = new IvParameterSpec(iv);
			Cipher ecipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			ecipher.init(Cipher.ENCRYPT_MODE, key, ivParams);
			LOGGER.debug("Encrypting");
			byte[] utf8 = str.getBytes("UTF8");
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception e) {
//			ecipher = null;
			LOGGER.error("Error while encrypting data : ", e.getMessage(), e);
			throw new DataVaultRuntimeException(ResponseErrorCode.HSM_ACCESS_EXCEPTION, e.getMessage());
		}
	}

	public String decrypt(String str) {
		try {
			SecretKey key = (SecretKey)hsmAdapter.getKey();
			IvParameterSpec ivParams = new IvParameterSpec(iv);
			Cipher dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, key, ivParams);
//			if (dcipher == null) {
//				LOGGER.info("Dcipher is not initialized . Reinitializing");
//				initialize();
//			}
			LOGGER.debug("Decrypting");
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, "UTF8");
		} catch (Exception e) {
//			dcipher = null;
			LOGGER.error("Error while decrypting data : ", e.getMessage(), e);
			throw new DataVaultRuntimeException(ResponseErrorCode.HSM_ACCESS_EXCEPTION, e.getMessage());
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		initialize();
	}

}
