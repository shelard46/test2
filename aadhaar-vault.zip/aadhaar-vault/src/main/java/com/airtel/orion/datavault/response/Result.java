package com.airtel.orion.datavault.response;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Result implements Serializable{

	private static final long serialVersionUID = -7671582293522799142L;
	
	private String statusCode;
	
	private String statusDescription;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("statusCode", statusCode).append("statusDescription", statusDescription).toString();
	}
}
