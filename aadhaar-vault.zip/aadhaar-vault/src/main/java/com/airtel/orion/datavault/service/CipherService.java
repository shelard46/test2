package com.airtel.orion.datavault.service;

public interface CipherService {
	
	public String encrypt(String data);
	
	public String decrypt(String data);

}
