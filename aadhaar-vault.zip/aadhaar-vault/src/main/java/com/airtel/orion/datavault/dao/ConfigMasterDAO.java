package com.airtel.orion.datavault.dao;

import java.util.List;

import com.airtel.orion.datavault.dto.ConfigValueTO;

public interface ConfigMasterDAO {
	
	public String getConfigValue(String appName);

	List<ConfigValueTO> getConfigValues();

}
