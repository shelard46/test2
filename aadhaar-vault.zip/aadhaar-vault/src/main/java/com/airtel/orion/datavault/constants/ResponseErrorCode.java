package com.airtel.orion.datavault.constants;

import org.springframework.http.HttpStatus;

public enum ResponseErrorCode {

	SUCCESS("uid-00", "Request processed successfully", HttpStatus.OK),

	INVALID_UID("uid-10", "uid is not valid", HttpStatus.BAD_REQUEST),

	INVALID_PATTERN_UID("uid-11", "uid number pattern not valid", HttpStatus.BAD_REQUEST),

	INVALID_DIGITS_UID("uid-12", "number of digits in uid is not valid", HttpStatus.BAD_REQUEST),

	INVALID_CHECK_DIGIT_UID("uid-13", "uid check digit is not valid", HttpStatus.BAD_REQUEST),

	INVALID_REF_KEY("uid-20", "Invalid Reference Key", HttpStatus.BAD_REQUEST),

	INVALID_PATTERN_REF_KEY("uid-21", "Invalid Reference Key pattern", HttpStatus.BAD_REQUEST),

	INVALID_DIGITS_REF_KEY("uid-22", "Invalid number of digits Reference Key", HttpStatus.BAD_REQUEST),

	INVALID_CHECK_DIGIT_REF_KEY("uid-23", "Invalid check digit Reference Key", HttpStatus.BAD_REQUEST),
	
	INVALID_REF_KEY_NO_MAPPING("uid-24", "No mapping found for Reference Key", HttpStatus.BAD_REQUEST),

	AADHAAR_ALREADY_DELETED("uid-25", "Aadhaar already deleted", HttpStatus.NOT_FOUND),

	NO_AADHAAR_MAPPING_FOUND_FOR_DELETION("uid-26", "No mapping found for Reference Key", HttpStatus.NOT_FOUND),

	AADHAAR_HAS_BEEN_DELETED("uid-27", "Aadhaar has been deleted from the system", HttpStatus.NOT_FOUND),

	INVALID_REF_KEY_GENERATED("uid-30", "System Error.Retry", HttpStatus.CONFLICT),

	INVALID_REQUEST("uid-40", "Request is not valid", HttpStatus.BAD_REQUEST),

	DATA_ACCESS_ERROR("uid-50", "Database Operation Error ", HttpStatus.CONFLICT),
	
	DATA_CONSTRAINT_VIOLATED("uid-51", "Database Error. Unique Constraint Violated ", HttpStatus.CONFLICT),

	HSM_ACCESS_EXCEPTION("uid-60", "Technical issue which is transient", HttpStatus.CONFLICT),

	ENCRYPTION_ERROR("uid-70", "Error encrypting data ", HttpStatus.FORBIDDEN),

	DECRYPTION_ERROR("uid-80", "Error decrypting data ", HttpStatus.FORBIDDEN),

	AUTHENTICATION_FAILED("uid-90", "Authentication Failed ", HttpStatus.FORBIDDEN),
	
	APP_NOT_REGISTERED("uid-91", "App not registered", HttpStatus.FORBIDDEN),
	
	NO_MSG_SIGNATURE("uid-92", "No Msg Signature Found", HttpStatus.FORBIDDEN),

	UNKNOWN_SERVICE_ERROR("uid-100", "Unknown Service Error", HttpStatus.EXPECTATION_FAILED);

	private String statusCode;
	private String message;
	private HttpStatus httpStatus;

	ResponseErrorCode(String statusCode, String message, HttpStatus httpStatus) {
		this.statusCode = statusCode;
		this.message = message;
		this.httpStatus = httpStatus;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
	
}
