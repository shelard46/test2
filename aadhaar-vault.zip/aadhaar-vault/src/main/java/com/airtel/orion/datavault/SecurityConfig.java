package com.airtel.orion.datavault;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.airtel.orion.datavault.filters.RequestSecurityFilter;


@Configuration
public class SecurityConfig {

    @Bean
    public FilterRegistrationBean requestSecurityFilterRegistration() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(requestSecurityFilter());
        registration.addUrlPatterns("/orion/uid/vault/referenceKey","/orion/uid/vault/aadhaar","/orion/uid/vault/aadhaarReference");
        registration.setName("requestSecurity");
        registration.setOrder(1);
        return registration;
    }

    @Bean(name = "requestSecurity")
    public Filter requestSecurityFilter() {
        return new RequestSecurityFilter();
    }

}
