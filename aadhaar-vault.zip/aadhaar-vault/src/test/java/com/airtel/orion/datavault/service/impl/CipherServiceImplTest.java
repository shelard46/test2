package com.airtel.orion.datavault.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.airtel.orion.datavault.adapter.IHSMAdapter;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;

public class CipherServiceImplTest {
	@InjectMocks
	private CipherServiceImpl cipherService;
	@Mock
	private IHSMAdapter hsmAdapter;
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldNotEncryptIfSecretKeyNotPresent() {
		cipherService.encrypt("TESTREFKEY");
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldNotDecryptIfSecretKeyNotPresent() {
		cipherService.decrypt("TESTREFKEY");
	}
	
}
