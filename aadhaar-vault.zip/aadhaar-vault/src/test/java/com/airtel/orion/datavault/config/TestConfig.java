package com.airtel.orion.datavault.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@ConfigurationProperties
@PropertySources({
    @PropertySource("classpath:application-test.properties")})
public class TestConfig {
    
	@Value("${hsm.encryption.enable}")
	private String hsmEncryptionEnabled;
    
    public String hsmEncryptionEnabled() {
        return hsmEncryptionEnabled;
    }
}