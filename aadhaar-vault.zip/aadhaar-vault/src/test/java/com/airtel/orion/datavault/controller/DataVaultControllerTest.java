package com.airtel.orion.datavault.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.response.Meta;
import com.airtel.orion.datavault.response.ResponseDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.request.ReferenceKeyRequest;
import com.airtel.orion.datavault.service.DataVaultService;
import com.airtel.orion.datavault.utils.ResponseEntityBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataVaultControllerTest {

	@InjectMocks
	DataVaultController dataVaultController;

	@Mock
	DataVaultService vaultService;

	@Mock
	ResponseEntityBuilder responseEntityBuilder;

	private MockMvc mockMvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(dataVaultController).build();
	}

	@Test
	public void shouldGetAadhaarNumber() throws Exception {
		AadhaarNumberRequest request = getAadhaarNumberRequest();
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.post("/orion/uid/vault/aadhaar")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isOk()).andReturn();
		Assert.assertTrue(true);
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();
		assertEquals(HttpStatus.OK.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	@Test
	public void shouldGetReferenceNumber() throws JsonProcessingException, Exception {
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.post("/orion/uid/vault/referenceKey")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isOk()).andReturn();
		Assert.assertTrue(true);
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();

		assertEquals(HttpStatus.OK.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	@Test
	public void testRemoveAadhaar() throws Exception {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setRequestId("ABC");
		request.setApiKey("paymentBank");
		request.setReferenceKey("969452339928");
		Mockito.when(vaultService.removeAadhaarByReferenceKey(Mockito.any(AadhaarNumberRequest.class))).thenReturn(ResponseDTO.builder().meta(Meta.builder().code("SUCCESS").description("Request processed successfully").build()).build());
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.delete("/orion/uid/vault/aadhaarReference")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();
		assertEquals(HttpStatus.OK.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	@Test
	public void testRemoveAadhaarNotFound() throws Exception {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setRequestId("ABC");
		request.setApiKey("paymentBank");
		request.setReferenceKey("969452339928");
		Mockito.when(vaultService.removeAadhaarByReferenceKey(Mockito.any(AadhaarNumberRequest.class))).thenReturn(ResponseDTO.builder().meta(Meta.builder().code("SUCCESS").description("Request processed").build()).build());
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.delete("/orion/uid/vault/aadhaarReference")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isNotFound()).andReturn();
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();
		assertEquals(HttpStatus.NOT_FOUND.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	@Test
	public void testRemoveAadhaarNotFoundWithDataVaultExeception() throws Exception {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setRequestId("ABC");
		request.setApiKey("paymentBank");
		request.setReferenceKey("969452339928");
		Mockito.when(vaultService.removeAadhaarByReferenceKey(Mockito.any(AadhaarNumberRequest.class))).thenThrow(new DataVaultRuntimeException(ResponseErrorCode.AADHAAR_ALREADY_DELETED));
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.delete("/orion/uid/vault/aadhaarReference")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isNotFound()).andReturn();
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();
		assertEquals(HttpStatus.NOT_FOUND.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	@Test
	public void testRemoveAadhaarNotFoundWithException() throws Exception {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setRequestId("ABC");
		request.setApiKey("paymentBank");
		request.setReferenceKey("969452339928");
		Mockito.when(vaultService.removeAadhaarByReferenceKey(Mockito.any(AadhaarNumberRequest.class))).thenThrow(new RuntimeException("test"));
		MvcResult resultFromAPIHit = mockMvc.perform(MockMvcRequestBuilders.delete("/orion/uid/vault/aadhaarReference")
				.content(new ObjectMapper().writeValueAsString(request)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isExpectationFailed()).andReturn();
		MockHttpServletResponse responseFromApiHit = resultFromAPIHit.getResponse();
		assertEquals(HttpStatus.EXPECTATION_FAILED.value(), responseFromApiHit.getStatus());
		assertNotNull(responseFromApiHit.getContentAsString());
	}

	private AadhaarNumberRequest getAadhaarNumberRequest() {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("TEST2930");
		return request;
	}

}
