package com.airtel.orion.datavault.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import com.airtel.orion.datavault.dao.impl.AadhaarVaultDAOImpl;
import com.airtel.orion.datavault.dto.AadhaarVaultTO;
import com.airtel.orion.datavault.response.ResponseDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.airtel.orion.datavault.constants.PropertyNames;
import com.airtel.orion.datavault.dao.AadhaarVaultDAO;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.request.ReferenceKeyRequest;
import com.airtel.orion.datavault.service.CipherService;
import com.airtel.orion.datavault.utils.ConfigMasterUtil;
import org.springframework.test.util.ReflectionTestUtils;

public class DataVaultServiceImplTest {

	public static final String AADHAAR_VALUE = "732284402680";
	@InjectMocks
	DataVaultServiceImpl dataVaultService;

	@Mock
	private AadhaarVaultDAOImpl vaultDao;

	@Mock
	private CipherService cipherService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		HashMap<String, String> config = new HashMap<>();
		config.put(PropertyNames.VALIDATE_UID_CHECK_DIGIT, "1");
		ConfigMasterUtil.setConfigValues(config);
	}

	@Test
	public void shouldGetAadhaarReferenceNumber() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid(AADHAAR_VALUE);
		aadhaarVaultTO.setReferenceKey(AADHAAR_VALUE);
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		String aadhaarRefNumber = dataVaultService.getAadhaarNumber(request);
		assertTrue(aadhaarRefNumber != null);
		assertEquals(AADHAAR_VALUE, aadhaarRefNumber);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldGetAadhaarReferenceNumberWithVaultException() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setReferenceKey(AADHAAR_VALUE);
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldGetAadhaarReferenceNumberFail() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn(null);
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		dataVaultService.getAadhaarNumber(request);
	}

	@Test
	public void shouldGetAadhaarReferenceNumberWithHSMInvalid() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "truee");
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid(AADHAAR_VALUE);
		aadhaarVaultTO.setReferenceKey(AADHAAR_VALUE);
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		String aadhaarRefNumber = dataVaultService.getAadhaarNumber(request);
		assertTrue(aadhaarRefNumber != null);
		assertEquals(AADHAAR_VALUE, aadhaarRefNumber);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldGetAadhaarReferenceNumberFailWithHSMInvalid() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "truee");
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn(null);
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		dataVaultService.getAadhaarNumber(request);
	}

	@Test
	public void shouldGetAadhaarReferenceNumberSuccessWithhsmEncryptionEnabled() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn(AADHAAR_VALUE);
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn(AADHAAR_VALUE);
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid("123456789089");
		aadhaarVaultTO.setReferenceKey("123456789089");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		String result = dataVaultService.getAadhaarNumber(request);
		Assert.assertEquals(AADHAAR_VALUE, result);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldGetAadhaarReferenceNumberFailWithhsmEncryptionEnabled() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn(AADHAAR_VALUE);
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn(AADHAAR_VALUE);
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn(null);
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey(AADHAAR_VALUE);
		dataVaultService.getAadhaarNumber(request);
	}


	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailForInvalidRequest() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailForInvalidDigits() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("D293040");
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailForInvalidNoOfDigits() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("293040");
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailForInvalidRefKey() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn("TestRefKey");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("123123123123");
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailForNoAadhaarExistsForRefKey() {
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn(null);
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("123123123123");
		dataVaultService.getAadhaarNumber(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailOnNullReferenceKey() {
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid(null);
		dataVaultService.getReferenceKey(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailOnEmptyReferenceKey() {
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("");
		dataVaultService.getReferenceKey(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailOnInvalidReferenceKey() {
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("D9930");
		dataVaultService.getReferenceKey(request);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void shouldFailOnInvalidDigitsReferenceKey() {
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("12312312313");
		dataVaultService.getReferenceKey(request);
	}
	
	@Test
	public void shouldReturnRefKeyIfExists() {
		Mockito.when(vaultDao.getReferenceKey(Mockito.any())).thenReturn("TEST133");
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("123123123123");
		String refKey = dataVaultService.getReferenceKey(request);
		assertTrue(refKey != null);
		assertEquals("TEST133", refKey);
	}

	@Test
	public void shouldCreateNewKeyForNoRefKeyExists() {
		Mockito.when(vaultDao.getReferenceKey(Mockito.any())).thenReturn(null);
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("123123123123");
		String refKey = dataVaultService.getReferenceKey(request);
		assertTrue(refKey != null);
	}

	@Test
	public void shouldReturnRefKeyIfExistsWithHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn("TEST133");
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn("TEST133");
		Mockito.when(vaultDao.getReferenceKey(Mockito.any())).thenReturn("TEST133");
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("123123123123");
		String refKey = dataVaultService.getReferenceKey(request);
		assertTrue(refKey != null);
		assertEquals("TEST133", refKey);
	}

	@Test
	public void shouldCreateNewKeyForNoRefKeyExistsWithHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn("TEST133");
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn("TEST133");
		Mockito.when(vaultDao.getReferenceKey(Mockito.any())).thenReturn(null);
		ReferenceKeyRequest request = new ReferenceKeyRequest();
		request.setUid("123123123123");
		String refKey = dataVaultService.getReferenceKey(request);
		assertTrue(refKey != null);
	}

	@Test
	public void testRemoveAadhaarByReferenceKeySuccess() {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid("123456789089");
		aadhaarVaultTO.setReferenceKey("123456789089");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		Mockito.when(vaultDao.removeAadhaarNumberByReferenceKey(Mockito.any())).thenReturn(true);
		ResponseDTO responseDTO = dataVaultService.removeAadhaarByReferenceKey(request);
		Assert.assertNotNull(responseDTO);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void testRemoveAadhaarByReferenceKeyFail() {
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid("818953340291");
		aadhaarVaultTO.setReferenceKey("818953340291");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		Mockito.when(vaultDao.getAadhaarNumber(Mockito.any())).thenReturn(null);
		dataVaultService.removeAadhaarByReferenceKey(request);
	}

	@Test
	public void testRemoveAadhaarByReferenceKeySuccessInvalidHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "truee");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setReferenceKey("818953340291");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		Mockito.when(vaultDao.removeAadhaarNumberByReferenceKey(Mockito.any())).thenReturn(true);
		ResponseDTO responseDTO = dataVaultService.removeAadhaarByReferenceKey(request);
		Assert.assertNotNull(responseDTO);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void testRemoveAadhaarByReferenceKeyFailInvalidHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "truee");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid("818953340291");
		aadhaarVaultTO.setReferenceKey("818953340291");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		Mockito.when(vaultDao.removeAadhaarNumberByReferenceKey(Mockito.any())).thenReturn(false);
		dataVaultService.removeAadhaarByReferenceKey(request);
	}

	@Test
	public void testRemoveAadhaarByReferenceKeySuccessWithHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn("818953340291");
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn("818953340291");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(null);
		Mockito.when(vaultDao.removeAadhaarNumberByReferenceKey(Mockito.any())).thenReturn(true);
		ResponseDTO responseDTO = dataVaultService.removeAadhaarByReferenceKey(request);
		Assert.assertNotNull(responseDTO);
	}

	@Test(expected = DataVaultRuntimeException.class)
	public void testRemoveAadhaarByReferenceKeyFailWithHSM() {
		ReflectionTestUtils.setField(dataVaultService, "hsmEncryptionEnabled", "true");
		Mockito.when(cipherService.encrypt(Mockito.any())).thenReturn("818953340291");
		Mockito.when(cipherService.decrypt(Mockito.any())).thenReturn("818953340291");
		AadhaarNumberRequest request = new AadhaarNumberRequest();
		request.setReferenceKey("818953340291");
		AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
		aadhaarVaultTO.setUid("818953340291");
		aadhaarVaultTO.setReferenceKey("818953340291");
		Mockito.when(vaultDao.getAadhaarVaultData(Mockito.any())).thenReturn(aadhaarVaultTO);
		Mockito.when(vaultDao.removeAadhaarNumberByReferenceKey(Mockito.any())).thenReturn(false);
		dataVaultService.removeAadhaarByReferenceKey(request);
	}
}


