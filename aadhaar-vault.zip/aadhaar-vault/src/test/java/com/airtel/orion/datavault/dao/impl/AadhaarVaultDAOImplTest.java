package com.airtel.orion.datavault.dao.impl;

import com.airtel.orion.datavault.dto.AadhaarVaultTO;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Arrays;
import java.util.List;

/**
 * @author Hitesh Khatri
 * @date 04/06/21
 */
public class AadhaarVaultDAOImplTest {

    @Mock
    private JdbcTemplate aadharJdbcTemplate;

    @InjectMocks
    private AadhaarVaultDAOImpl aadhaarVaultDAOImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRemoveAadhaarNumberByReferenceKeyFail() {
        String refKey = "test";
        Mockito.when(aadharJdbcTemplate.update("update aadhaar_vault set aadhaar_number = ? where reference_key = ?", null, refKey)).thenReturn(-1);
        boolean result = aadhaarVaultDAOImpl.removeAadhaarNumberByReferenceKey(refKey);
        Assert.assertFalse(result);
    }

    @Test
    public void testRemoveAadhaarNumberByReferenceKeySuccess() {
        String refKey = "test";
        Mockito.when(aadharJdbcTemplate.update("update aadhaar_vault set aadhaar_number = ? where reference_key = ?", null, refKey)).thenReturn(1);
        aadhaarVaultDAOImpl.removeAadhaarNumberByReferenceKey(refKey);
        Mockito.verify(aadharJdbcTemplate, Mockito.times(1)).update("update aadhaar_vault set aadhaar_number = ? where reference_key = ?", null, refKey);
    }

    @Test(expected = DataVaultRuntimeException.class)
    public void testRemoveAadhaarNumberByReferenceKeyWithException() {
        String refKey = "test";
        Mockito.when(aadharJdbcTemplate.update("update aadhaar_vault set aadhaar_number = ? where reference_key = ?", null, refKey)).thenThrow(new RuntimeException("Test"));
        aadhaarVaultDAOImpl.removeAadhaarNumberByReferenceKey(refKey);
    }

    @Test
    public void testGetNextSeqNumber() {
        Mockito.when(aadharJdbcTemplate.queryForObject("select REF_KEY_SEQ.nextval as num from dual", Long.class)).thenReturn(12345678L);
        Assert.assertEquals(12345678L, (long) aadhaarVaultDAOImpl.getNextSeqNumber());
    }

    @Test
    public void testCreateRefKeyToAadhaarMappingSuccess() {
        AadhaarVaultTO dataObject = new AadhaarVaultTO();
        dataObject.setReferenceKey("1234567890");
        dataObject.setUid("1234567890");
        String configQuery = "insert into aadhaar_vault (aadhaar_number,reference_key) values (?,?)";
        Mockito.when(aadharJdbcTemplate.update(configQuery, dataObject.getUid(),
                dataObject.getReferenceKey())).thenReturn(1);
        Assert.assertTrue(aadhaarVaultDAOImpl.createRefKeyToAadhaarMapping(dataObject));
    }

    @Test(expected = DataVaultRuntimeException.class)
    public void testCreateRefKeyToAadhaarMappingFail() {
        AadhaarVaultTO dataObject = new AadhaarVaultTO();
        dataObject.setReferenceKey("1234567890");
        dataObject.setUid("1234567890");
        String configQuery = "insert into aadhaar_vault (aadhaar_number,reference_key) values (?,?)";
        Mockito.when(aadharJdbcTemplate.update(configQuery, dataObject.getUid(),
                dataObject.getReferenceKey())).thenReturn(0);
        aadhaarVaultDAOImpl.createRefKeyToAadhaarMapping(dataObject);
    }

    @Test
    public void testGetReferenceKey() {
        String aadhaarNumber = "123456789012";
        String configQuery = "SELECT reference_key FROM aadhaar_vault WHERE aadhaar_number = ?";
        Mockito.when(aadharJdbcTemplate.queryForList(configQuery, new Object[]{aadhaarNumber},
                String.class)).thenReturn(Arrays.asList(aadhaarNumber));
        String ref = aadhaarVaultDAOImpl.getReferenceKey(aadhaarNumber);
        Assert.assertEquals(aadhaarNumber, ref);
    }

    @Test
    public void testGetAadhaar() {
        String refkey = "123456789012";
        String configQuery = "SELECT aadhaar_number FROM aadhaar_vault WHERE reference_key = ?";
        Mockito.when(aadharJdbcTemplate.queryForList(configQuery, new Object[]{refkey},
                String.class)).thenReturn(Arrays.asList(refkey));
        String aadhaar = aadhaarVaultDAOImpl.getAadhaarNumber(refkey);
        Assert.assertEquals(refkey, aadhaar);
    }

    @Test
    public void testGetAadhaarVaultData() {
        Assert.assertNull(aadhaarVaultDAOImpl.getAadhaarVaultData("test"));
    }

}
