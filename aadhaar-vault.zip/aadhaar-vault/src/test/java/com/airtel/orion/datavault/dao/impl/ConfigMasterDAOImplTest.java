package com.airtel.orion.datavault.dao.impl;

import com.airtel.orion.datavault.dto.ConfigValueTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

public class ConfigMasterDAOImplTest {

    public static final String TESTKEY = "TESTKEY";
    public static final String TEST = "test";

    @InjectMocks
    private ConfigMasterDAOImpl configMasterDao;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldReturnConfigValueForTestKeyFail() {
        String result = configMasterDao.getConfigValue(TESTKEY);
        assertNull(result);
    }

    @Test
    public void shouldReturnConfigValueForTestKeySuccess() {

        when(jdbcTemplate.queryForObject("SELECT key FROM config_master WHERE name = ?", new Object[]{TESTKEY}, String.class)).thenReturn(TEST);
        String result = configMasterDao.getConfigValue(TESTKEY);
        assertEquals(TEST, result);
    }

    @Test
    public void shouldReturnConfigValues() {
        List<ConfigValueTO> result = configMasterDao.getConfigValues();
        assertNotNull(result);
    }
}
