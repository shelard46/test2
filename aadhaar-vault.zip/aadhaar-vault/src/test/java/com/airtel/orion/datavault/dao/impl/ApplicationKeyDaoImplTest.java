package com.airtel.orion.datavault.dao.impl;

import com.airtel.orion.datavault.dto.ApplicationKeyTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class ApplicationKeyDaoImplTest {

	@InjectMocks
	private ApplicationKeyDAOImpl applicationDao;

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldReturnApplicationKeyFail() {
		assertNull(applicationDao.getApplicationKey("testAppName"));
	}

	@Test
	public void shouldReturnApplicationKeySuccess() {
		ApplicationKeyTO app = new ApplicationKeyTO();
		Mockito.when(jdbcTemplate.queryForObject("SELECT key FROM application_keys WHERE name = ?", new Object[]{"testAppName"},
				String.class)).thenReturn("test");
		assertNotNull(applicationDao.getApplicationKey("testAppName"));
	}

	@Test
	public void shouldReturnApplicationKeys() {
		assertNotNull(applicationDao.getApplicationKeys());
	}

}
