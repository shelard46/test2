package com.airtelbank.sweepinout.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "input")
public class Input {

	@XmlElement(name = "LoggedInUserId")
	private String loggedInUserId;

	@XmlElement(name = "SessionContext")
	private SessionContext sessionContext;

	@XmlElement(name = "RefNoCumFlag")
	private String refNoCumFlag;

	@XmlElement(name = "Operation")
	private String operation;

	@XmlElement(name = "ValueDate")
	private String valueDate;

	@XmlElement(name = "TransactionData2")
	private String transactionData2;

	@XmlElement(name = "TransactionData1")
	private String transactionData1;

	@XmlTransient
	private long suryodayTxnId;

	@XmlTransient
	private int retryCount = 0;
	
}
