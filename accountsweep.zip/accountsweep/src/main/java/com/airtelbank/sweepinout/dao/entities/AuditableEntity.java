package com.airtelbank.sweepinout.dao.entities;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The <code>AuditableEntity</code> represents base class for all persistence
 * entities which needs to be audited. It contains common attributes which must
 * be present in all auditable persistence entities.
 *
 * @author b0211363
 *
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
public abstract class AuditableEntity implements Serializable {

	private static final long serialVersionUID = -5481977578791509969L;

	/** Creation time stamp of persistence object */
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Calendar createdOn;


	/** Last modification time stamp of persistence object */
	@Column(name = "modifiedOn", nullable = false)
	private Calendar modifiedOn;



	/**
	 * Initialises the {@link #createdOn}, {@link #modifiedOn} attributes before a
	 * new business object is persisted.
	 */
	@PrePersist
	protected void prePersist() {
		if (null == createdOn) {
			createdOn = Calendar.getInstance();
		}
		if (null == modifiedOn) {
			modifiedOn = getCreatedOn();
		}
	}


	/**
	 * Updates the {@link #modifiedOn} attribute before a business object is
	 * updated.
	 */
	@PreUpdate
	protected void preUpdate() {
		modifiedOn = Calendar.getInstance();
	}

}
