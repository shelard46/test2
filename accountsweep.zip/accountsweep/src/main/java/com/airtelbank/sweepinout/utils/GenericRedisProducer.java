package com.airtelbank.sweepinout.utils;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;

import com.airtelbank.sweepinout.config.RedisConfig;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;

@Slf4j
public class GenericRedisProducer {

	public static <T>  void addEntryToZadd(String zaddkey, String member, int retryPeriodInMin) {
		try(Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {			
			if (jedis != null) {
				long score = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(retryPeriodInMin);
				log.info("Storing member {} with score {} in ZADDSET {}", member, score, zaddkey);
				jedis.zadd(zaddkey, score, member);
			} else {
				log.error("Couldn't get a jedis client from pool");
			}			
		}			
	}				

	public static <T> void addEntryToRedisHset(String key, String hsetField, T record, int hsetExpiryTimeInSec) {
		Gson gson = new Gson();
		try(Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {
			if (jedis != null) {
				log.info("Storing value {} in redis set {}",  record, key);
				if(StringUtils.isBlank(hsetField)) {
					jedis.hset(key, "field", gson.toJson(record));
				} else {
					jedis.hset(key, hsetField, gson.toJson(record));
				}
				jedis.expire(key, hsetExpiryTimeInSec);
				log.info("Setting expiry of set {} in seconds {}", key, hsetExpiryTimeInSec);
			} else {
				log.error("Couldn't get a jedis client from pool");
			}
		}
		
	}

	public static void removeEntryFromZadd(String key, String member) {
		try(Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {
			if (jedis != null) {
				log.info("removing value {} from {}", member, key);
				jedis.zrem(key, member);
			} else {
				log.error("Couldn't get a jedis client from pool");
			}
		}
	}

	public static void removeEntryFromRedisHashSet(String key, String field) {
		log.info("Inside remove from hdel method.");
		try(Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {			
			if (jedis != null) {			
				log.info("Removing key {} from HSet", key);
				jedis.hdel(key, field);
			} else {
				log.error("Couldn't get a jedis client from pool");
			}
		}
	}
}
