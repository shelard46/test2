package com.airtelbank.sweepinout.utils;

import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.NotAPBCustomerException;

@Component
public class ErrorHandling {

	public void customerErrorHandler(ResultDTO meta) {
		if(Constants.NOT_APB_CUSTOMER_CODE.equals(meta.getCode())) {
            throw new NotAPBCustomerException();
     }
     throw new GenericException(meta.getCode(), meta.getDescription());
}
}

