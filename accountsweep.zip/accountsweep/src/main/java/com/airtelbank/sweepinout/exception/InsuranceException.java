package com.airtelbank.sweepinout.exception;


import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.airtelbank.sweepinout.dto.ResponseDTO;

@Getter
@Setter
public class InsuranceException extends RuntimeException {

    HttpStatus httpStatus;
    private ResponseDTO responseDTO;

    public InsuranceException(ResponseDTO responseDTO,HttpStatus httpStatus) {
        this.responseDTO = responseDTO;
        this.httpStatus = httpStatus;
    }

}
