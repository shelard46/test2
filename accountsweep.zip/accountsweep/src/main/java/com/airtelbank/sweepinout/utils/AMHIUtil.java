package com.airtelbank.sweepinout.utils;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AMHIUtil {

	public static String hashEncrypt(String strToEncrypt) {
		try {
			String secretKey = "987654321ABCDF29987654321ABCDF29";
			byte[] iv = new byte[16];
			SecureRandom secureRandom = new SecureRandom(); // Generate random IV of length 16
			secureRandom.nextBytes(iv);
			IvParameterSpec ivspec = new IvParameterSpec(iv);

			SecretKeySpec skeySpec = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
			// getInstance of AES 256 bit encryption
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			// initialize Cipher for encryption
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivspec);
			// get Final encrypted byte Array
			byte[] encrypted = cipher.doFinal(strToEncrypt.getBytes());
			// convert byteArray[] to `hex` string and return
			return bytesToHex(iv) + ":" + bytesToHex(encrypted);

		} catch (Exception e) {
			log.error("HashEncryption Failed. Exception {}", e);
		}
		return null;
	}

	// function to convert byteArray[] to `hex` string
	private static String bytesToHex(byte[] bytes) {
		final char[] hexArray = "0123456789ABCDEF".toCharArray();
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}
}
