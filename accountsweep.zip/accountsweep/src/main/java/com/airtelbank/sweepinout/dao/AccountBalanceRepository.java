package com.airtelbank.sweepinout.dao;


import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;

public interface AccountBalanceRepository extends JpaRepository<AccountBalance, Long> {
	
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	AccountBalance findByAddonAccount(AddonAccount ddonAccount);
}