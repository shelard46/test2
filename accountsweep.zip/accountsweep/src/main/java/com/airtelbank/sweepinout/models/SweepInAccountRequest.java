package com.airtelbank.sweepinout.models;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class SweepInAccountRequest {
	
	@NotNull(message = "{sweepInOut.base.response.customerid.errormessage}")
	private String accountNo;

	private String retailerNo;

	@NotNull(message = "{sweepInOut.base.response.channel.errormessage}")
	private String channel;
	
	@NotNull(message = "{sweepInOut.base.response.amount.errormessage}")
	private String amount;
	
	@NotNull(message = "{sweepInOut.base.response.source.errormessage}")
	private String sourceId;
	
	@NotNull(message = "{sweepInOut.base.response.purposeCode.errormessage}")
	private String purposeCode;
	
	@NotNull(message = "{sweepInOut.base.response.refrenceNm.errormessage}")
	private String paymentRefId;
	
	private String narration;
	
}