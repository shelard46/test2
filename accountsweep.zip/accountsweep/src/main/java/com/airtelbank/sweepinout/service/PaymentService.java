package com.airtelbank.sweepinout.service;

import org.springframework.stereotype.Service;

import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.models.FundTransferRetryRequest;
import com.airtelbank.sweepinout.models.Input;
import com.airtelbank.sweepinout.models.InputForEnquiry;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInResponseDto;

@Service
public interface PaymentService {
	public void internalFundTransfer(SuryodaySweepTxnDetails details);
	public void suryodayFundTransfer(SuryodaySweepTxnDetails details);
	public SweepInResponseDto internalFundTransferSweepIn(SuryodaySweepTxnDetails details);
	public void saveSuryodayFundTransaferRequestForRetry(InputForEnquiry input);
	public Response suroydayInternalFundTransafer(String refId, SuryodaySweepTxnDetails details);
	public void apbIFTRedisPayment(FundTransferRetryRequest consumerModel);
	public Input createSurodayFundTransferRequest(String refId, SuryodaySweepTxnDetails details);
	public void suryodayIFTRetry(InputForEnquiry input);
	public void updateRecordAfterPayment(String ftResponse, SuryodaySweepTxnDetails details);
}
