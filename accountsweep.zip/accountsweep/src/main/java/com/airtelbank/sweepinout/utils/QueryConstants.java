package com.airtelbank.sweepinout.utils;

public final class QueryConstants {
	private QueryConstants() {}
	//Insurance
	public static final String POLICY_DETAILS_FOR_CANCEL_INSURANCE = "SELECT * FROM INSURANCE WHERE POLICY_NO IN ?1 AND INSURANCE_TYPE= ?2";
	public static final String POLICY_DETAILS_FOR_UPDATE_INSURANCE = "SELECT * FROM INSURANCE WHERE PROPOSAL_ID = ?1 AND INSURANCE_TYPE= ?2";
	public static final String UPDATE_POLICY_STATUS_FOR_INSURANCE = "UPDATE INSURANCE SET STAGE=?1 WHERE PROPOSAL_ID=?2";
	//CustomerInfo
	public static final String FETCH_CUSTOMER_DETAILS = "SELECT * FROM CUSTOMER_INFO WHERE ACCOUNT_NO=?1 AND INSURANCE_PURCHASED=?2";
     //Proposal
	public static final String POLICY_DETAILS_FOR_CANCEL_INSURANCE_BY_PROPOSAL = "SELECT * FROM PROPOSAL WHERE PROPOSAL_NO =?1";
}
