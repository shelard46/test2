
package com.airtelbank.sweepinout.utils;


import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpMethod;

import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.airtelbank.sweepinout.models.RestRequest;



@Component
public class RequestCreationUtil {
	
	private static final Logger log = LoggerFactory.getLogger(RequestCreationUtil.class);
		
	public static <T> RestRequest<T> createRestRequest(String url, HttpMethod method, Object body, Class<T> responseClass, Map params, MultiValueMap headers, MultiValueMap queryParams) {
		RestRequest<T> restRequest = new RestRequest<>();
		restRequest.setUri(url);
		restRequest.setHttpMethod(method);
		restRequest.setEntity(body);
		restRequest.setResponseClass(responseClass);
		restRequest.setParams(params);
		restRequest.setHeaders(headers);
		restRequest.setQueryParams(queryParams);
		return restRequest;
	}	
	
}
