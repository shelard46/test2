package com.airtelbank.sweepinout.dao.entities;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="SURYODAY_SWEEP_TXN_DETAILS")
@ToString
public class SuryodaySweepTxnDetails implements Serializable{
	
	private static final long serialVersionUID = -5751385247653354376L;
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="SURYODAY_SWEEP_TXN_SEQUENCE")
   	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
    @Column(name = "ID", updatable = false, nullable = false)
	@JsonIgnore
    private long id;
	
    @ManyToOne(optional = false)
	@JoinColumn(name = "AOA_ADDON_ACCOUNT_ID")
	private AddonAccount addonAccount;
    
    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;
    
    @Column(name = "FAILED_REASON")
    private String failedReason;
    
    @Column(name = "CURRENT_STATUS")
    private String currentStatus;
    
    @Column(name = "AMOUNT")
    private BigDecimal amount;
    
    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;
    
    @Column(name = "SURYODAY_TRN_REF_NO")
    private String suryodayTrnRefNo;
    
    @Column(name = "APB_STATUS")
    private String apbStatus;
    
    @Column(name = "SURYODAY_STATUS")
    private String suryodayStatus;
    
    @Column(name = "REFRENCE_NUMBER")
    private String refrenceNumber;
    
    @Column(name = "APB_TXN_ID")
    private String apbTxnId;
    
    @Column(name = "CHANNEL")
    private String channel;
    
    @Column(name = "FLOW_NAME")
    private String flow;
    
    @Column(name = "RETRY_COUNT")
    private Integer retryCount = 0;
    
    @Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Calendar createdOn;


	/** Last modification time stamp of persistence object */
	@Column(name = "MODIFIED_ON", nullable = false)
	private Calendar modifiedOn;
	
	@Column(name = "VALUE_DATE", nullable = false)
	private Calendar valueDate;
	
	@Column(name = "SURYODAY_BLN", nullable = false)
	private String suryodayBln;
	
}
