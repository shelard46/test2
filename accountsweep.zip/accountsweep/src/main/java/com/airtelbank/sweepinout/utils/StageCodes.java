package com.airtelbank.sweepinout.utils;

public enum StageCodes {
		// Payment
		TO_BE_INITIATED, AWAITED, FAILED, SUCCESSFUL, INITIATED,
		EXPIRED, TIMEOUT, RETRY,
		
		// Suryoday payment
		SWEEPIN, SWEEPOUT, TOKENMONEY, SWEEPINREFUND,
		
		//Post payment
		POST_PAYMENT_AWAITED, POST_PAYMENT_DONE, PAYMENT_TRIED;
}
