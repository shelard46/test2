package com.airtelbank.sweepinout.models;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@ToString
public class FtEnquiryResponse {
	private String channel;
	private String sourceId;
	private String purposeCode;
	private String txnCode;
	private String ftTxnId;
	private Date txnDateTime;
	private BigDecimal amount;
	private BigDecimal charges;
	private BigDecimal balAfterTxn;
	private BigDecimal availableBalance;
	private BigDecimal holdBalance;
}