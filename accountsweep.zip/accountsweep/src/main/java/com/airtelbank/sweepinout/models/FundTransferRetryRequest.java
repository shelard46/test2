package com.airtelbank.sweepinout.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class FundTransferRetryRequest {
	private int retryCount = 0;
	private long suryodayTxnId;
	private FundTransferRequest fundTransferRequest;
}