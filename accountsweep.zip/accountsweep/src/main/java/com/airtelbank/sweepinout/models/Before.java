package com.airtelbank.sweepinout.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class Before {
	
	@JsonProperty("COD_ACCT_NO")
	private String codAcctNo;
	
	@JsonProperty("COD_CUST_ID")
	private String codCustId;
	
	@JsonProperty("FLG_CUST_TYP")
	private String flgCustTyp;
	
	@JsonProperty("DAT_AUTOSWP")
	private String datAutoSwp;
	
	@JsonProperty("BAL_AVAILABLE")
	private String balAvailable;
	
	@JsonProperty("AMT_AUTOSWP")
	private String amtAutoSwp;
	
	@JsonProperty("COD_PRIORITY")
	private String codPriority;
	
	@JsonProperty("DAT_AUTOSWP_REV")
	private String datAutoSwpRev;
	
	@JsonProperty("FLG_AUTOSWP")
	private String flgAutoSwp;
	
	@JsonProperty("DAT_LAST_MNT")
	private String datLastMnt;
	
	@JsonProperty("COD_STREAM_ID")
	private String codStreamId;
	
	@JsonProperty("COD_GL_ACCT")
	private String codGlAcct;
	
	@JsonProperty("DAT_LAST_MNT_PURGE")
	private String datLastMntPurge;
	
	@JsonProperty("DAT_LAST_PURGE")
	private String datLastPurge;

}
