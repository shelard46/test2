package com.airtelbank.sweepinout.dao.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AOA_MSTR_ACCOUNT_PROVIDER")
@SequenceGenerator(name = "accountProviderSequence", sequenceName = "ACCOUNT_PROVIDER_SEQUENCE", allocationSize = 50, initialValue = 1)
public class AccountProvider implements Serializable {

	private static final long serialVersionUID = 4236826683754862457L;

	/** The id. */
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	private Long id;

	/** The name. */
	@Column(name = "NAME", length = 50)
	private String name;

	/** The code. */
	@Column(name = "CODE", length = 50)
	private String code;

}
