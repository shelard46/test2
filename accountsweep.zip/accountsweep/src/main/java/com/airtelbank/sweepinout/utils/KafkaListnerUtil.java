package com.airtelbank.sweepinout.utils;

import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.config.log.SweepInOutThreadLocal;
import com.airtelbank.sweepinout.helper.ValidationHelper;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.LoggerModel;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.service.SweepInOutService;

@Component
@RefreshScope
public class KafkaListnerUtil<T> {

	private static final Logger log = LoggerFactory.getLogger(KafkaListnerUtil.class);

	@Autowired
	private ValidationHelper validationHelper;

	@Autowired
	private SweepInOutService sweepInOutService;

	/*
	 * 1. Funds move from APB to APB GL via IFT
	 * 2. Funds move from APB GL to SSFB via SSFB Fund Transfer API.
	 */
	@KafkaListener(topics = "${sweepout.token.money.topic.name}", groupId = "${suryoday.group.id}")
	public void sweepOutTokenMoney(ConsumerRecord<String, T> consumerRecord, Acknowledgment acknowledgment)
			throws IllegalAccessException, InvocationTargetException {
		SweepInOutThreadLocal.setValue(new LoggerModel());
		MDC.put("contentId", UUID.randomUUID().toString());
		validationHelper.printTopicMeta(consumerRecord);
		SweepInOutTokenMoneyRequest request = CommonUtil.objectMapper.convertValue(consumerRecord.value(),
				SweepInOutTokenMoneyRequest.class);
		acknowledgment.acknowledge();
		if (validationHelper.duplicateRecordCheck(request)) {
			sweepInOutService.tokenMoneyDebit(request);
		} else {
			log.info("SweepInOutTokenMoneyRequest duplicate record in kafka {}", request);
		}
	}

	
	/*
	 * 1. Funds move from APB GL to SSFB via SSFB Fund Transfer API.
	 */
	@KafkaListener(topics = "${sweepout.suryoday.ft.topic.name}", groupId = "${suryoday.group.id}")
	public void sweepOutSuryodayFT(ConsumerRecord<String, T> consumerRecord, Acknowledgment acknowledgment)
			throws IllegalAccessException, InvocationTargetException {
		SweepInOutThreadLocal.setValue(new LoggerModel());
		MDC.put("contentId", UUID.randomUUID().toString());
		validationHelper.printTopicMeta(consumerRecord);
		AutoSwpAmtXferLog request = CommonUtil.objectMapper.convertValue(consumerRecord.value(),
				AutoSwpAmtXferLog.class);
		acknowledgment.acknowledge();
		log.info("acknowledge");
		if (validationHelper.duplicateRecordCheck(request)) {
			sweepInOutService.sweepOutSuroydayFT(request);
		} else {
			log.info("SweepInOutTokenMoneyRequest duplicate record in kafka {}", request);
		}
	}

}
