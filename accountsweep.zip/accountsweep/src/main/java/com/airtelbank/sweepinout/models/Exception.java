package com.airtelbank.sweepinout.models;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@JacksonXmlRootElement
public class Exception {
	private String Response;

    private String StackTrace;

    private String ErrorCode;

    private String ErrorMessage;

    private Reason Reason;
}
