package com.airtelbank.sweepinout.config.log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.core.config.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.models.LoggerModel;
import com.airtelbank.sweepinout.utils.Constants;
import com.google.gson.Gson;

@Component
@Order(1)
public class StatsFilter extends OncePerRequestFilter {

	private final Logger log = LoggerFactory.getLogger(StatsFilter.class);

	@Autowired
	MessageSource messageSource;


	@Value(value = "${filter.regex.generic}")
	private String genFilter;

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain filterChain)
			throws ServletException, IOException {
		LoggerModel loggerModel = new LoggerModel();

		SweepInOutThreadLocal.setValue(loggerModel);
		long startTime = System.currentTimeMillis();
		loggerModel.setErrors(new ArrayList<>());
		loggerModel.setMethods(new ArrayList<>());
		MultipleReadHttpServletRequest multipleReadHttpServletRequest = new MultipleReadHttpServletRequest(req);

		if (res.getCharacterEncoding() == null) {
			res.setCharacterEncoding("UTF-8"); // Or whatever default. UTF-8 is good for World Domination.
		}

		HttpServletResponseCopier responseCopier = new HttpServletResponseCopier((HttpServletResponse) res);
		filterChain.doFilter(multipleReadHttpServletRequest, responseCopier);

		byte[] copy = responseCopier.getCopy();
		try {
			responseCopier.flushBuffer();
		} finally {

		}

		long endTime = System.currentTimeMillis();
		long time = endTime - startTime;

		StringBuilder builder = new StringBuilder();

		builder.append(loggerModel.getServiceId()).append(addKibanaSeparator());
		builder.append(loggerModel.getApiId()).append(addKibanaSeparator());
		builder.append(loggerModel.getCustMobileNo()).append(addKibanaSeparator());
		builder.append(loggerModel.getContentId()).append(addKibanaSeparator());
		builder.append(loggerModel.getTranId()).append(addKibanaSeparator());
		builder.append(loggerModel.getAmount()).append(addKibanaSeparator());
		builder.append(loggerModel.getId1()).append(addKibanaSeparator());
		builder.append(loggerModel.getId2()).append(addKibanaSeparator());
		builder.append(loggerModel.getId3()).append(addKibanaSeparator());
		builder.append(loggerModel.getId4()).append(addKibanaSeparator());
		builder.append(loggerModel.getId5()).append(addKibanaSeparator());
		builder.append(loggerModel.getId6()).append(addKibanaSeparator());
		builder.append(loggerModel.getId7()).append(addKibanaSeparator());
		builder.append(loggerModel.getId8()).append(addKibanaSeparator());
		builder.append(loggerModel.getId9()).append(addKibanaSeparator());
		builder.append(loggerModel.getId10()).append(addKibanaSeparator());
		builder.append(loggerModel.getNumber1()).append(addKibanaSeparator());
		builder.append(loggerModel.getNumber2()).append(addKibanaSeparator());
		builder.append(loggerModel.getNumber3()).append(addKibanaSeparator());
		builder.append(loggerModel.getDate1()).append(addKibanaSeparator());
		builder.append(loggerModel.getDate2()).append(addKibanaSeparator());
		builder.append(multipleReadHttpServletRequest.getRequestBody()).append(addKibanaSeparator());
		// Response handling
		try {
			String responseString = new String(copy, res.getCharacterEncoding());
			Gson gson = new Gson();
			ResponseDTO<?> responseDto = gson.fromJson(responseString, ResponseDTO.class);

			if (responseDto != null && responseDto.getMeta() != null) {
				loggerModel.addError(responseDto.getMeta().getCode(), responseDto.getMeta().getDescription(),
						responseDto.getMeta().getStatus());
			}
			builder.append(responseString).append(addKibanaSeparator());
		} catch (Exception e) {
			log.error("Exception occurred in handling api reponse");
		}

		for (int i = 0; i < loggerModel.getErrors().size(); i++) {
			builder.append(loggerModel.getErrors().get(i).getStatus()).append(addKibanaSeparator())
					.append(loggerModel.getErrors().get(i).getErrorCode()).append(addKibanaSeparator())
					.append(loggerModel.getErrors().get(i).getErrorDescription());
		}

		builder.append(Constants.KIBANA_SEPARATOR);
		builder.append(time);
		SweepInOutThreadLocal.unset();
		Pattern pattern = Pattern.compile(genFilter);
		Matcher matcher = pattern.matcher(builder.toString());
		String logStr = builder.toString();
		if (matcher.find()) {
			try {
				logStr = logStr.replaceAll(matcher.group("otp"), "****");
			} catch (Exception e) {
			}
		}
		log.info(logStr);
		if (StringUtils.isNotBlank(loggerModel.getServiceId())) {
			logStr = logStr.replace(loggerModel.getServiceId(), loggerModel.getServiceId().replace(".", "_"));
			log.info(logStr + Constants.KIBANA_SEPARATOR + req.getRequestURI());
		}
		MDC.clear();
	}

	private String addKibanaSeparator() {
		return Constants.KIBANA_SEPARATOR;
	}

}
