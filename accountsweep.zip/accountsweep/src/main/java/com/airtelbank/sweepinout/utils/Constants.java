package com.airtelbank.sweepinout.utils;

public final class Constants {
	public static final String SMS_NUMBER = "smsNumber";

	private Constants() {}
	public static final String REQUEST_SUCCESS_DESCRIPTION = "SUCCESS";
	public static final String REQUEST_SUCCESS_CODE = "000";
	public static final int REQUEST_FAIL = 1;
	public static final int REQUEST_SUCCESS = 0;
	public static final int REQUEST_PENDING = 2;
	public static final String REQUEST_FAIL_STRING = "1";
	public static final String REQUEST_SUCCESS_STRING = "0";
	public static final String REQUEST_PENDING_STRING = "2";
	public static final String AMHI = "AMHI";
	public static final String NEW = "NEW";
	public static final String UPDATE = "UPDATE";
	public static final String CANCEL = "CANCEL";
	public static final int MOBILE_LENGTH = 10;
	public static final int MAX_LENGTH = 15;
	public static final String DATE_FORMAT ="yyyy-MM-dd";
	public static final int POLICY_NUMBER_MIN =10;
	public static final int POLICY_NUMBER_MAX =13;
	public static final String ANDROID = "ANDROID";
	public static final String SWEEP_IN_PURPOSE_CODE = "SWEEPIN";
	public static final String CUS_SEGMENT = "CUS";
	public static final String KIBANA_SEPARATOR = "~#~";
	public static final String INSURANCE_PRODUCT_ID="5";
	public static final String EXCEPTION_ROOT_CAUSE = "Root Cause: ";
	public static final String EXCEPTION_STACK_TRACE = "Stacktrace: ";
	public static final String GENERIC_ERROR_CODE ="config.generic.errorCode";
	public static final String GENERIC_ERROR_MESSAGE ="config.generic.errorMessage";
	public static final String POLICY_STATUS_POLICY_AWAITED = "Policy awaited";
	public static final String POLICY_STATUS_ISSUED = "Policy Issued";
	public static final String POLICY_CANCELLED = "Policy Cancelled";
	public static final String MOBILE_CODE_PREFIX = "91";
	public static final String AMHI_CONSENT_KEY="AMHIMPINConsent";
	public static final String TRANSACTION_DR = "Dr";
	public static final String TRANSACTION_CR = "Cr";
	public static final String SOCKET_TIME_OUT_EXCEPTION="connect timed out";
    public static final String SOCKET_READ_TIME_OUT_EXCEPTION="Read timed out";
    public static final String PROXY_ERROR= "Unable to tunnel through proxy";
    public static final String HTTP_STATUS_200 = "200";
    public static final String CONTENT_ID = "23413rwrgfserd"; 
    public static final String DEFAULT_CHANNEL = "ANDROID"; 
    public static final String CONTENTID = "contentId"; 

	public static final String PARAM_1 = "EU-GPLAY";
	public static final String PARAM_2 = "";
	public static final String PARAM_3 = "";
	public static final String LATITUDE="0";
	public static final String LONGITUDE = "0";
	public static final String SOURCE_IP="10.56.110.147";
    public static final String PAYMENT_MODE_REAL="REAL";
    public static final String PAYMENT_MODE_ENQUIRY = "ENQUIRY";
    public static final String PAYMENT_MODE_REFUND = "REFUND";
    public static final String PURPOSE_CODE= "";
    public static final String ONBEHALF_MOBILE = "";
    public static final String ONBEHALF_NAME = "";
    
    public static final String CHANNEL = "channel";
	public static final String FROM_ACCOUNT_TYPE = "CUST";
	public static final String LIMIT_DETAILS="";
    public static final String SOURCE_ID="merchants.payment.bbps";
    public static final String TO_ACCOUNT_NO= "220101228";
    public static final String TO_ACCOUNT_TYPE = "GL";
    public static final String TXN_CODE = "bbps.payment";
    public static final String TXN_GROUP_ID = "";
    public static final String PAYMENT_REF_ID = "BBPS002";
    
    
    public static final String AMOUNT = "1000";
    public static final String NARRATION = "";
    public static final String SMS = "smsText";
    public static final String CUSTOMER_MSISDN = "customerId";
    public static final String ERROR_CODE_KEY = "";
    public static final String SWEEPIN_SURYODAY_FAIL = "suryodaySweepInFail";
    public static final String SWEEPIN_SURYODAY_SUCCESS = "suryodaySweepInSuccess";
    public static final String SWEEPIN_SURYODAY_HOLD = "suryodaySweepInHold";
    public static final String SURYODAY_ACCOUNT_NO = "suryodayAccountNo";
    public static final String SWEEPOUT_SUCCESS = "sweepOutSuccess";
	public static final String TOKENMONEY_SUCCESS = "tokenMoneySuccess";

	public static final String TXN_AMOUNT = "amount";
	public static final String TXN_DATE = "txnDate";
    public static final String BALANCE = "balance";
    public static final String APB_FT_SUCCESSS = "FT_000";
    public static final String APB_TXN_ID = "txnID";
    public static final String NOT_APB_CUSTOMER_CODE = "1071";
    public static final String SBA_ACCOUNT_TYPE="SBA";
	public static final String CUR_ACCOUNT_TYPE="CUR";

    public static final String REGULAR="REGULAR";
    public static final String OPENED_TODAY="OPENED_TODAY";
    public static final String REF = "REF";
    public static final String VALIDATE_REF_NUM= "validateReferenceNumber";
    public static final String RAPP = "RAPP";
    
    public static final String SURYODAY_BLANCE = "surodayBalance";

	/**
	 * The constant MESSAGE_DATE_FORMAT.
	 */
	public static final String MESSAGE_DATE_FORMAT = "dd-MMM-yyyy";
    
    public static final String SWEEP_IN = "SWEEPIN";
    public static final String TIMEOUT = "TIMEOUT";
    public static final String SUCCESS = "SUCCESSFUL";
    public static final String SWEEPIN = "SWEEPIN";
    public static final String TOKENMONEY = "TOKENMONEY";
    public static final String SWEEPOUT = "SWEEPOUT";
    public static final String SWEEPINREFUND = "SWEEPINREFUND";
    public static final String REQUEST_FAIL_DESCRIPTION = "FAIL";
    /** The Constant DEFAULTCATEGORYID. */
	public static final String NOTAVAILABLE = "NA";
	public static final String NO_TRANS_ID = "No transaction id set in Recon Process";
	public static final String RECON_ERR_CODE = "RECON_001";
	public static final String RECON_ERR_MSG = "getting no data for this request";
	public static final String EMPTY_STRING = "";
	public static final String INVALID_STATUS_CODE = "INVALID_001";
	public static final String INVALID_STATUS_DESC = "Status must be either success or fail";
	public static final String TYPE = "EMAIL";
	public static final String MODE = "I";
	public static final boolean IS_DELIVERY_REPORT_REQ = false;
	public static final int INDEX = 1;
	public static final String CATEGORY = "transaction";
	public static final boolean IS_MASKING_REQUIRED = false;
	public static final int RETRY_COUNT = 0;
	public static final int MAX_RETRY_COUNT = 0;
	public static final String PRIORITY = "p1";
	public static final int MAX_LEN_REF_ID = 20;
	
	public static final String JSON = "json";
	public static final String XML = "xml";
	public static final String TEXT = "text";
	public static final String INFO_MSG_PREFIX = "<=== ";
	public static final String INFO_MSG_SUFFIX = " ===>";
	public static final int RETRY_CNT = 4;
	public static final String CUST_TYPE = "custType";
}