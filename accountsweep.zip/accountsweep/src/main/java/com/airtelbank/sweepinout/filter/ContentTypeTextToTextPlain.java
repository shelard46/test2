package com.airtelbank.sweepinout.filter;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;

// TODO: Auto-generated Javadoc
/**
 * The Class ContentTypeTextToTextPlain.
 */
@Service
public class ContentTypeTextToTextPlain implements ClientHttpRequestInterceptor {

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(ContentTypeTextToTextPlain.class);

    /* (non-Javadoc)
     * @see org.springframework.http.client.ClientHttpRequestInterceptor#intercept(org.springframework.http.HttpRequest, byte[], org.springframework.http.client.ClientHttpRequestExecution)
     */
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
    	long time = System.currentTimeMillis();
        if(body != null) {
        	LOG.info("Request is : {}", new String(body, "UTF-8"));
        }

        LOG.info("Http Method {}, Request URL {}", request.getMethod().toString(), request.getURI());
        ClientHttpResponse response = execution.execute(request, body);
        time = System.currentTimeMillis() - time;
        LOG.info("Total time taken by request {}", time);
        if(response != null) {
        	LOG.info("HTTP status code returned is : {}" , response.getStatusCode().toString());
        	LOG.info("Response is : {}", response.getBody());
        }
        return response;
    }


}