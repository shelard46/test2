package com.airtelbank.sweepinout.exception;

public class ProcessingException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1844041746898204165L;

	/**
	 * Instantiates a new processing exception.
	 */
	public ProcessingException() {
	}

	/**
	 * Instantiates a new processing exception.
	 *
	 * @param message the message
	 */
	public ProcessingException(String message) {
		super(message);
	}
}