package com.airtelbank.sweepinout.helper;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.AccountBalanceRepository;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.LowBlanceException;
import com.airtelbank.sweepinout.exception.SuryodayIFTException;
import com.airtelbank.sweepinout.exception.SweepInOutException;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.service.PaymentService;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.StageCodes;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
@RefreshScope
public class ValidationHelper {
	
	@Autowired
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;
	
	@Autowired
	private AddonAccountRepository addonAccountRepository;
	
	@Autowired
	private ErrorHandler errorHandler;
	
	@Autowired PaymentService paymentService;
	
	@Autowired
	private AccountBalanceRepository accountBalanceRepository;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private KibanaErrorLogger kibanaLogger;
	
	@Autowired
	private DbAuditingHelper dbAuditingHelper;
	
	public boolean duplicateRecordCheck(SweepInOutTokenMoneyRequest request) {
		AddonAccount addonAccount = addonAccountRepository.findByAccountNumber(request.getCustomerSyordayaAccount());
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository.findByAddonAccount(addonAccount);
		if(suryodaySweepTxnDetails.isEmpty()) {
			log.info("token money request is not duplicate");
			return true;
		} else {
			log.info("token money request is duplicate");
			return false;
		}
	}
	
	public boolean duplicateRecordCheck(AutoSwpAmtXferLog request) {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository.findByApbTxnId(request.getPos());
		log.info("suryodaySweepTxnDetails {}",suryodaySweepTxnDetails);
		if(suryodaySweepTxnDetails != null) {
			//Token Money Case.
			if(StageCodes.TOKENMONEY.equals(suryodaySweepTxnDetails.getFlow()))
				if(StageCodes.SUCCESSFUL.toString().equals(suryodaySweepTxnDetails.getApbStatus()) && StageCodes.TO_BE_INITIATED.toString().equals(suryodaySweepTxnDetails.getSuryodayStatus()))
					return true;
		}
		//Check the object in after.
		AddonAccount addonAccount = null;
		String creationDate = "";
		log.info("request.getBefore(): {}",request.getBefore());
		if(request.getAfter() != null) {
			addonAccount = addonAccountRepository.findByAirtelAcountNumber(request.getAfter().getCodAcctNo().trim());
			creationDate = request.getAfter().getDatAutoSwp();
		}else if(request.getBefore() != null){
			addonAccount = addonAccountRepository.findByAirtelAcountNumber(request.getBefore().getCodAcctNo().trim());
			creationDate = request.getBefore().getDatAutoSwp();
		}
		if(addonAccount == null) {
			log.error("addonAccount not found",request.getBefore());
			return false;
		}else {
			Calendar cal = Calendar.getInstance();
			cal.setTime(CommonUtil.StringToDate(creationDate, env.getProperty("cbs.date.formate")));
			SuryodaySweepTxnDetails txnDetails = suryodaySweepTxnDetailsRepository.findByAddonAccountAndFlowAndValueDate(addonAccount, StageCodes.SWEEPOUT.toString(), cal);
			if(txnDetails == null)
				return true;
			else
				return false;
		}
	}
	
	@Transactional
	public AddonAccount checkForBlanceCustomer(String accountNo, String amount) {
		AddonAccount addonAccount = addonAccountRepository.findByCustomerNatalId(accountNo);
		AccountBalance accountBlance = accountBalanceRepository.findByAddonAccount(addonAccount);
		if(accountBlance == null) {
			throw new SweepInOutException("APB_SWI_001", "Customer Not Register In Suryoday");
		}
		BigDecimal amnt = CommonUtil.roundOff(amount);
		if(accountBlance.getBalanceAmount().compareTo(amnt) < 0) {
			throw new LowBlanceException();
		}
		return addonAccount;
	}
	
	public boolean checkForRecordDublicationRefrence(String ref) {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository.findByRefrenceNumber(ref);
		return suryodaySweepTxnDetails == null ? true : false;
	}
	
	
	public Response sweepinSuryodayIFTValidationError(String res, SuryodaySweepTxnDetails details, boolean expThrow) {
		try {
			log.info("[ValidationHelper.sweepinSuryodayIFTValidationError] | sweepinSuryodayIFTValidation start {}",res);
			if(res == null) {
				return null;
			}
			// SSFB Exceptional case
			SuryodayIFTException ex = CommonUtil.convertToObjectFromXMLInJAXB(res, SuryodayIFTException.class);
			if(ex != null && ex.getErrorCode() != null) {
				// Transaction Marked failed
				dbAuditingHelper.suryodayFundTransferFailure(details, ex.getErrorMessage());
				if(expThrow) {
					//Depending on error scenario throw SweepInOutException
					doErrorHandling(ex.getErrorCode(), ex.getErrorMessage());
				}
			}
			log.info("return data");
			return  CommonUtil.convertToObjectFromXMLInJAXB(res, Response.class);
		} catch (JAXBException | XMLStreamException e) {
			log.error("Unable to parse the data {}",e);
			//db auditing
			throw new GenericException();
		} catch (SweepInOutException e) {
			log.error("Unable to parse the data {}",e);
			throw e;
		} catch (Exception e) {
			log.error("Unable to parse the data {}",e);
			throw new GenericException();
		}
	}
	
	public SuryodayIFTException suryodayFTValidation(String res) {
		try {
			SuryodayIFTException ex = CommonUtil.convertToObjectFromXMLInJAXB(res, SuryodayIFTException.class);
			if(ex != null && ex.getErrorCode() != null) {
				if("1515".equals(ex.getErrorCode())) {
					return ex;
				}
			}
		} catch (Exception e) {
			
		}
		return  null;
	}
	
	private void doErrorHandling(String code, String msg) {
		errorHandler.sweepInOutErrorHandler(code, msg);
	}
	
	public <T> void printTopicMeta(ConsumerRecord<String, T> payLoad) {
		log.info("Inside Consumer:: data: {}", payLoad.key(), payLoad.topic(),
				payLoad.partition(), payLoad.offset(),payLoad);

	}
	
}
