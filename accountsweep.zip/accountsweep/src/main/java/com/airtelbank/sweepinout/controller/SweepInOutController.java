package com.airtelbank.sweepinout.controller;

import java.util.Calendar;
import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Before;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.airtelbank.sweepinout.service.SweepInOutService;
import com.airtelbank.sweepinout.utils.KafkaProducer;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1/extraccount/transfer")
@CrossOrigin
public class SweepInOutController {

	@Autowired
	private SweepInOutService sweepInOutService;
	
	@Autowired
	private KafkaProducer kafkaProducer;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private SmsUtil smsUtil;
	
	/**
	 * @param <T>
	 * @param amhiRequest
	 * @return
	 */

	@PostMapping(value = "/sweepIn", produces = "application/json")
	@ApiOperation(value = "This service will provide status of a sweep in api", response = SweepInOutController.class)
	public ResponseEntity<?> sweepin(@Valid @RequestBody SweepInAccountRequest request) {
		MDC.put("contentId", UUID.randomUUID().toString());
		ResponseDTO<?> res = sweepInOutService.sweepInRequest(request);
		if (res == null) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
		return ResponseEntity.ok().body(res);
	}
	
	@PostMapping(value = "/tokenMoney", produces = "application/json")
	@ApiOperation(value = "This service will provide status of a sweep in api", response = SweepInOutController.class)
	public ResponseEntity<?> tokenMoney(@Valid @RequestBody SweepInAccountRequest request) {
		SweepInOutTokenMoneyRequest moneyRequest = new SweepInOutTokenMoneyRequest();
		moneyRequest.setAmount(Double.valueOf(request.getAmount()));
		moneyRequest.setCodCustNatlNo(request.getAccountNo());
		moneyRequest.setCustomerSyordayaAccount(request.getRetailerNo());
		moneyRequest.setRefrenceNumber(request.getPaymentRefId());
		moneyRequest.setValueDate(Calendar.getInstance());
		kafkaProducer.pushOnKafka(moneyRequest, env.getProperty("sweepout.token.money.topic.name"));
		return ResponseEntity.ok().body(null);
	}
	
	@PostMapping(value = "/sweepOut", produces = "application/json")
	@ApiOperation(value = "This service will provide status of a sweep in api", response = SweepInOutController.class)
	public ResponseEntity<?> sweepOut(@Valid @RequestBody SweepInAccountRequest request) {
		
		//smsUtil.sendEmail();
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos(request.getPaymentRefId());
		Before after = new Before();
		after.setAmtAutoSwp(request.getAmount());
		after.setCodCustId(request.getRetailerNo());
		after.setCodAcctNo(request.getAccountNo());
		after.setDatAutoSwp(request.getSourceId());
		autoSwpAmtXferLog.setAfter(after);
		sweepInOutService.sweepOutSuroydayFT(autoSwpAmtXferLog);;
		return ResponseEntity.ok().body(null);
		//kafkaProducer.pushOnKafka(autoSwpAmtXferLog, env.getProperty("sweepout.suryoday.ft.topic.name"));
		
		//return ResponseEntity.ok().body(null);
	}
	
	@PostMapping(value = "/recon/sweepIn/", produces = "application/json")
	@ApiOperation(value = "This service will provide recon of sweepin api", response = SweepInOutController.class)
	public ResponseEntity<?> reconSweepIn(@Valid @RequestBody SweepInReconRequest sweepInReconRequest) throws JsonProcessingException {
		ResponseDTO<?> response = sweepInOutService.reconSweepInRequest(sweepInReconRequest);
		if (null == response) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
		return ResponseEntity.ok().body(response);
	}
	
	@PostMapping(value = "/recon/sweepIn", produces = "application/json")
	@ApiResponses(value = {
			@ApiResponse(code = 500, message = "Something went wrong, please try again later."),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 503, message = "Something went wrong, please try again later."),
			@ApiResponse(code = 200, message = "Recon for given request is completed.")})
	@ApiOperation(value = "This service will provide recon of sweepin api", response = SweepInOutController.class)
	public ResponseEntity<?> reconSweepInRequest(@Valid @RequestBody ReconRequest sweepInReconRequest) throws JsonProcessingException {
		ResponseDTO<?> response = sweepInOutService.reconSweepInRequest(sweepInReconRequest);
		
		if (null == response) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
		return ResponseEntity.ok().body(response);
	}
	
	
}