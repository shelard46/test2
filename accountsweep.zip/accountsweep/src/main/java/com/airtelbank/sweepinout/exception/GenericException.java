package com.airtelbank.sweepinout.exception;

import com.airtelbank.sweepinout.dto.ResultDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
@Setter
public class GenericException extends RuntimeException{
	protected ResultDTO meta;
	protected String errorCode;
	protected String errorMessage;
	
	public GenericException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;	
	}
}
