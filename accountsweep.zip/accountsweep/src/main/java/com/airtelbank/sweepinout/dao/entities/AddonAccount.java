package com.airtelbank.sweepinout.dao.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class AddonAccount.
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "AOA_ADDON_ACCOUNT")
@SequenceGenerator(name = "addonAccountSequence", sequenceName = "ADDON_ACCOUNT_SEQUENCE", allocationSize = 50, initialValue = 1)
public class AddonAccount extends AuditableEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1059822389732706440L;

	/** The id. */
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	@GeneratedValue(generator = "addonAccountSequence")
	private Long id;

	/** The customer natal id. */
	@Column(name = "COD_CUST_NATL_ID", length = 50)
	private String customerNatalId;

	/** The customer id. */
	@Column(name = "COD_CUST_ID", length = 50)
	private String customerId;

	/** The airtel acount number. */
	@Column(name = "AIRTEL_ACC_NUMBER", length = 50)
	private String airtelAcountNumber;

	/** The account type. */
	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "ACCOUNT_TYPE")
	private AddonAccountType accountType;

	/** The account provider. */
	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "ACCOUNT_PROVIDER")
	private AccountProvider accountProvider;

	/** The account status. */
	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "ACCOUNT_STATUS")
	private AccountStatus accountStatus;

	/** The account CIF number. */
	@Column(name = "CIF_NUMBER", length = 50)
	private String accountCIFNumber;

	/** The addon account number. */
	@Column(name = "ADDON_ACCOUNT_NUMBER", length = 50)
	private String accountNumber;

	/** The additional details. */
	@OneToMany(mappedBy = "addonAccount", cascade = CascadeType.ALL)
	private List<AccountAdditionalDetail> additionalDetails = new ArrayList<>();

	/** The account balance. */
	@OneToOne(mappedBy = "addonAccount", cascade = CascadeType.ALL)
	private AccountBalance accountBalance;

	/** The cbs updated. */
	@Column(name = "CBS_FLAG_UPDATED")
	private Boolean cbsUpdated;

	/** The last referrence number. */
	@Column(name = "LAST_REF_NUMBER")
	private String lastReferrenceNumber;

	/** The cif created. */
	@Column(name = "NEW_CIF_CREATED")
	private Boolean cifCreated;
}
