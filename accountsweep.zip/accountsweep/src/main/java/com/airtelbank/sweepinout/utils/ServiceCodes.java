package com.airtelbank.sweepinout.utils;

public enum ServiceCodes {

    //Customer Profile
    CUSTOMER_PROFILE,

    //Consent
    CONSENT,

    //P2.0
    PAYMENT2_0_ENQUIRY,


    //Fund Transfer
    FUND_TRANSFER

}
