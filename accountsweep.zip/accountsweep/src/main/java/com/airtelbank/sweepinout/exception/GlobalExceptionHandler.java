package com.airtelbank.sweepinout.exception;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.utils.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	private MessageSource messageSource;
	
	@Value("${upper.sweepIn.limit}")
	private String upperSweepInLimit;
	

	@SuppressWarnings("unchecked")
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String errorCode = messageSource.getMessage("code.suryoday.invalid.min.amount", null, null);
		String errorMessage = null;
		for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
			errorMessage = fieldError.getDefaultMessage();
		}
		return (ResponseEntity<Object>) createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { SweepInOutException.class })
	protected ResponseEntity<?> handleSweepInOutException(SweepInOutException ex) {
		String errorCode = ex.getErrorCode();
		String errorMessage = ex.getErrorMessage();
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}

	@ExceptionHandler(value = { LowBlanceException.class })
	protected ResponseEntity<?> handleLowBlanceException(LowBlanceException ex) {
		String errorCode = messageSource.getMessage("code.suryoday.insufficient.fund", null, null);
		String errorMessage = messageSource.getMessage("code.suryoday.insufficient.fund.desc", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { Exception.class })
	protected ResponseEntity<?> handleAllUnhandledException(Exception ex) {
		logger.error("Inside Global Exception Handler. Exception caught is {}", ex);
		String errorCode = messageSource.getMessage(Constants.GENERIC_ERROR_CODE, null, null);
		String errorMessage = messageSource.getMessage(Constants.GENERIC_ERROR_MESSAGE, null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@SuppressWarnings("unchecked")
	protected ResponseEntity<Object> handleMethodHttpMessageNotReadableException(HttpMessageNotReadableException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		String errorCode = messageSource.getMessage("config.generic.errorCode", null, null);

		String errorMessage = ex.getMessage();

		return (ResponseEntity<Object>) createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@SuppressWarnings("unchecked")
	protected ResponseEntity<Object> handleMethodJsonProcessingException(JsonProcessingException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		String errorCode = messageSource.getMessage("config.generic.errorCode", null, null);

		String errorMessage = ex.getOriginalMessage();

		return (ResponseEntity<Object>) createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@SuppressWarnings("unchecked")
	protected ResponseEntity<Object> handleMethodInvalidFormatException(InvalidFormatException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		String errorCode = messageSource.getMessage("config.generic.errorCode", null, null);
		String errorMessage = ex.getMessage();
		return (ResponseEntity<Object>) createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { DatabaseException.class })
	protected ResponseEntity<?> handleDatabaseException(DatabaseException ex) {
		String errorCode = messageSource.getMessage("config.database.exception.errorCode", null, null);
		String errorMessage = messageSource.getMessage("config.database.exception.errorMessage", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = { GenericException.class })
	protected ResponseEntity<?> genericExceptionHandler(GenericException ex) {
		String errorCode = messageSource.getMessage("config.generic.errorCode", null, null);
		String errorMessage = messageSource.getMessage("config.generic.errorMessage", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = { InvalidCustomerException.class })
	protected ResponseEntity<?> handleInvalidCustomerException(InvalidCustomerException ex) {
		String errorCode = messageSource.getMessage("code.suryoday.invalid.customer", null, null);
		String errorMessage = messageSource.getMessage("code.suryoday.invalid.customer.desc", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}

	private ResponseEntity<?> createErrorResponse(String code, String description, HttpStatus status) {
		log.info("code="+code);
		ResponseDTO<?> response = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
		meta.setCode(code);
		meta.setDescription(description);
		meta.setStatus(Constants.REQUEST_FAIL);
		response.setMeta(meta);
		return ResponseEntity.status(status).body(response);
	}

	@ExceptionHandler(value = { InvalidRequestException.class })
	protected ResponseEntity<?> communicationExceptionHandler(InvalidRequestException ex) {
		return createErrorResponse(ex.getErrorCode(), ex.getErrorMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = { DuplicateDataException.class })
	protected ResponseEntity<?> handleDuplicateDataException(DuplicateDataException ex) {
		String errorCode = messageSource.getMessage("config.duplicate.data.errorCode", null, null);
		String errorMessage = messageSource.getMessage("config.duplicate.data.errorMessage", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = { InsuranceException.class })
	protected ResponseEntity<?> handleConflict(InsuranceException ex) {
		return ResponseEntity.status(ex.httpStatus).body(ex.getResponseDTO());
	}
	
	@ExceptionHandler(value = { CustomerSavingsAccountNotExistException.class })
	protected ResponseEntity<?> handleCustomerValidationException(CustomerSavingsAccountNotExistException ex) {
		String errorCode = messageSource.getMessage("config.customer.nonAPB.customerapp.errorCode", null, null);
		String errorMessage = messageSource.getMessage("config.customer.nonAPB.customerapp.errorMessage", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { NegativeAmountException.class })
	protected ResponseEntity<?> handleNegativeAmountException(NegativeAmountException ex) {
		String errorCode = messageSource.getMessage("code.suryoday.negative.amount", null, null);
		String errorMessage = messageSource.getMessage("code.suryoday.negative.amount.desc", null, null);
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { UpperLimitBreachException.class })
	protected ResponseEntity<?> handleUpperLimitException(UpperLimitBreachException ex) {
		Object[] args = new Object[] {upperSweepInLimit};
		String errorCode = messageSource.getMessage("code.suryoday.upper.limit.error", null, null);
		String errorMessage = messageSource.getMessage("code.suryoday.upper.limit.desc", args, new Locale("en"));
		return createErrorResponse(errorCode, errorMessage, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = { CustomerValidationException.class })
	protected ResponseEntity<?> handleCustomerValidationException(CustomerValidationException ex) {
		return createErrorResponse(ex.getErrorCode(), ex.getErrorMessage(), HttpStatus.OK);
	}

}
