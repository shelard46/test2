package com.airtelbank.sweepinout.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.airtelbank.sweepinout.dao.entities.AccountBalance;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.exception.CustomerSavingsAccountNotExistException;
import com.airtelbank.sweepinout.exception.CustomerValidationException;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.models.AccountResponse;
import com.airtelbank.sweepinout.models.Customer;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.RestRequest;
import com.airtelbank.sweepinout.service.PaymentService;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.ErrorHandling;
import com.airtelbank.sweepinout.utils.HttpUtils;
import com.airtelbank.sweepinout.utils.RequestCreationUtil;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.airtelbank.sweepinout.utils.StageCodes;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RefreshScope
public class PaymentServiceImplHelper {

	@Autowired
	private DbAuditingHelper dbAuditingHelper;

	@Autowired
	private PaymentService paymentService;

	@Autowired
	private SmsUtil smsUtil;

	@Value(value = "${customer.profile.query.param}")
	private String customerProfileQueryParam;

	@Value(value = "${customer.profile.url}")
	private String customerProfileEndPoint;

	@Value("#{'${customer.app.channel}'.split(',')}")
	private List<String> customerAppChannel;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private HttpUtils httpUtil;

	@Autowired
	private ErrorHandling errorHandler;

	@Value(value = "#{'${apy.customer.account.blocked.list}'.split(',')}")
	private List<String> blockedAccountList;

	public SuryodaySweepTxnDetails sweepInHelper(Response response, SuryodaySweepTxnDetails details) {
		if (Constants.REQUEST_SUCCESS_STRING.equals(response.getTransactionStatus().getErrorCode())) {
			log.debug("Suryoday FT Success");
			details = dbAuditingHelper.updateSuryodaySweepInStatus(details, response.getTransactionRefNumber(), StageCodes.SUCCESSFUL.toString());
			AccountBalance accountBalance = dbAuditingHelper.updateSurodayAccountBlance(details);
			paymentService.internalFundTransferSweepIn(details);
		} else if (Constants.REQUEST_FAIL_STRING.equals(response.getTransactionStatus().getErrorCode())) {
			log.error("Suryoday FT Fail");
			details = dbAuditingHelper.updateSuryodaySweepInStatus(details, response.getTransactionRefNumber(), StageCodes.FAILED.toString());
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(Constants.CUSTOMER_MSISDN, details.getAmount());
			map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_FAIL);
			map.put(Constants.SURYODAY_ACCOUNT_NO, details.getAccountNumber());
			map.put(Constants.SMS_NUMBER, details.getAddonAccount().getAirtelAcountNumber());
			if(Constants.CUR_ACCOUNT_TYPE.toUpperCase().equals(MDC.get(Constants.CUST_TYPE))) {
				map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
				map.put(Constants.CUSTOMER_MSISDN, details.getAmount());
			}
			else {
				map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
			}
			smsUtil.sendSMSToUser(map);
		} else {
			// send msg for wait and enquery.
		}
		return null;
	}

	public SuryodaySweepTxnDetails sweepOutFinalAudit(Response response, SuryodaySweepTxnDetails details) {
		if (Constants.REQUEST_SUCCESS_STRING.equals(response.getTransactionStatus().getErrorCode())) {
			log.debug("Success");
			details = dbAuditingHelper.updateSuryodaySuccessSweepOut(details, response);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(Constants.CUSTOMER_MSISDN, CommonUtil.lastNum(details.getAddonAccount().getAirtelAcountNumber()));
			map.put(Constants.SMS_NUMBER, details.getAddonAccount().getAirtelAcountNumber());
			if(details.getFlow().equalsIgnoreCase(Constants.TOKENMONEY))
				map.put(Constants.SMS, Constants.TOKENMONEY_SUCCESS);
			else
				map.put(Constants.SMS, Constants.SWEEPOUT_SUCCESS);

			map.put(Constants.BALANCE, details.getAmount().toString());
			map.put(Constants.SURYODAY_BLANCE, details.getSuryodayBln());
			map.put(Constants.APB_TXN_ID, details.getApbTxnId());
			map.put(Constants.TXN_AMOUNT, details.getAmount().toString());
			log.info("Cutomer Type : {}",MDC.get(Constants.CUST_TYPE));
			if(Constants.CUR_ACCOUNT_TYPE.equalsIgnoreCase(MDC.get(Constants.CUST_TYPE))) {
				map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
			}
			else {
				map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
			}
			log.info("[PaymentServiceImplHelper.sweepOutFinalAudit] SMS MAP :: {}",map);
			smsUtil.sendSMSToUser(map);
		} else if (Constants.REQUEST_FAIL_STRING.equals(response.getTransactionStatus().getErrorCode())) {
			log.debug("Fail");
			// Db auditing for fail
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(Constants.CUSTOMER_MSISDN, details.getAmount());
			map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_FAIL.toString());
			map.put(Constants.SURYODAY_ACCOUNT_NO, details.getAccountNumber());
			map.put(Constants.SMS_NUMBER, details.getAddonAccount().getAirtelAcountNumber());
			if(Constants.CUR_ACCOUNT_TYPE.equalsIgnoreCase(MDC.get(Constants.CUST_TYPE))) {
				map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
			}
			else {
				map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
			}
			smsUtil.sendSMSToUser(map);
		} else {
			// send msg for wait and enquery.
		}
		return null;
	}

	public Customer getCustomerProfile(final String customerId, String contentId, String channel,String airtelAccountNumber) {
		ResponseEntity<ResponseDTO<Customer>> responseEntity = null;
		Customer customer = null;
		MultiValueMap<String, String> headers = new HttpHeaders();
		headers.add(Constants.CONTENTID, contentId);
		headers.add(Constants.CHANNEL, channel);

		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
		queryParams.add(customerProfileQueryParam, String.valueOf(true));

		Map<String, Object> params = new HashMap<>();
		params.put("customerId", customerId);
		RestRequest<Customer> request = RequestCreationUtil.createRestRequest(customerProfileEndPoint, HttpMethod.GET,
				null, Customer.class, params, headers, queryParams);

		responseEntity = httpUtil.sendHttpRequest(request);
		List<AccountResponse> accountList = responseEntity.getBody().getData().getAccountList();
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK
				&& responseEntity.getBody() != null) {
			ResponseDTO<Customer> response = responseEntity.getBody();
			ResultDTO meta = response.getMeta();
			if (meta != null) {
				if (meta.getStatus() == 0) {
					customer = response.getData();
					checkAccountStatus(customer, channel, accountList, airtelAccountNumber);
				} else {
					log.error("Get customer request fails!! {}", meta);
					if (customerAppChannel.contains(channel.toUpperCase())) {
						String errorCode = messageSource.getMessage("config.customer.nonAPB.customerapp.errorCode",
								null, null);
						String errorMessage = messageSource
								.getMessage("config.customer.nonAPB.customerapp.errorMessage", null, null);
						throw new CustomerSavingsAccountNotExistException(errorCode, errorMessage);
					} else {
						errorHandler.customerErrorHandler(meta);
					}
				}
			}
		}
		return customer;
	}

	private void checkAccountStatus(Customer customer, String channel, List<AccountResponse> accountList,
			String airtelAccountNumber) {
		getAccountsDetails(customer, accountList, airtelAccountNumber);
		if (!(Constants.SBA_ACCOUNT_TYPE.equalsIgnoreCase(customer.getCustomerType()) || Constants.CUR_ACCOUNT_TYPE.equalsIgnoreCase(customer.getCustomerType()))) {
			if (customerAppChannel.contains(channel.toUpperCase())) {
				log.info("In Nor SBA Neither current  from CustomerServiceImpl");
				String errorCode = messageSource.getMessage("config.customer.notSBA.notCUR.customerapp.errorCode", null, null);
				String errorMessage = messageSource.getMessage("config.customer.notSBA.notCUR.customerapp.errorMessage", null,
						null);
				throw new CustomerValidationException(errorCode, errorMessage);
			} else {
				throw new CustomerValidationException();
			}
		}
		else {
			MDC.put(Constants.CUST_TYPE, customer.getCustomerType().toUpperCase()); 
		}
	}

	public AccountResponse getAccountsDetails(Customer customer, List<AccountResponse> accountList, String airtelAccountNumber) {
		String accountStatus = null;
		for (AccountResponse account : accountList) {
			accountStatus = account.getAccountNumber().equalsIgnoreCase(airtelAccountNumber) ? account.getStatus() : "";
			if (Constants.REGULAR.equalsIgnoreCase(accountStatus)
					|| Constants.OPENED_TODAY.equalsIgnoreCase(accountStatus)) {
				return account;
			}
		}
		throw new CustomerValidationException(
				messageSource.getMessage("code.suryoday.invalid.account.type", null, null),
				messageSource.getMessage("code.suryoday.invalid.account.type.desc", null, null));
	}

}