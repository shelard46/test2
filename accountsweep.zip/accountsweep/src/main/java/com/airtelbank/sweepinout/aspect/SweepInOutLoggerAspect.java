package com.airtelbank.sweepinout.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.SweepInOutUtil;

@Aspect
@Configuration
@RefreshScope
public class SweepInOutLoggerAspect {

	@Value(value = "${sweepinout.serviceId}")
	private String serviceId;

	@Value(value = "${sweepinout.apId}")
	private String apId;

	@Before(value = "execution(* com.airtelbank.sweepinout.controller.SweepInOutController.*(..))")
	public void checkEncryptionHeader(JoinPoint joinPoint) {
		try {
			joinPoint.getSignature().getName();
			if ("sweepInRequest".equalsIgnoreCase(joinPoint.getSignature().getName())) {
				sweepInRequestUserDetailsLogger(joinPoint);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	private void sweepInRequestUserDetailsLogger(JoinPoint joinPoint) {
		SweepInAccountRequest request = (SweepInAccountRequest) joinPoint.getArgs()[0];
		SweepInOutUtil.kibanaPreProcess(serviceId, apId, String.valueOf(request.getAccountNo()), 0,
				Constants.SWEEP_IN_PURPOSE_CODE);
	}
	 

}
