package com.airtelbank.sweepinout.helper;

import java.math.BigDecimal;
import java.util.Calendar;

import com.airtelbank.sweepinout.exception.InvalidRequestException;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.AccountBalanceRepository;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.InvalidCustomerException;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.StageCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * To Audit AMHI Request
 *
 */

@Slf4j
@Component
@RefreshScope
public class DbAuditingHelper {
	
	
	@Autowired
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;
	
	@Autowired
	private AddonAccountRepository addonAccountRepository;
	
	@Autowired
	private AccountBalanceRepository accountBalanceRepository;
	
	@Autowired
	private KibanaErrorLogger kibanaLogger;
	
	@Autowired
	private Environment env;

	@Autowired
	MessageSource messageSource;
	
	@Transactional
	public SuryodaySweepTxnDetails tokenMoneySweepOutDbAuditing(SweepInOutTokenMoneyRequest request, String transactionType) {
		AddonAccount addonAccount = addonAccountRepository.findByAccountNumber(request.getCustomerSyordayaAccount());
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAccountNumber(request.getCustomerSyordayaAccount());
		suryodaySweepTxnDetails.setChannel("RAPP");
		suryodaySweepTxnDetails.setAmount(BigDecimal.valueOf(request.getAmount()).setScale(2, BigDecimal.ROUND_HALF_EVEN));
		suryodaySweepTxnDetails.setTransactionType(transactionType);
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		suryodaySweepTxnDetails.setRefrenceNumber(request.getRefrenceNumber());
		suryodaySweepTxnDetails.setCurrentStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setApbStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setSuryodayStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setFlow(StageCodes.TOKENMONEY.toString());
		suryodaySweepTxnDetails.setValueDate(Calendar.getInstance());
		suryodaySweepTxnDetails.setCreatedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
		return suryodaySweepTxnDetails;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails internalFundTransferDbAuditing(SuryodaySweepTxnDetails details) {
		details.setCurrentStatus(StageCodes.INITIATED.toString());
		details.setApbStatus(StageCodes.INITIATED.toString());
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails SuryodayFundTransferBeforDbAuditing(SuryodaySweepTxnDetails details) {
		details.setCurrentStatus(StageCodes.INITIATED.toString());
		details.setSuryodayStatus(StageCodes.INITIATED.toString());
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails internalFundTransferSuccess(SuryodaySweepTxnDetails details, String tranRefNo) {
		log.info("fundTransferSuccess Start {}",details);
		details.setCurrentStatus(StageCodes.SUCCESSFUL.toString());
		details.setApbStatus(StageCodes.SUCCESSFUL.toString());
		details.setApbTxnId(tranRefNo);
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails finalSuccessAudit(SuryodaySweepTxnDetails details, String tranRefNo) {
		log.info("fundTransferSuccess Start {}",details);
		details.setCurrentStatus(StageCodes.SUCCESSFUL.toString());
		details.setApbStatus(StageCodes.SUCCESSFUL.toString());
		details.setApbTxnId(tranRefNo);
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails internalFundTransferFailure(SuryodaySweepTxnDetails details, String failReason, String tranRefNo) {
		log.info("fundTransferFailure Start {}",details);
		details.setCurrentStatus(StageCodes.FAILED.toString());
		details.setApbStatus(StageCodes.FAILED.toString());
		details.setFailedReason(failReason);
		details.setApbTxnId(tranRefNo);
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails suryodayFundTransferFailure(SuryodaySweepTxnDetails details, String failReason) {
		log.info("suryodayFundTransferFailure {}",details);
		details.setCurrentStatus(StageCodes.FAILED.toString());
		details.setSuryodayStatus(StageCodes.FAILED.toString());
		details.setFailedReason(failReason);
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails sweepOutSuryodayFT(AutoSwpAmtXferLog amtXferLog, String transactionType) {
		
		log.info("[DbAuditingHelper.sweepOutSuryodayFT] | AutoSwpAmtXferLog :: {} ",amtXferLog);
		// Changes to support different custTypes
		if(amtXferLog.getAfter() == null || amtXferLog.getAfter().getFlgCustTyp()==null || amtXferLog.getAfter().getFlgCustTyp().isEmpty()){
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.INVALID_AFTER_OBJECT);
			log.error("cust type is null or empty::{}",amtXferLog.getAfter().getFlgCustTyp());
			throw new InvalidRequestException(messageSource.getMessage("invalid.after.object.errorCode", null, null),
					messageSource.getMessage("invalid.after.object.errorMessage", null, null));
		}
		log.info("[DbAuditingHelper.sweepOutSuryodayFT] | AutoSwpAmtXferLog.getCustType :: {} ",amtXferLog.getAfter().getFlgCustTyp());
		String custType = amtXferLog.getAfter().getFlgCustTyp();

		MDC.put(Constants.CUST_TYPE, custType.toUpperCase());
		
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository.findByApbTxnId(amtXferLog.getPos());
		if(suryodaySweepTxnDetails != null) {
			return suryodaySweepTxnDetails;
		}
		suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		AddonAccount addonAccount = addonAccountRepository.findByAirtelAcountNumber(amtXferLog.getAfter() == null ? amtXferLog.getBefore().getCodAcctNo().trim() : amtXferLog.getAfter().getCodAcctNo().trim());
		if(addonAccount == null) {
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.INVALID_ACCOUNT);
		}
		suryodaySweepTxnDetails.setAccountNumber(addonAccount.getAccountNumber());
		BigDecimal amount = amtXferLog.getAfter() == null ? BigDecimal.valueOf(Double.valueOf(amtXferLog.getBefore().getAmtAutoSwp())) : BigDecimal.valueOf(Double.valueOf(amtXferLog.getAfter().getAmtAutoSwp()));
		suryodaySweepTxnDetails.setAmount(amount);
		suryodaySweepTxnDetails.setTransactionType(transactionType);
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		suryodaySweepTxnDetails.setCurrentStatus(StageCodes.SUCCESSFUL.toString());
		suryodaySweepTxnDetails.setApbStatus(StageCodes.SUCCESSFUL.toString());
		suryodaySweepTxnDetails.setSuryodayStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setFlow(StageCodes.SWEEPOUT.toString());
		suryodaySweepTxnDetails.setApbTxnId(amtXferLog.getPos());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setRefrenceNumber("APBSO"+CommonUtil.genrateRefrenceNumber());
		Calendar cal = Calendar.getInstance();
		cal.setTime(CommonUtil.StringToDate(amtXferLog.getAfter() == null ? amtXferLog.getBefore().getDatAutoSwp() : amtXferLog.getAfter().getDatAutoSwp(), env.getProperty("cbs.date.formate")));
		suryodaySweepTxnDetails.setCreatedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setValueDate(cal);
		suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
		return suryodaySweepTxnDetails;
	}

	@Transactional
	public AccountBalance updateSurodayAccountBlance(SuryodaySweepTxnDetails details) {
		log.info("updateSurodayAccountBlance call {}",details);
		AccountBalance accountBlance = accountBalanceRepository.findByAddonAccount(details.getAddonAccount());
		if (accountBlance == null) {
			accountBlance = new AccountBalance();
			accountBlance.setAddonAccount(details.getAddonAccount());
			accountBlance.setAccountNumber(details.getAddonAccount().getAccountNumber());
			accountBlance.setCustomerId(details.getAddonAccount().getCustomerId());
			accountBlance.setCustomerNatalId(details.getAddonAccount().getCustomerNatalId());
		}
		if (details.getTransactionType().equalsIgnoreCase(Constants.TRANSACTION_DR)) {
			BigDecimal balanceAmount = accountBlance.getBalanceAmount() == null ? BigDecimal.ZERO : accountBlance.getBalanceAmount();
			accountBlance.setPreviousBalance(balanceAmount);
			accountBlance.setBalanceAmount(balanceAmount.add(details.getAmount()));
			accountBalanceRepository.save(accountBlance);
		}
		if (details.getTransactionType().equalsIgnoreCase(Constants.TRANSACTION_CR)) {
			BigDecimal balanceAmount = accountBlance.getBalanceAmount() == null ? BigDecimal.ZERO : accountBlance.getBalanceAmount();
			accountBlance.setPreviousBalance(balanceAmount);
			if (balanceAmount.compareTo(details.getAmount()) != 0 && balanceAmount.compareTo(details.getAmount()) < 0) {
				throw new GenericException();
			} else {
				accountBlance.setBalanceAmount(balanceAmount.subtract(details.getAmount()));
				accountBalanceRepository.save(accountBlance);
			}
		}
		accountBalanceRepository.flush();
		return accountBlance;
	}

	@Transactional
	public SuryodaySweepTxnDetails preAuditingSweepIn(SweepInAccountRequest sweepInAccountRequest) {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		AddonAccount addonAccount = addonAccountRepository.findByCustomerNatalId(sweepInAccountRequest.getAccountNo());
		if(addonAccount == null) {
			log.error("customer is not registered for add on account");
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidCustomerException();
		}
		suryodaySweepTxnDetails.setAmount(CommonUtil.roundOff(sweepInAccountRequest.getAmount()));
		suryodaySweepTxnDetails.setAccountNumber(addonAccount.getAccountNumber());
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		suryodaySweepTxnDetails.setChannel(sweepInAccountRequest.getChannel());
		suryodaySweepTxnDetails.setCreatedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setApbStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setRefrenceNumber(sweepInAccountRequest.getPaymentRefId());
		suryodaySweepTxnDetails.setSuryodayStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setCurrentStatus(StageCodes.TO_BE_INITIATED.toString());
		suryodaySweepTxnDetails.setFlow(StageCodes.SWEEPIN.toString());
		suryodaySweepTxnDetails.setTransactionType(Constants.TRANSACTION_CR);
		suryodaySweepTxnDetails.setValueDate(Calendar.getInstance());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
		return suryodaySweepTxnDetails;
	}

	@Transactional
	public SuryodaySweepTxnDetails updateSuryodaySweepInStatus(SuryodaySweepTxnDetails details, String refNum, String ststus) {
		details.setSuryodayStatus(ststus);
		String [] str = refNum.split("~");
		details.setSuryodayTrnRefNo(str[0]);
		if(str.length > 1)
			details.setSuryodayBln(str[1]);
		details.setCurrentStatus(ststus);
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public void updateSuryodayRetryStatus(SuryodaySweepTxnDetails details) {
		details.setSuryodayStatus(StageCodes.RETRY.toString());
		details.setRetryCount(details.getRetryCount() + 1);
		suryodaySweepTxnDetailsRepository.save(details);
	}
	
	@Transactional
	public void updateInternalPayRetryStatus(SuryodaySweepTxnDetails details) {
		details.setApbStatus(StageCodes.RETRY.toString());
		details.setRetryCount(details.getRetryCount() + 1);
		suryodaySweepTxnDetailsRepository.save(details);
	}
	
	@Transactional
	public SuryodaySweepTxnDetails updateSuryodaySuccessSweepOut(SuryodaySweepTxnDetails details, Response response) {
		details.setSuryodayStatus(StageCodes.SUCCESSFUL.toString());
		String [] str = response.getTransactionRefNumber().split("~");
		details.setSuryodayTrnRefNo(str[0]);
		if(str.length > 1)
			details.setSuryodayBln(str[1]);
		details.setCurrentStatus(StageCodes.SUCCESSFUL.toString());
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails updateFtRefrenceNumber(SuryodaySweepTxnDetails details, String num) {
		details.setApbTxnId(num);
		details.setModifiedOn(Calendar.getInstance());
		return suryodaySweepTxnDetailsRepository.save(details);
	}
	
	@Transactional
	public void updateAPBStatus(SuryodaySweepTxnDetails details, String status) {
		details.setApbStatus(status);
		details.setModifiedOn(Calendar.getInstance());
		details.setCurrentStatus(status);
		suryodaySweepTxnDetailsRepository.save(details);
	}
	
	@Transactional
	public SuryodaySweepTxnDetails SuccessAuditingReconSweepIn(SweepInReconRequest sweepInReconRequest, SuryodaySweepTxnDetails suryodaySweepTxnDetails) {
		log.info("preAuditingSweepIn start {}",sweepInReconRequest);
		AddonAccount addonAccount = addonAccountRepository.findByAirtelAcountNumber(sweepInReconRequest.getCustomerAccountNo());
		if(addonAccount == null) {
			log.error("customer is not registered for add on account");
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidCustomerException();
		}
		String status = sweepInReconRequest.getStatus();
		if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(status)) {
			suryodaySweepTxnDetails.setApbTxnId(sweepInReconRequest.getAirtelTransactionId());
		}  else if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(status) && null==sweepInReconRequest.getAirtelTransactionId()) {
			 suryodaySweepTxnDetails.setFailedReason(Constants.NO_TRANS_ID);
		}  else if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(status) && null!=sweepInReconRequest.getAirtelTransactionId()) {
			 suryodaySweepTxnDetails.setApbTxnId(sweepInReconRequest.getAirtelTransactionId());
		}  else {
			 throw new GenericException(Constants.INVALID_STATUS_CODE, Constants.INVALID_STATUS_DESC);
		}
			
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		log.info("suryodaySweepTxnDetails", suryodaySweepTxnDetails);
		suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
		return suryodaySweepTxnDetails;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails SuccessAuditingReconSweepIn(ReconRequest sweepInReconRequest, SuryodaySweepTxnDetails suryodaySweepTxnDetails) {
		log.info("preAuditingSweepIn starts for SuccessAuditingReconSweepIn with request: {}",sweepInReconRequest);
		AddonAccount addonAccount = addonAccountRepository.findByAirtelAcountNumber(sweepInReconRequest.getCustomerAccountNo());
		if(null == addonAccount) {
			log.error("customer is not registered for add on account");
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidCustomerException();
		}
		String status = sweepInReconRequest.getStatus();
		log.info("status for sweepInReconRequest: {}",status);
		if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
			internalFundTransferFailureForRecon(suryodaySweepTxnDetails, sweepInReconRequest.getAirtelTransactionId());
		}  else if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus()) && null==sweepInReconRequest.getAirtelTransactionId()) {
			suryodayFundTransferFailureForRecon(suryodaySweepTxnDetails); 
		}  else if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
			internalFundTransferFailureForRecon(suryodaySweepTxnDetails, sweepInReconRequest.getAirtelTransactionId());
		}  else if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
			suryodayFundTransferFailureForRecon(suryodaySweepTxnDetails); 
		}  else {
			 throw new GenericException(Constants.INVALID_STATUS_CODE, Constants.INVALID_STATUS_DESC);
		}		
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		log.info("suryodaySweepTxnDetails after setting values in SuccessAuditingReconSweepIn: {}", suryodaySweepTxnDetails);
		suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
		return suryodaySweepTxnDetails;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails internalFundTransferFailureForRecon(SuryodaySweepTxnDetails details, String tranRefNo) {
		log.info("fundTransferFailure Start {}",details);
		details.setCurrentStatus(StageCodes.FAILED.toString());
		details.setApbStatus(StageCodes.FAILED.toString());
		details.setApbTxnId(tranRefNo);
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
	@Transactional
	public SuryodaySweepTxnDetails suryodayFundTransferFailureForRecon(SuryodaySweepTxnDetails details) {
		log.info("suryodayFundTransferFailure {}",details);
		details.setCurrentStatus(StageCodes.FAILED.toString());
		details.setSuryodayStatus(StageCodes.FAILED.toString());
		details.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetailsRepository.save(details);
		return details;
	}
	
}
