package com.airtelbank.sweepinout.dao;

import java.util.Calendar;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;

public interface SuryodaySweepTxnDetailsRepository extends JpaRepository<SuryodaySweepTxnDetails, Long> {

	List<SuryodaySweepTxnDetails> findByAddonAccount(AddonAccount addonAccount);
	SuryodaySweepTxnDetails findByApbTxnId(String apbTxnId);
	SuryodaySweepTxnDetails findByRefrenceNumber(String refrenceNumber);
	SuryodaySweepTxnDetails findByAddonAccountAndFlowAndValueDate(AddonAccount addonAccount, String flow, Calendar valueDate);
}
