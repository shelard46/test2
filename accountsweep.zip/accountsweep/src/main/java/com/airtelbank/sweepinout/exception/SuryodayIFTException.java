package com.airtelbank.sweepinout.exception;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Exception")
@ToString
public class SuryodayIFTException {
	
	private String Response;

    private String StackTrace;

    private String ErrorCode;

    private String ErrorMessage;

    private Reason Reason;
}
