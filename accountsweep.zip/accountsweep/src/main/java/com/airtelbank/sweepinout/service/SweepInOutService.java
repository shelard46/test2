package com.airtelbank.sweepinout.service;

import org.springframework.stereotype.Service;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
/**
 * To save AMHI user details.
 *
 */
@Service
public interface SweepInOutService {
	public ResponseDTO<?> sweepInRequest(SweepInAccountRequest request);
	public void tokenMoneyDebit(SweepInOutTokenMoneyRequest request);
	public void sweepOutSuroydayFT(AutoSwpAmtXferLog request);
	public ResponseDTO<?> reconSweepInRequest(SweepInReconRequest request) throws JsonProcessingException;
	public ResponseDTO<?> reconSweepInRequest(ReconRequest request) throws JsonProcessingException;
}
