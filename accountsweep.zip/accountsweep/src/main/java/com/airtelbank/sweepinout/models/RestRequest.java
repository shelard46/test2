package com.airtelbank.sweepinout.models;

import java.util.Map;

import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RestRequest<T> {
	private String uri;
	private Map<String, Object> params;
	private HttpMethod httpMethod;
	private Class<T> responseClass;
	private MultiValueMap<String, String> headers;
	private MultiValueMap<String, String> queryParams;
	private Object entity;
	@Override
	public String toString() {
		return "RestRequest [" + (uri != null ? "uri=" + uri + ", " : "")
				+ (params != null ? "params=" + params + ", " : "")
				+ (httpMethod != null ? "httpMethod=" + httpMethod + ", " : "")
				+ (responseClass != null ? "responseClass=" + responseClass + ", " : "")
				+ (headers != null ? "headers=" + headers + ", " : "")
				+ (queryParams != null ? "queryParams=" + queryParams + ", " : "")
				+ (entity != null ? "entity=" + entity : "") + "]";
	}
	
	
	
}
