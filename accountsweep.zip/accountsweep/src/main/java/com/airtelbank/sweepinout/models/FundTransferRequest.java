package com.airtelbank.sweepinout.models;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class FundTransferRequest {
	private String sourceId;
	private BigDecimal amount;
	private String txnGroupId;
	private String sourceIpAdd;
	private FromActorDetails fromActorDetails;
	private String paymentMode;
	private String latitude;
	private String channel;
	private String limitDetails;
	private String paymentRefId;
	private DiffParams diffParams;
	private ToActorDetails toActorDetails;
	private String txnCode;
	private String purposeCode;
	private String longitude;
	private String refundPaymentRefId;
	private String reverseSc;
	private OnBehalfDetails onBehalfDetails;
	private AdditionalDetails additionalDetails;
	
	
}