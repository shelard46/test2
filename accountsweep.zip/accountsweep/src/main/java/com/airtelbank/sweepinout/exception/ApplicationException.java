package com.airtelbank.sweepinout.exception;

import com.airtelbank.sweepinout.models.Meta;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class ApplicationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7803878771092932632L;
	
	private String code;
	private Meta meta;
	
	public ApplicationException(String code) {		
		this.code=code;
	}
	
}
