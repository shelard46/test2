package com.airtelbank.sweepinout.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class AutoSwpAmtXferLog {
	
	@JsonProperty("table")
	private String table;
    
	@JsonProperty("op_type")
	private String optype;
	
	@JsonProperty("op_ts")
	private String opts;
	
	@JsonProperty("current_ts")
    private String currentts;
    
	@JsonProperty("pos")
	private String pos;
    
	@JsonProperty("before")
    private Before before;
	
	@JsonProperty("after")
    private Before after;
    
}
