package com.airtelbank.sweepinout.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "input")
@ToString
public class InputForEnquiry {
	
	@XmlElement(name = "SessionContext")
	private SessionContextForEnquiry sessionContext;

	@XmlElement(name = "Operation")
	private String operation;

	@XmlElement(name = "ReferenceNumber")
	private String referenceNumber;
	
	@XmlTransient
	private long suryodayTxnId;
	
	@XmlTransient
	private int retryCount = 0;

}
