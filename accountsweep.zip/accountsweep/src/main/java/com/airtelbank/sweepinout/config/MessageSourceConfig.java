package com.airtelbank.sweepinout.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@Configuration
@RefreshScope
public class MessageSourceConfig {

  @Value("${spring.config.location}")
  private String baseLocation;
 
  @Value("${config.message.properties.name}")
  private String messagePropertiesName;
  
  @Bean
  public MessageSource messageSource() {
	  ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
      messageSource.setBasename("file:" + baseLocation + "/" + messagePropertiesName);
      messageSource.setCacheSeconds(10);
	  return messageSource;
	}  
  
  @Bean
  public LocalValidatorFactoryBean validator() {
      LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
      bean.setValidationMessageSource(messageSource());
      return bean;
  }
}
