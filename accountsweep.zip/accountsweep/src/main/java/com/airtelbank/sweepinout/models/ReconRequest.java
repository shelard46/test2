package com.airtelbank.sweepinout.models;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class ReconRequest {
	
	@NotNull(message = "{sweepInOut.base.response.refrenceNm.errormessage}")
	private String refrenceNo;
	
	private String airtelTransactionId;
	
	@NotNull(message = "{sweepInOut.base.response.customerid.errormessage}")
	private String customerAccountNo;
	
	@NotNull(message = "{sweepInOut.base.response.amount.errormessage}")
	private String amount;
	
	private String status;
	
	private String apbStatus;
	
	private String suryodayStatus;
	
	private String suryodayTxnId;
	
	@NotNull(message = "{sweepInOut.base.response.flow.name.errormessage}")
	private String flowName;
	
}
