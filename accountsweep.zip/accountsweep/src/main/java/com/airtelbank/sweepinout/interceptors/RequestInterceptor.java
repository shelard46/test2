package com.airtelbank.sweepinout.interceptors;

import java.io.IOException;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RequestInterceptor implements ClientHttpRequestInterceptor {
   

   @Override
   public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
         throws IOException {
      long time = System.currentTimeMillis();
      if(body != null) {
         log.info("Request is : {}", new String(body, "UTF-8"));
      }

      log.info("Http Method {}, Request URL {}", request.getMethod().toString(), request.getURI());
      ClientHttpResponse response = execution.execute(request, body);
      time = System.currentTimeMillis() - time;
      log.info("Total time taken by request {}", time);
      if(response != null) {
         log.info("HTTP status code returned is : {}" , response.getStatusCode().toString());
         log.info("Response is : {}", response.getBody());
      }
      return response;
   }
}
