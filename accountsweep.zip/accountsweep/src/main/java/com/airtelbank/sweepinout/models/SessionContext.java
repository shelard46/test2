package com.airtelbank.sweepinout.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "SessionContext")
public class SessionContext {
	
	@XmlElement(name = "SupervisorContext")
	private SupervisorContext supervisorContext;

	@XmlElement(name = "Channel")
    private String channel;

	/*
	 * @XmlElement(name = "ValueDate") private SimpleDateFormat valueDate;
	 */

	@XmlElement(name = "ExternalReferenceNo")
    private String externalReferenceNo;
}
