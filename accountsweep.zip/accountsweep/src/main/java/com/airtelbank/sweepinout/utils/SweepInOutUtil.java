package com.airtelbank.sweepinout.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.config.log.SweepInOutThreadLocal;
import com.airtelbank.sweepinout.models.LoggerModel;

@Component
@RefreshScope
public class SweepInOutUtil {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private Environment environment;

	public void amhiKibanaLogger(String customerID) {
		if (StringUtils.isNotBlank(customerID)) {
			MDC.put("customerId", customerID);
		}
		LoggerModel loggerModel = SweepInOutThreadLocal.getValue();
		loggerModel.setCustMobileNo(customerID);
		loggerModel.setServiceId(environment.getProperty("sweepinout.serviceId"));
		loggerModel.setApiId(environment.getProperty("sweepinout.apId"));
	}

	
	public static void kibanaPreProcess(String serviceId, String apId, String mobileNo,
			long insuranceId, String sourceId) {
		LoggerModel loggerModel = SweepInOutThreadLocal.getValue();
		loggerModel.setServiceId(serviceId);
		loggerModel.setApiId(apId);
		loggerModel.setCustMobileNo(mobileNo);
		MDC.put("customerId", mobileNo);
		MDC.put("type", String.valueOf(insuranceId));//Cr/Dr
		MDC.put("sourceId", sourceId);
	}
	
	public void amhiMetaKibanaLogger(String request,String response) {
		LoggerModel loggerModel = SweepInOutThreadLocal.getValue();
		loggerModel.setId1(request);
		loggerModel.setId2(response);
		loggerModel.setServiceId(environment.getProperty("sweepinout.serviceId"));
		loggerModel.setApiId(environment.getProperty("sweepinout.apId"));
	}

 }
