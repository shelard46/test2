package com.airtelbank.sweepinout.config.log;

import com.airtelbank.sweepinout.models.LoggerModel;

public class SweepInOutThreadLocal {
	
	private static ThreadLocal<LoggerModel> thLocal = new ThreadLocal<>();
	
	public static void setValue(LoggerModel logger){
		thLocal.set(logger);
	}
	
	public static LoggerModel getValue(){
		return thLocal.get();
	}

	public static void unset(){
		thLocal.remove();
	}
	
}
