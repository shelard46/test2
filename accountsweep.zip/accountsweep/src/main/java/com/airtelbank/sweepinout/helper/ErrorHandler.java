package com.airtelbank.sweepinout.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.config.log.KibanaErrorLogger.LOGGING_TYPE;
import com.airtelbank.sweepinout.exception.SweepInOutException;

@Component
public class ErrorHandler {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private KibanaErrorLogger kibanaErrorLogger;

	public void sweepInOutErrorHandler(String code, String msg) {
		String errorCode = null;
		String errorMessage = null;
		switch (code) {
		case "-9949":
			kibanaErrorLogger.addError(LOGGING_TYPE.DUPLICATE_TRANSACTION);
			errorCode = messageSource.getMessage("code.suryoday.duplicate.transaction", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.duplicate.transaction.desc", null, null);
			break;
		case "2743":
			kibanaErrorLogger.addError(LOGGING_TYPE.INSUFFICIENT_FUND);
			errorCode = messageSource.getMessage("code.suryoday.insufficient.fund", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.insufficient.fund.desc", null, null);
			break;
		case "7606":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_ACCOUNT_TYPE);
			errorCode = messageSource.getMessage("code.suryoday.invalid.account.type", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.invalid.account.type.desc", null, null);
			break;
		case "7549":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_MIN_AMOUNT);
			errorCode = messageSource.getMessage("code.suryoday.invalid.min.amount", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.invalid.min.amount.desc", null, null);
			break;
		case "3103":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_TRANSACTION);
			errorCode = messageSource.getMessage("code.insurance.invalid.transaction", null, null);
			errorMessage = messageSource.getMessage("code.insurance.invalid.transaction.desc", null, null);
			break;
		case "7774":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.invalid.account", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.invalid.account.desc", null, null);
			break;
		case "":
			kibanaErrorLogger.addError(LOGGING_TYPE.NEGATIVE_AMOUNT);
			errorCode = messageSource.getMessage("code.suryoday.negative.amount", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.negative.amount.desc", null, null);
			break;
		case "700511":
			kibanaErrorLogger.addError(LOGGING_TYPE.EXCEED_TRANSACTION_LIMIT);
			errorCode = messageSource.getMessage("code.suryoday.exceed.transaction.limit", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.exceed.transaction.limit.desc", null, null);
			break;
		case "700512":
			kibanaErrorLogger.addError(LOGGING_TYPE.EXCEED_TRANSACTION_LIMIT);
			errorCode = messageSource.getMessage("code.suryoday.exceed.transaction.limit", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.exceed.transaction.limit.desc", null, null);
			break;
		case "700506":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_BENEFICIARY);
			errorCode = messageSource.getMessage("code.suryoday.invalid.beneficiary", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.invalid.beneficiary.desc", null, null);
			break;
		case "3310":
			kibanaErrorLogger.addError(LOGGING_TYPE.INACTIVE_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.inactive.account", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.inactive.account.desc", null, null);
			break;
		case "3308":
			kibanaErrorLogger.addError(LOGGING_TYPE.DORMANT_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.dormant.account", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.dormant.account.desc", null, null);
			break;
		case "3309":
			kibanaErrorLogger.addError(LOGGING_TYPE.ESCHEAT_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.escheat.account", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.escheat.account.desc", null, null);
			break;
		case "55":
			kibanaErrorLogger.addError(LOGGING_TYPE.CLOSED_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.account.closed", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.account.closed.desc", null, null);
			break;
		case "700110":
			kibanaErrorLogger.addError(LOGGING_TYPE.DECEASED_CUST);
			errorCode = messageSource.getMessage("code.suryoday.customer.deceased", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.customer.deceased.desc", null, null);
			break;
		case "700106":
			kibanaErrorLogger.addError(LOGGING_TYPE.RESTRICT_ACCOUNT);
			errorCode = messageSource.getMessage("code.suryoday.account.restrict", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.account.restrict.desc", null, null);
			break;
		case "700530":
			kibanaErrorLogger.addError(LOGGING_TYPE.EXCEED_TRANS_LIMIT);
			errorCode = messageSource.getMessage("code.suryoday.transaction.limit.exceed", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.transaction.limit.exceed.desc", null, null);
			break;
		case "700140":
			kibanaErrorLogger.addError(LOGGING_TYPE.RESTRICT_CUST);
			errorCode = messageSource.getMessage("code.suryoday.customer.restrict", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.customer.restrict.desc", null, null);
			break;
		case "2849":
			kibanaErrorLogger.addError(LOGGING_TYPE.REQUIRED_USER_ID);
			errorCode = messageSource.getMessage("code.suryoday.required.user.id", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.required.user.id.desc", null, null);
			break;
		case "2858":
			kibanaErrorLogger.addError(LOGGING_TYPE.INVALID_USER);
			errorCode = messageSource.getMessage("code.suryoday.invalid.user", null, null);
			errorMessage = messageSource.getMessage("code.suryoday.invalid.user", null, null);
			break;
		default:
			kibanaErrorLogger.addError(LOGGING_TYPE.DEF);
			errorCode = code;
			errorMessage = msg;
			break;
		}
		throw new SweepInOutException(errorCode, errorMessage);
	}

}
