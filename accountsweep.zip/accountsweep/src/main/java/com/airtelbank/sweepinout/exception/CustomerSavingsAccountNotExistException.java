package com.airtelbank.sweepinout.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CustomerSavingsAccountNotExistException extends GenericException{

	public CustomerSavingsAccountNotExistException(String errorCode, String errorMessage) {
		super(errorCode,errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;	
		
	}
}
