package com.airtelbank.sweepinout.utils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.exception.ProcessingException;
import com.airtelbank.sweepinout.models.CommunicationList;
import com.airtelbank.sweepinout.models.PartnerTextMessageAndEnableRetry;
import com.airtelbank.sweepinout.models.TempDataModel;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RefreshScope
public class SmsUtil {

	/** The sender name. */
	private @Value("${sender.name}") String senderName;
	
	/** The vo helper service id. */
	private @Value("${tpIntegrationsServiceId}") String tpIntegrationsServiceId;
	
	/** The success response code. */
	private @Value("${successful.response.code}") String successResponseCode;
	
	/** The error response code. */
	private @Value("${error.response.code}") String errorResponseCode;
	
	/** The success sms text. */
	private @Value("${sms.text.suryoday.sweepin.fail}") String smsTextSuryodayPaymentFail;
		
	private @Value("${sms.text.suryoday.sweepin.success}") String smsTextSuryodayPaymentSuccess;
	
	private @Value("${sms.text.suryoday.sweepin.hold}") String smsTextSuryodayPaymentHold;
	
	private @Value("${sms.text.suryoday.sweepin.cur.fail}") String smsTextCurSuryodayPaymentFail;
	
	private @Value("${sms.text.suryoday.sweepin.cur.success}") String smsTextCurSuryodayPaymentSuccess;
	
	private @Value("${sms.text.suryoday.sweepout.cur.success}") String smsTestCurSweepOutSuccess;
	
	private @Value("${sms.text.suryoday.tokenmoney.cur.success}") String smsTestCurTokenMoneySuccess;
	
	/** The sms sending endpoint. */
	private @Value("${sms.sending.endpoint}") String smsSendingEndpoint;
	
	/** The sms sent status. */
	private @Value("${sms_sent}") String smsSentStatus;
	
	/** The http util. */
	private @Autowired HttpUtils httpUtil;
	
	@Value("${sms.text.suryoday.sweepout.success}")
	private String sweepoutSucess;
	
	/** The lang id. */
	private @Value("${email.langId}") String langId;
	
	/** The external refrence number */
	private @Value("${email.external.reference.number}") String extRefNo;
	
	/** The first receipient of mail */
	private @Value("${email.first.recipient}") String firstRecipient;
	
	/** The first receipient of mail */
	private @Value("${email.second.recipient}") String secondRecipient;
	
	/** The sender of mail */
	private @Value("${email.sender}") String emailSender;
	
	/** The temp code of mail */
	private @Value("${email.temp.code}") String emailTempCode;
	
	/** The email body value */
	private @Value("${email.body.key}") String emailBodyKey;
	
	/** The email body key */
	private @Value("${email.body.value}") String emailBodyValue;

	/** The email subject */
	private @Value("${email.subject}") String emailSubject;

	@Value("${sms.text.suryoday.tokenmoney.success}")
	private String tokenmoneySucess;
	
	public SendSMS prepareSendEmailObject(String accountNo, BigDecimal amount, String airtelTxnId, Calendar valueDate) {
		log.info("prepareSendEmailObject starts");
		CommunicationList communication = new CommunicationList();
		communication.setType(Constants.TYPE);
		communication.setMode(Constants.MODE);
		communication.setLangId(langId);
		communication.setExternalRefNo(extRefNo);
		communication.setDeliveryReportRequired(Constants.IS_DELIVERY_REPORT_REQ);
		List<String> recipient = new ArrayList<String>();
		recipient.add(firstRecipient);
		recipient.add(secondRecipient);
		communication.setRecipient(recipient);
		communication.setSubject(emailSubject);
		communication.setSender(emailSender);
		communication.setIndex(Constants.INDEX);
		communication.setCategory(Constants.CATEGORY);
		communication.setMaskingRequired(Constants.IS_MASKING_REQUIRED);
		communication.setTempCode(emailTempCode);
		communication.setFrequency(Constants.EMPTY_STRING);
		communication.setRetryCount(Constants.RETRY_COUNT);
		communication.setCustomClassName(Constants.EMPTY_STRING);
		communication.setContent(Constants.EMPTY_STRING);
		communication.setMaxRetryCount(Constants.MAX_RETRY_COUNT);
		communication.setPriority(Constants.PRIORITY);
		communication.setAppCode(Constants.EMPTY_STRING);
		communication.setAppKey(Constants.EMPTY_STRING);
		TempDataModel tempDataModel = new TempDataModel();
		tempDataModel.setKey(emailBodyKey);
		
		Date date = valueDate.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy hh:mm:ss");  
        String strDate = dateFormat.format(date);  
		tempDataModel.setVal(emailBodyValue.concat("\nCustomer Account Number : ").concat(accountNo).concat("\nAirtel Transaction ID : ").concat(airtelTxnId).concat("\nAmount : ").concat(amount.toString()).concat("\nValue Date : ").concat(strDate));
		log.info("TempDataModel:", tempDataModel);
		List<TempDataModel> tempDataModelList = new ArrayList<TempDataModel>();
		tempDataModelList.add(tempDataModel);
		communication.setTempDataModel(tempDataModelList);	
		List<CommunicationList> communicationList = new ArrayList<>();
		log.info("communication data:", communication);
		communicationList.add(communication);
		log.info("communicationList data:", communicationList);
		SendSMS sendSMSBody = new SendSMS();
		sendSMSBody.setCommunicationList(communicationList);
		log.info("after hitting sendSMSBody:", sendSMSBody);
		return sendSMSBody;
	}
	

	/**
	 * Prepare send SMS object.
	 *
	 * @param partnerTextMessageAndEnableRetry the partner text message and enable
	 *                                         retry
	 * @return the send SMS
	 */
	public SendSMS prepareSendSMSObject(Map<String,Object> map,
			PartnerTextMessageAndEnableRetry partnerTextMessageAndEnableRetry, String smsNumber) {
		CommunicationList communication = new CommunicationList();
		communication.setType("SMS");
		communication.setMode("I");
		communication.setLangId("2");

		String textMessageTemplate = partnerTextMessageAndEnableRetry.getTextMessage();
		if (StringUtils.isBlank(textMessageTemplate)) {
			log.warn(tpIntegrationsServiceId + ":" + errorResponseCode + ": No TextMessage Format found");
			throw new ProcessingException(
					"No TextMessage Format found for EMI " +  map.get(Constants.CUSTOMER_MSISDN).toString());
		} else {
			try {
				communication.setContent(textMessageTemplate);
				List<String> recipients = new ArrayList<String>();
				recipients.add(smsNumber);
				communication.setRecipient(recipients);
				communication.setSender(senderName);
				communication.setSubject("SMS");
				communication.setCategory("Fund Transfer");
				communication.setExternalRefNo(UUID.randomUUID().toString());
				List<CommunicationList> communicationList = new ArrayList<>();
				communicationList.add(communication);
				SendSMS sendSMSBody = new SendSMS();
				sendSMSBody.setCommunicationList(communicationList);
				return sendSMSBody;
			} catch (IllegalArgumentException iae) {
				log.warn(tpIntegrationsServiceId + ":" + errorResponseCode
						+ ": Exception occurred while preparing sms object  : {}. Root cause : {}. Error message : {}",
						map, ExceptionUtils.getRootCause(iae), ExceptionUtils.getMessage(iae));
				throw new ProcessingException(
						"Exception occurred while preparing sms object " + map + " to ValuesMap ");
			}
		}
	}

	
	public void sendEmail(String accountNo, BigDecimal amount, String airtelTxnId, Calendar valueDate) throws JsonProcessingException {
		log.info("sendEmail starts");
		SendSMS sendSMSBody = prepareSendEmailObject(accountNo,amount,airtelTxnId,valueDate);
		log.info("sendSMSBody going  to hit invokePostURL",sendSMSBody);
		String response = httpUtil.invokePostURL(null != smsSendingEndpoint && StringUtils.isNotEmpty(smsSendingEndpoint) ? smsSendingEndpoint : smsSendingEndpoint, sendSMSBody);
		log.info("EMI SMS response " + response
				+ " received after hitting " + smsSendingEndpoint + "output =" +smsSentStatus);
	}
	
	public void sendSMSToUser (Map<String,Object> map) {
		log.info("SMS request Map = {}", map);
		String smsNumber = "";
		try {
			PartnerTextMessageAndEnableRetry partnerTextMessageAndEnableRetry = new PartnerTextMessageAndEnableRetry();
				smsNumber = (String) map.get(Constants.SMS_NUMBER);
				if(map.get(Constants.SMS).toString().equals(Constants.SWEEPIN_SURYODAY_FAIL)) {
					String msg = "";
					if(map.get(Constants.CUST_TYPE).toString().equalsIgnoreCase(Constants.CUR_ACCOUNT_TYPE)) {
						msg = smsTextCurSuryodayPaymentFail;
						msg = msg.replaceAll("Xamount", (String )map.get(Constants.TXN_AMOUNT));
					}
					else {
						msg = smsTextSuryodayPaymentFail;
						msg = msg.replaceAll("XXXXXXX", (String ) map.get(Constants.SURYODAY_ACCOUNT_NO));
					}
					partnerTextMessageAndEnableRetry.setTextMessage(msg);
				}else if(map.get(Constants.SMS).toString().equals(Constants.SWEEPIN_SURYODAY_SUCCESS)){
					String msg = "";
					if(map.get(Constants.CUST_TYPE).toString().equalsIgnoreCase(Constants.CUR_ACCOUNT_TYPE)) {
						msg = smsTextCurSuryodayPaymentSuccess;
						msg = msg.replaceAll("XXXXXXX", map.get(Constants.SMS_NUMBER).toString().replaceAll("\\w(?=\\w{4})", "X"));
						msg = msg.replaceAll("Xamount",(String ) map.get(Constants.TXN_AMOUNT));
						msg = msg.replaceAll("Zbalance", (String ) map.get(Constants.BALANCE));
						msg = msg.replaceAll("TtxnID", (String ) map.get(Constants.APB_TXN_ID));
					}
					else {
						msg = smsTextSuryodayPaymentSuccess;
						msg = msg.replaceAll("Xamount",(String ) map.get(Constants.TXN_AMOUNT));
						msg = msg.replaceAll("QsurodayBalance", (String ) map.get(Constants.SURYODAY_BLANCE));
						msg = msg.replaceAll("Ydate", (String )map.get(Constants.TXN_DATE));
						msg = msg.replaceAll("Zbalance", (String ) map.get(Constants.BALANCE));
						msg = msg.replaceAll("TtxnID", (String ) map.get(Constants.APB_TXN_ID));
					}
					partnerTextMessageAndEnableRetry.setTextMessage(msg);
				}else if(map.get(Constants.SMS).toString().equals(Constants.SWEEPIN_SURYODAY_HOLD)) {
					String msg = smsTextSuryodayPaymentHold;
					msg = msg.replaceAll("XXXXXXX", (String ) map.get(Constants.SURYODAY_ACCOUNT_NO));
					msg = msg.replaceAll("X", (String ) map.get(Constants.TXN_AMOUNT));
					partnerTextMessageAndEnableRetry.setTextMessage(msg);
				}else if(map.get(Constants.SMS).toString().equals(Constants.SWEEPOUT_SUCCESS)) {
					String msg = "";
					if(map.get(Constants.CUST_TYPE).toString().equalsIgnoreCase(Constants.CUR_ACCOUNT_TYPE)) {
						msg = smsTestCurSweepOutSuccess;
						msg = msg.replaceAll("XXXXXXX", map.get(Constants.SMS_NUMBER).toString().replaceAll("\\w(?=\\w{4})", "X"));
						msg = msg.replaceAll("Xamount", (String ) map.get(Constants.TXN_AMOUNT));
						msg = msg.replaceAll("Zbalance", (String ) map.get(Constants.BALANCE));
						msg = msg.replaceAll("TtxnID", (String ) map.get(Constants.APB_TXN_ID));
					}
					else {
						msg = sweepoutSucess;
						msg = msg.replaceAll("Xamount", (String ) map.get(Constants.TXN_AMOUNT));
						msg = msg.replaceAll("TtxnID", (String ) map.get(Constants.APB_TXN_ID));
					}
					partnerTextMessageAndEnableRetry.setTextMessage(msg);
				} else if(map.get(Constants.SMS).toString().equals(Constants.TOKENMONEY_SUCCESS)) {
					String msg = "";
					if(map.get(Constants.CUST_TYPE).toString().equalsIgnoreCase(Constants.CUR_ACCOUNT_TYPE)) {
						msg = smsTestCurTokenMoneySuccess;
					}
					else {
						msg = tokenmoneySucess;
					}
					msg = msg.replaceAll("Xamount", (String ) map.get(Constants.TXN_AMOUNT));
					msg = msg.replaceAll("TtxnID", (String ) map.get(Constants.APB_TXN_ID));
					msg = msg.replaceAll("QsurodayBalance", (String ) map.get(Constants.SURYODAY_BLANCE));
					partnerTextMessageAndEnableRetry.setTextMessage(msg);
				}

			partnerTextMessageAndEnableRetry.setEnableRetry(true);
			// prepare SendSMS body
			SendSMS sendSMSBody = prepareSendSMSObject(map,
							partnerTextMessageAndEnableRetry, smsNumber);
			// create entity by setting body data and headers
			// and hit url
			log.info("EMI SMS invoking invokePostURL of AppUtil with "
						+ smsSendingEndpoint + " and data  " + sendSMSBody);

			String response = httpUtil.invokePostURL(null != smsSendingEndpoint && StringUtils.isNotEmpty(smsSendingEndpoint) ? smsSendingEndpoint : smsSendingEndpoint, sendSMSBody);

			log.info("EMI SMS response " + response
						+ " received after hitting " + smsSendingEndpoint + "output =" +smsSentStatus);
		} catch (Exception rae) {
			log.error("Exception while sending sms to the user",rae);
		}
		
	}

}