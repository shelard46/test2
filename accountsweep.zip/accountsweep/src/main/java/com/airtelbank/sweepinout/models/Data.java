package com.airtelbank.sweepinout.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Data implements Serializable {
	
	private static final long serialVersionUID = 1L;
	public String message;
	public String ftTxnId;
	public String balAfterTxn;
	public String availableBalance;
	public String holdBalance;
	public String charges;
	
}