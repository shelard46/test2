package com.airtelbank.sweepinout.exception;

import com.airtelbank.sweepinout.dto.ResultDTO;

import lombok.Data;

@Data
public class CustomerValidationException extends GenericException{
	private String errorCode;
	private String errorMessage;
	
	public <T> CustomerValidationException(String errorCode, String errorMessage){
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
			}

	public CustomerValidationException() {
		// TODO Auto-generated constructor stub
	}
}
