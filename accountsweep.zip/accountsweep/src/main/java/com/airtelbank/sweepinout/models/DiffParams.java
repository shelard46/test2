package com.airtelbank.sweepinout.models;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class DiffParams {
	private String diffParam1;
    private String diffParam3;
    private String diffParam2;
}
