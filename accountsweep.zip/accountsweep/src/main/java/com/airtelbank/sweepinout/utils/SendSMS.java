package com.airtelbank.sweepinout.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.airtelbank.sweepinout.models.CommunicationList;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * The Class SendSMS.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "communicationList" })
public class SendSMS {

	/** The communication list. */
	@JsonProperty("communicationList")
	private List<CommunicationList> communicationList = null;

	/** The additional properties. */
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	/**
	 * No args constructor for use in serialization.
	 */
	public SendSMS() {
	}

	/**
	 * Instantiates a new send SMS.
	 *
	 * @param communicationList the communication list
	 */
	public SendSMS(List<CommunicationList> communicationList) {
		super();
		this.communicationList = communicationList;
	}

	/**
	 * Gets the communication list.
	 *
	 * @return the communication list
	 */
	@JsonProperty("communicationList")
	public List<CommunicationList> getCommunicationList() {
		return communicationList;
	}

	/**
	 * Sets the communication list.
	 *
	 * @param communicationList the new communication list
	 */
	@JsonProperty("communicationList")
	public void setCommunicationList(List<CommunicationList> communicationList) {
		this.communicationList = communicationList;
	}

	/**
	 * Gets the additional properties.
	 *
	 * @return the additional properties
	 */
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	/**
	 * Sets the additional property.
	 *
	 * @param name  the name
	 * @param value the value
	 */
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this).append("communicationList", communicationList)
				.append("additionalProperties", additionalProperties).toString();
	}
}
