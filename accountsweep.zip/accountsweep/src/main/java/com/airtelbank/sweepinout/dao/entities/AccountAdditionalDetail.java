package com.airtelbank.sweepinout.dao.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AOA_ACC_ADDITIONAL_DETAIL")
@SequenceGenerator(name = "accountAdditionalDetailSequence", sequenceName = "ACC_ADDITIONAL_DETAIL_SEQUENCE", allocationSize = 50, initialValue = 1)
public class AccountAdditionalDetail implements Serializable {

	private static final long serialVersionUID = -5751385249582354349L;
	/** The id. */
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	private Long id;

	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "ADDON_ACCOUNT")
	private AddonAccount addonAccount;

	@Column(name = "KEY", length = 200)
	private String key;

	@Column(name = "VALUE", length = 200)
	private String value;
}
