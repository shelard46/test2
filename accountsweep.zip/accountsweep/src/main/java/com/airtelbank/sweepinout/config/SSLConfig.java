package com.airtelbank.sweepinout.config;

import java.util.Arrays;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.airtelbank.sweepinout.config.log.LoggingClientHttpRequestInterceptor;

/**
 * Class provides beans for external communication over ssl.
 *
 * In order to make ssl work, following properties need to be define in
 * environment. <br />
 * <strong>server.ssl.trust-store </strong>: location of trust store file <br />
 * <strong>server.ssl.trust-store-password </strong>: password of trust store
 * file <br />
 * <strong>server.ssl.key-store </strong>: password of key store file <br />
 * <strong>server.ssl.key-password </strong>: password of key store file <br />
 * <strong>app.ssl.enabled </strong>: Boolean value weather ssl is enabled for
 * externa system <br />
 *
 * @author B0206676
 *
 */
@Configuration
@RefreshScope
public class SSLConfig {

	private static Logger logger = LoggerFactory.getLogger(SSLConfig.class);
	
	@Value("${server.ssl.trust-store:#{null}}")
	private String trustStoreLocation;

	@Value("${server.ssl.trust-store-password:#{null}}")
	private String trustStorePassPhrase;

	@Value("${server.ssl.key-store}")
	private String keyStoreLocation;

	@Value("${server.ssl.key-password}")
	private String keyStorePassPhrase;

	@Value("${app.ssl.enabled}")
	private boolean sslEnabled;

	@Value("${config.proxy.url}")
	private String proxyURL;

	@Value("${config.proxy.port}")
	private int proxyPort;

	@Value("${config.connection.request.timeout}")
	private int requestTimeout;

	@Value("${config.connect.timeout}")
	private int connectTimeout;

	@Value("${config.socket.timeout}")
	private int socketTimeout;
	
	@Value("${partner.readTimeOut}")
	private int partnerReadTimeOut;
	
	@Value("${partner.connectionTimeOut}")
	private int partnerConnectionTimeOut;


	@Autowired
	private LoggingClientHttpRequestInterceptor loggingClientHttpRequestInterceptor;
	
	@Bean
	public ClientHttpRequestFactory requestFactory() {
		HttpClient httpClient = null;
		if (sslEnabled) {
			try {

				SSLContextBuilder sslContextBuilder = SSLContextBuilder.create();

				if (keyStoreLocation != null && keyStorePassPhrase != null) {
					sslContextBuilder.loadKeyMaterial(ResourceUtils.getFile(keyStoreLocation),
							keyStorePassPhrase.toCharArray(), keyStorePassPhrase.toCharArray());
				}
				if (trustStoreLocation != null && trustStorePassPhrase != null) {
					sslContextBuilder.loadTrustMaterial(ResourceUtils.getFile(trustStoreLocation),
							trustStorePassPhrase.toCharArray());
				}

				javax.net.ssl.SSLContext sslContext = sslContextBuilder.build();

				RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(requestTimeout)
						.setConnectTimeout(connectTimeout).setSocketTimeout(socketTimeout).build();
				httpClient = HttpClients.custom().setSSLContext(sslContext).setDefaultRequestConfig(requestConfig)
						.build();

			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			httpClient = HttpClients.createDefault();
		}

		ClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

		return clientHttpRequestFactory;
	}

	@Bean
	public RestTemplate restTemplate() {
		BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory = new BufferingClientHttpRequestFactory(
				requestFactory());
		RestTemplate restTemplate = new RestTemplate(bufferingClientHttpRequestFactory);
		restTemplate.setInterceptors(Arrays.asList(loggingClientHttpRequestInterceptor));
		return restTemplate;
	}

	@Bean
	public ClientHttpRequestFactory proxyRequestFactory() {
		HttpClient httpClient = null;
		if (sslEnabled) {
			try {

				SSLContextBuilder sslContextBuilder = SSLContextBuilder.create();

				if (keyStoreLocation != null && keyStorePassPhrase != null) {
					sslContextBuilder.loadKeyMaterial(ResourceUtils.getFile(keyStoreLocation),
							keyStorePassPhrase.toCharArray(), keyStorePassPhrase.toCharArray());
				}
				if (trustStoreLocation != null && trustStorePassPhrase != null) {
					sslContextBuilder.loadTrustMaterial(ResourceUtils.getFile(trustStoreLocation),
							trustStorePassPhrase.toCharArray());
				}

				javax.net.ssl.SSLContext sslContext = sslContextBuilder.build();

				RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(partnerReadTimeOut)
						.setConnectTimeout(partnerConnectionTimeOut).setSocketTimeout(partnerConnectionTimeOut).build();
				httpClient = HttpClients.custom().setSSLContext(sslContext).setProxy(new HttpHost(proxyURL, proxyPort))
						.setDefaultRequestConfig(requestConfig).build();

			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			httpClient = HttpClientBuilder.create().setProxy(new HttpHost(proxyURL, proxyPort)).build();
		}
		ClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

		return clientHttpRequestFactory;
	}

	@Bean
	public RestTemplate proxyRestTemplate() {
		BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory = new BufferingClientHttpRequestFactory(
				proxyRequestFactory());
		RestTemplate proxyTemplate = new RestTemplate(bufferingClientHttpRequestFactory);
		proxyTemplate.setInterceptors(Arrays.asList(loggingClientHttpRequestInterceptor));
		return proxyTemplate;
	}
}
