package com.airtelbank.sweepinout.dao.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AOA_ACCOUNT_BALANCE")
@SequenceGenerator(name = "accountBalanceSequence", sequenceName = "ACCOUNT_BALANCE_SEQUENCE", allocationSize = 50, initialValue = 1)
public class AccountBalance implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1988571180983923077L;

	/** The id. */
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	@GeneratedValue(generator = "accountBalanceSequence")
	private Long id;

	/** The addon account. */
	@OneToOne(cascade = CascadeType.DETACH)
	private AddonAccount addonAccount;

	/** The balance A mount. */
	@Column(name = "BALANCE_AMT")
	private BigDecimal balanceAmount;

	/** The previous balance. */
	@Column(name = "PREVIOUS_BALANCE_AMT")
	private BigDecimal previousBalance;
	
	@Column(name = "COD_CUST_NATL_ID", length = 50)
	private String customerNatalId;

	@Column(name = "COD_CUST_ID", length = 50)
	private String customerId;
	/** The addon account number. */

	@Column(name = "ADDON_ACCOUNT_NUMBER", length = 50)
	private String accountNumber;

}
