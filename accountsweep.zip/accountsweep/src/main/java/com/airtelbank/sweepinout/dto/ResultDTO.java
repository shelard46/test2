package com.airtelbank.sweepinout.dto;

import java.io.Serializable;
import java.util.List;

import com.airtelbank.sweepinout.exception.ErrorMessage;
import com.airtelbank.sweepinout.utils.Constants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class ResultDTO implements Serializable {
    
	private static final long serialVersionUID = -2779305745756246981L;
	private List<ErrorMessage> errors;
    private String code;
    private String description;
    private int status;
 
    //for retailerTxns
    @JsonProperty("x-access-token")
    private String xAccessToken;    
    
    public void generatePositiveResponse(String desc){
		this.setDescription(desc);
		this.setStatus(Constants.REQUEST_SUCCESS);
		this.setCode(Constants.REQUEST_SUCCESS_CODE);
    }
    
    public void generateErrorResponse(String desc, String code){
    	this.setCode(code);
		this.setDescription(desc);
		this.setStatus(Constants.REQUEST_FAIL);
	}
    
    public void generateTimeOutResponse(String desc, String code){
    	this.setCode(code);
		this.setDescription(desc);
		this.setStatus(Constants.REQUEST_PENDING);
	}
}
