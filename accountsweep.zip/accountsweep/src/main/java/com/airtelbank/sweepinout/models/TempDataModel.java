package com.airtelbank.sweepinout.models;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"key",
"val"
})
public class TempDataModel {

@JsonProperty("key")
private String key;
@JsonProperty("val")
private String val;

@JsonProperty("key")
public String getKey() {
return key;
}

@JsonProperty("key")
public void setKey(String key) {
this.key = key;
}

@JsonProperty("val")
public String getVal() {
return val;
}

@JsonProperty("val")
public void setVal(String val) {
this.val = val;
}

}