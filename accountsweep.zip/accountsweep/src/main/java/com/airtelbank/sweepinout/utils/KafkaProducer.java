package com.airtelbank.sweepinout.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class KafkaProducer {
    @Autowired
    KafkaTemplate<String, Object> kafkaTemplate;

    public void pushOnKafka(Object payment, String topic) {

        ListenableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, payment);

        future.addCallback(new ListenableFutureCallback<SendResult<String, Object>>() {

            @Override
            public void onSuccess(SendResult<String, Object> payment) {
                onSuccesshandler(payment);
            }

            @Override
            public void onFailure(Throwable th) {
                onFailureHandler(th);
            }
        });
    }

    protected void onSuccesshandler(SendResult<String, Object> payment) {
        log.info("Record produced successfully {}", payment.toString());
    }

    protected void onFailureHandler(Throwable th) {
        log.info("Failed to produced record {}", th);
    }
}
