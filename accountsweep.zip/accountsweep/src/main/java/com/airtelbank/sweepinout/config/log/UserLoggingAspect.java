package com.airtelbank.sweepinout.config.log;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.airtelbank.sweepinout.utils.CommonUtil;

@Aspect
@Configuration
public class UserLoggingAspect {
	
	@Pointcut("execution(* com.airtelbank.sweepinout.service.impl..*.*(..))")
	public void serviceExecution() {
	}
	
	@Pointcut("execution(* com.airtelbank.sweepinout.utils..*.*(..))")
	public void utilsExecution() {
	}
	
	@Pointcut("execution(* com.airtelbank.sweepinout.helper..*.*(..))")
	public void  helperExecution() {
	}
	
	@Pointcut("execution(* com.airtelbank.sweepinout.controller..*.*(..))")
	public void  controllerExecution() {
	}
	
	@Pointcut("execution(* com.airtelbank.sweepinout.dao..*.*(..))")
	public void  daoExecution() {
	}
	
	@Pointcut("execution(* com.airtelbank.sweepinout.exception..*.*(..))")
	public void  exceptionExecution() {
	}

	@Around("serviceExecution()")
	public Object aroundService(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
	@Around("utilsExecution()")
	public Object aroundUtils(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
	@Around("helperExecution()")
	public Object aroundHelper(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
	@Around("controllerExecution()")
	public Object aroundController(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
	@Around("daoExecution()")
	public Object aroundDao(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
	@Around("exceptionExecution()")
	public Object aroundException(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType());
		Signature methodSignature = joinPoint.getSignature();
		logger.info(CommonUtil.infoPrefixSuffix("Entering Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		Object ret = joinPoint.proceed();
		logger.info(CommonUtil.infoPrefixSuffix("Exiting Service method... {} : {}()"),
				methodSignature.getDeclaringType().getCanonicalName(), methodSignature.getName());
		return ret;
	}
	
}
