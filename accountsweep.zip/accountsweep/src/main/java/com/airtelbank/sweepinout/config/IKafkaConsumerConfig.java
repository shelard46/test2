package com.airtelbank.sweepinout.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;

public interface IKafkaConsumerConfig {
	public default Map<String, Object> consumerFactory(String bootstrapAddress, String groupId) {
		Map<String, Object> props = new HashMap<>(2);	
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		return props;
	}

}