package com.airtelbank.sweepinout.utils;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.airtelbank.sweepinout.config.RedisConfig;
import com.airtelbank.sweepinout.models.FundTransferRetryRequest;
import com.airtelbank.sweepinout.models.InputForEnquiry;
import com.airtelbank.sweepinout.service.PaymentService;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Tuple;

@Component
@EnableScheduling
@Slf4j
@RefreshScope
public class RedisConsumer {
	
	@Value("${zadd.set.name}") 
	private String zaddSet;		
	
	@Value("${zadd.set.name.Suryoday}") 
	private String suryodayZaddSet;
	
	@Value("${payment.enquiry.scheduler.enable}")
	private boolean isSchedulerEnabled;
	
	@Value("${zadd.set.name.policyRetry}")
	private String policyRetrySetName;	
	
	@Autowired
	private PaymentService paymentService;
	
	@Scheduled(fixedDelayString = "${payment.enquiry.scheduler.duration}")
	public void consume() {
		if(isSchedulerEnabled) {
			String currentTime = CommonUtil.getCurrentDateTime().toString();
			log.info("payment Enquiry scheduler started at {}", currentTime);
			Gson gson = new Gson();
			//InsuranceThreadLocal.setValue(new LoggerModel());
			try (Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {
				if (jedis != null) {
					Set<Tuple> tupleSet = jedis.zrangeByScoreWithScores(zaddSet, 0, System.currentTimeMillis());
					for (Tuple tuple : tupleSet) {
						log.info("Score {}, Element {}", tuple.getScore(), tuple.getElement());
						String value = tuple.getElement();
						String object = jedis.hget(value, "value");
						FundTransferRetryRequest fundTransferRequest = gson.fromJson(object, FundTransferRetryRequest.class);
						if (fundTransferRequest != null) {
							paymentService.apbIFTRedisPayment(fundTransferRequest);
						} else {
							log.info("Response Data for value {} is null in Redis HashSet ", value);	
							removeFromRedis(zaddSet, value, "value");
						}
					}
				} else	{
					log.error("Couldn't get a jedis client from pool");
				}	
			}
					
		}
	}
	
	
	@Scheduled(fixedDelayString = "${suryoday.enquiry.scheduler.duration}")
	public void consumeSuryodayIFT() {
		if(isSchedulerEnabled) {
			String currentTime = CommonUtil.getCurrentDateTime().toString();
			log.info("suryoday Enquiry scheduler started at {}", currentTime);
			Gson gson = new Gson();
			//InsuranceThreadLocal.setValue(new LoggerModel());
			try (Jedis jedis = RedisConfig.getInstance().getJedisPool().getResource()) {
				if (jedis != null) {
					Set<Tuple> tupleSet = jedis.zrangeByScoreWithScores(suryodayZaddSet, 0, System.currentTimeMillis());
					for (Tuple tuple : tupleSet) {
						log.info("Score {}, Element {}", tuple.getScore(), tuple.getElement());
						String value = tuple.getElement();
						String object = jedis.hget(value, "value");
						InputForEnquiry fundTransferRequest = gson.fromJson(object, InputForEnquiry.class);
						if (fundTransferRequest != null) {
							paymentService.suryodayIFTRetry(fundTransferRequest);
						} else {
							log.info("Response Data for value {} is null in Redis HashSet ", value);	
							removeFromRedis(suryodayZaddSet, value, "value");
						}
					}
				} else	{
					log.error("Couldn't get a jedis client from pool");
				}	
			}
					
		}
	}
	
	
	private void removeFromRedis(String setName, String member, String field) {
		GenericRedisProducer.removeEntryFromZadd(setName, member);
		GenericRedisProducer.removeEntryFromRedisHashSet(member, field);
	}
}
