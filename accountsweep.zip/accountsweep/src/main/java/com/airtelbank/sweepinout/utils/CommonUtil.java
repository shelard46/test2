package com.airtelbank.sweepinout.utils;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUtil {

	private static final Logger log = LoggerFactory.getLogger(CommonUtil.class);

	private CommonUtil() {

	}

	/** The object mapper. */
	public static ObjectMapper objectMapper = new ObjectMapper();
	
	private static final DateFormat sdf = new SimpleDateFormat("DDDMMyyyyHHmmssSSS");
	private static DateTimeFormatter formatterDob = DateTimeFormatter.ofPattern("yyyyMMdd");

	public static String generateUniqueKey() {
		return new StringBuffer().append(sdf.format(new Date(System.currentTimeMillis())))
				.append(new Random().nextInt(10)).toString();
	}

	public static String generateUniqueKey(String prefix) {
		return new StringBuffer().append(prefix).append(generateUniqueKey()).toString();
	}

	public static Date asDate(LocalDate localDate) {
		return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}

	public static Date asDate(LocalDateTime localDateTime) {
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	public static LocalDateTime asLocalDateTime(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	public static long getAge(LocalDate userDob) {
		LocalDate now = LocalDate.now();
		return ChronoUnit.YEARS.between(userDob, now);
	}

	public static String formatDate(String format, Date date) {
		if (null == date) {
			return null;
		}
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String strDate = formatter.format(date);
		return strDate;
	}

	public static long getTimeDifference(LocalDateTime from, LocalDateTime to, ChronoUnit unit) {
		long timeDifference = 0;
		switch (unit) {
		case MINUTES:
			timeDifference = ChronoUnit.MINUTES.between(from, to);
			break;
		case SECONDS:
			timeDifference = ChronoUnit.SECONDS.between(from, to);
			break;
		default:
			break;
		}
		return timeDifference;
	}

	public static LocalDate getFormattedDob(String dateValue) {
		if (dateValue == null || dateValue.isEmpty())
			return null;
		return LocalDate.parse(dateValue, formatterDob);
	}

	public static LocalDate asLocalDate(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
	}

	public static ResultDTO generateMetaData(int status, String code, String message) {
		ResultDTO meta = new ResultDTO();
		// Please DON'T TOUCH THIS!
		meta.setStatus(status);
		meta.setDescription(message);
		meta.setCode(code);
		return meta;
	}

	public static String makeStringInOneLine(String str) {
		if (str != null)
			return str.replaceAll("[\\t\\n\\r]+", " ");
		else
			return str;
	}

	public static Date getCurrentDateTime() {
		return new Date();
	}

	public static long getDifferenceInDays(String dateInString) {
		SimpleDateFormat dobSdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date = dobSdf.parse(dateInString);
			LocalDate localDateDob = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			long days = ChronoUnit.DAYS.between(localDateDob, LocalDate.now());
			return days;
		} catch (ParseException e) {
			log.error("Root Cause :" + e.getMessage());
			log.error("Nomiee DOB couldn't be parsed");
			e.printStackTrace();
		}
		return 0;
	}

	public static Date StringToDate(String dateString, String dateFormat) {
		SimpleDateFormat dobSdf = new SimpleDateFormat(dateFormat);
		try {
			Date date = dobSdf.parse(dateString);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			log.error("Root Cause :" + e.getMessage());
			log.error("Nomiee DOB couldn't be parsed");
		}
		return null;
	}

	public static <T> ResponseDTO<?> createGenericMeta(T data, int status, String code, String message) {
		ResponseDTO<T> response = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
		meta.setStatus(status);
		meta.setDescription(message);
		meta.setCode(code);
		if (data != null) {
			response.setData(data);
		}
		response.setMeta(meta);
		return response;
	}

	public static String trimCustomerId(String customerId) {
		if (customerId == null) {
			return null;
		}

		String trimmedCustomerId = null;
		if (customerId.length() == 12) {
			trimmedCustomerId = customerId.substring(2, customerId.length());
			return trimmedCustomerId;
		}
		return customerId;
	}

	public static String dateToString(Date date, String requiredDateFormt) {
		DateFormat df = new SimpleDateFormat(requiredDateFormt);
		try {
			String formattedDate = df.format(date);
			return formattedDate.toString();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Root Cause :" + e.getMessage());
			log.error("Date couldn't be formated");
		}
		return null;
	}

	public static boolean mobileValidation(long number, int size) {
		if (String.valueOf(number).length() == size) {
			return false;
		}
		return true;
	}
	public static boolean lengthValidation(double number, int size) {
		if (String.valueOf(number).length() <= size) {
			return false;
		}
		return true;
	}
	public static boolean minMaxValidation(String number, int min ,int max) {
		if (String.valueOf(number).length() >=min && String.valueOf(number).length() <=max) {
			return false;
		}
		return true;
	}

	
	public static ObjectMapper getObjectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false);
		return objectMapper;
	}
	
	public static <T> String convertToXMLInJAXB(T obj, Class<T> classObj) throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(classObj);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter xmlString = new StringWriter();
		m.marshal(obj, xmlString);
		return xmlString.toString();
	}

	public static <T> T convertToObjectFromXMLInJAXB(String xmlString, Class<T> classObj)
			throws JAXBException, XMLStreamException {
		JAXBContext context = JAXBContext.newInstance(classObj);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		XMLStreamReader reader = XMLInputFactory.newInstance()
				.createXMLStreamReader(new ByteArrayInputStream(xmlString.getBytes()));
		return unmarshaller.unmarshal(reader, classObj).getValue();
	}
	
	public static Map<String, String> defaultJsonHadderInRequest(){
		Map<String, String> headers = new HashMap<>();
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/json");
		headers.put("contentId", Constants.CONTENT_ID);
		return headers;
	}
	
	public static String genrateRefrenceNumber() {
		return Integer.toString(ThreadLocalRandom.current().nextInt(1000, 99999999));
	}
	
	public static BigDecimal roundOff(String amount) {
		return BigDecimal.valueOf(Double.valueOf(amount)).setScale(2, BigDecimal.ROUND_HALF_EVEN);
	}
	
	public static String lastNum(String num) {
		return StringUtils.right(num, 4);
	}
	/**
	 * Format date string.
	 *
	 * @param localDateTime the local date time
	 * @param format        the format
	 *
	 * @return the string
	 */
	public static String formatDate(LocalDateTime localDateTime,String format){
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
		return localDateTime.format(dateTimeFormatter);
	}
	
	public static String infoPrefixSuffix(String message) {
		String finalMessage = null;
		if (message != null) {
			finalMessage = Constants.INFO_MSG_PREFIX + message + Constants.INFO_MSG_SUFFIX;
		}
		return finalMessage;
	}


}
