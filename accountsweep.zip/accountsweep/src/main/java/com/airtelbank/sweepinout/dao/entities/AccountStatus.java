package com.airtelbank.sweepinout.dao.entities;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AOA_MSTR_ACCOUNT_STATUS")
@SequenceGenerator(name = "accountStatusSequence", sequenceName = "ACCOUNT_STATUS_SEQUENCE", allocationSize = 50, initialValue = 1)
public class AccountStatus implements Serializable {

	/**
	 * The Enum AccountStatusEnum.
	 */
	public enum AccountStatusEnum {

		/** The account closed. */
		ACCOUNT_CLOSED("1", "CLOSED"),
		/** The account blocked. */
		ACCOUNT_BLOCKED("2", "BLOCKED"),
		/** The account open no debit. */
		ACCOUNT_OPEN_NO_DEBIT("3", "NO_DR"),
		/** The account open no credit. */
		ACCOUNT_OPEN_NO_CREDIT("4", "NO_CR"),
		/** The account closed today. */
		ACCOUNT_CLOSED_TODAY("5", "CLOSED_TODAY"),
		/** The account opened today. */
		ACCOUNT_OPENED_TODAY("6", "OPENED_TODAY"),
		/** The account dormant. */
		ACCOUNT_DORMANT("7", "DORMANT"),
		/** The account open regular. */
		ACCOUNT_OPEN_REGULAR("8", "REGULAR"),
		/** The account inoperative. */
		ACCOUNT_INOPERATIVE("9", "INOPERATIVE"),
		/** The account blocked dormant. */
		ACCOUNT_BLOCKED_DORMANT("10", "BLK_DORMANT"),
		/** The account dormant no debit. */
		ACCOUNT_DORMANT_NO_DEBIT("11", "NO_DR_DORMANT"),
		/** The account dormant no credit. */
		ACCOUNT_DORMANT_NO_CREDIT("12", "NO_CR_DORMANT"),
		/** The account inoperative blocked. */
		ACCOUNT_INOPERATIVE_BLOCKED("13", "BLK_INOP"),
		/** The account inoperative no debit. */
		ACCOUNT_INOPERATIVE_NO_DEBIT("14", "NO_DR_INOP"),
		/** The account inoperative no credit. */
		ACCOUNT_INOPERATIVE_NO_CREDIT("15", "NO_CR_INOP"),
		/** The account open debit with override. */
		ACCOUNT_OPEN_DEBIT_WITH_OVERRIDE("16", "DR_OVERRIDE"),
		/** The account open credit with override. */
		ACCOUNT_OPEN_CREDIT_WITH_OVERRIDE("17", "CR_OVERRIDE"),
		/** The account dormant debit with override. */
		ACCOUNT_DORMANT_DEBIT_WITH_OVERRIDE("18", "DR_OV_DORM"),
		/** The account dormant credit with override. */
		ACCOUNT_DORMANT_CREDIT_WITH_OVERRIDE("19", "CR_OV_DORM"),
		/** The account matured. */
		ACCOUNT_MATURED("20", "MATURED"),
		/** The unclaimed account. */
		UNCLAIMED_ACCOUNT("21", "UNCLAIMED");

		/** The id. */
		private String id;

		/** The code. */
		private String code;

		/**
		 * Instantiates a new account status enum.
		 *
		 * @param id
		 *            the id
		 */
		private AccountStatusEnum(String id, String code) {
			this.id = id;
			this.code = code;
		}

		public Long getId() {
			return Long.parseLong(id);
		}

		public String getCode() {
			return code;
		}

		/**
		 * Gets the by name.
		 *
		 * @param name
		 *            the name
		 * @return the by name
		 */
		public static AccountStatusEnum getById(String id) {
			AccountStatusEnum result = null;
			for (AccountStatusEnum accountType : AccountStatusEnum.values()) {
				if (id.equals(accountType.getId())) {
					result = accountType;
					break;
				}
			}

			return result;
		}

		/**
		 * Gets the all active status codes.
		 *
		 * @return the all active status codes
		 */
		public static List<String> getAllActiveStatusCodes() {
			return Arrays.asList(AccountStatusEnum.ACCOUNT_OPENED_TODAY.code,
					AccountStatusEnum.ACCOUNT_OPEN_REGULAR.code, AccountStatusEnum.ACCOUNT_INOPERATIVE.code);
		}

		/**
		 * Gets the all active status ids.
		 *
		 * @return the all active status ids
		 */
		public static List<String> getAllActiveStatusIds() {
			return Arrays.asList(AccountStatusEnum.ACCOUNT_OPENED_TODAY.id, AccountStatusEnum.ACCOUNT_OPEN_REGULAR.id,
					AccountStatusEnum.ACCOUNT_INOPERATIVE.id);
		}

	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4117073627488130032L;

	/** The id. */
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	@GeneratedValue(generator = "accountStatusSequence")
	private Long id;

	/** The name. */
	@Column(name = "NAME", length = 50)
	private String name;

}
