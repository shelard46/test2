package com.airtelbank.sweepinout.utils;

import com.airtelbank.sweepinout.exception.ApplicationException;

public final class ErrorCode {

	
	/**
	 * DO NOT CHANGE
	 */
	public static final String REQUEST_TIMED_OUT = "2";
	public static final String PROXY_ERROR = "3";
	public static final String TP_ERROR_CONNECTING = "1006";
}
