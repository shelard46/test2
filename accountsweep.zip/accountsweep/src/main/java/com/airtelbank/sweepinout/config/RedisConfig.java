package com.airtelbank.sweepinout.config;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.exceptions.JedisConnectionException;

@Component
@RefreshScope
public class RedisConfig implements AutoCloseable {

	private static final Logger logger = LoggerFactory.getLogger(RedisConfig.class);
	private static String redisHost;
	private static int redisPort;
	private static String redisPassword;
	private static int redisTimeout;
	private static boolean isRedisPaswrdAuthenticated;
	private static RedisConfig redisConfig;
	private static JedisPool jedisPool = null;
	private static Jedis jedis = null;
	private static JedisPoolConfig poolConfig = null;
	
	private static int poolSize;	
	private static int maxConnections;
	private static int minConnections;
	
	@Value("${redis.pool.size}")
	public void setPoolSize(int poolSize) {
		RedisConfig.poolSize = poolSize;
	}	
	
	@Value("${redis.max.idle.threads}")
	public void setMaxConnections(int maxConnections) {
		RedisConfig.maxConnections = maxConnections;
	}	
	
	@Value("${redis.min.idle.threads}")
	public void setMinConnections(int minConnections) {
		RedisConfig.minConnections = minConnections;
	}

	public static RedisConfig getInstance() {
		try {
			if (redisConfig == null) {
				logger.info("Redis config is null. Creating a new one. isRedisPaswrdAuthenticated: {}", isRedisPaswrdAuthenticated);
				redisConfig = new RedisConfig();
				poolConfig = buildPoolConfig();
				jedisPool = (isRedisPaswrdAuthenticated)
						? new JedisPool(poolConfig, redisHost, redisPort, redisTimeout, redisPassword)
						: new JedisPool(poolConfig, redisHost, redisPort);
				jedis = jedisPool.getResource();

			} else {				
				if (poolConfig == null) {
					logger.info("Jedis object is null. Getting new jedis from Jedis Pool.");
					poolConfig = buildPoolConfig();
				}
				if (jedisPool == null) {
					logger.info("Creating new Jedis Pool.");
					jedisPool = (isRedisPaswrdAuthenticated)
							? new JedisPool(poolConfig, redisHost, redisPort, redisTimeout, redisPassword)
							: new JedisPool(poolConfig, redisHost, redisPort);
				} else {
					//logger.info("Jedis Active connection: {}, Waiters: {}, Idle: {}", jedisPool.getNumActive(), jedisPool.getNumWaiters(), jedisPool.getNumIdle());
				}					
				if (jedis == null) {
					logger.info("Jedis object is null. Getting new jedis from Jedis Pool.");
					jedis = jedisPool.getResource();
				}
			}
		} catch (JedisConnectionException jce) {
			logger.error("Couldn't get a resource from Redis Pool: ", jce);
		}
		return redisConfig;
	}

	@Value("${spring.redis.host}")
	public void setRedisHost(String redisHost) {
		RedisConfig.redisHost = redisHost;
	}

	@Value("${spring.redis.port}")
	public void setRedisPort(int redisPort) {
		RedisConfig.redisPort = redisPort;
	}

	@Value("${spring.redis.password}")
	public void setRedisPassword(String redisPassword) {
		RedisConfig.redisPassword = redisPassword;
	}

	@Value("${spring.redis.timeout}")
	public void setRedisTimeout(int redisTimeout) {
		RedisConfig.redisTimeout = redisTimeout;
	}

	@Value("${redis.auth.enabled}")
	public void setIsRedisPaswrdAuthenticated(boolean isRedisPaswrdAuthenticated) {
		RedisConfig.isRedisPaswrdAuthenticated = isRedisPaswrdAuthenticated;
	}

	public JedisPool getJedisPool() {
		return jedisPool;
	}

	public Jedis getJedis() {
		return jedis;
	}

	private static JedisPoolConfig buildPoolConfig() {
		poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(poolSize);
		poolConfig.setMaxIdle(maxConnections);
		poolConfig.setMinIdle(minConnections);
		poolConfig.setTestOnBorrow(true);
		poolConfig.setTestOnReturn(true);
		poolConfig.setTestWhileIdle(true);
		poolConfig.setMinEvictableIdleTimeMillis(Duration.ofSeconds(60).toMillis());
		poolConfig.setTimeBetweenEvictionRunsMillis(Duration.ofSeconds(30).toMillis());
		poolConfig.setNumTestsPerEvictionRun(3);
		poolConfig.setBlockWhenExhausted(true);
		logger.info("created JedisPoolConfig");
		return poolConfig;
	}

	@Override
	public void close() throws Exception {
		logger.info("Cleanup operation. Closing jedis");
		if(jedis != null) {
			jedis.close();
			logger.info("Closed jedis.");
			if(jedis != null && jedis.isConnected()) {
				jedis.disconnect();
			}
		}		
	}
}
