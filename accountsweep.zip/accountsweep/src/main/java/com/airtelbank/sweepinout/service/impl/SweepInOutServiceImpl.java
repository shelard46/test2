package com.airtelbank.sweepinout.service.impl;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.exception.DuplicateDataException;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.InvalidRequestException;
import com.airtelbank.sweepinout.exception.NegativeAmountException;
import com.airtelbank.sweepinout.exception.UpperLimitBreachException;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.helper.ValidationHelper;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.ReconSweepInResponseDto;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.airtelbank.sweepinout.models.SweepInResponseDto;
import com.airtelbank.sweepinout.service.PaymentService;
import com.airtelbank.sweepinout.service.SweepInOutService;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.airtelbank.sweepinout.utils.StageCodes;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.slf4j.Slf4j;

import com.airtelbank.sweepinout.utils.KafkaProducer;

/**
 * AMHI service Implementation.
 * 
 *
 */
@Slf4j
@Service
@RefreshScope
public class SweepInOutServiceImpl implements SweepInOutService {

	@Autowired
	private KibanaErrorLogger kibanaLogger;

	@Autowired
	private DbAuditingHelper dbAuditingHelper;

	@Autowired
	private PaymentService paymentService;

	@Autowired
	private PaymentServiceImplHelper paymentServiceImplHelper;

	@Autowired
	private ValidationHelper validationHelper;

	@Autowired
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	@Autowired
	private AddonAccountRepository addonAccountRepository;
	
	@Autowired
	private SmsUtil smsUtil;
	
	@Autowired
	private KafkaProducer kafkaProducer;
	
	@Autowired
	private Environment env;
	
	@Value("${upper.sweepIn.limit}")
	private int upperSweepInLimit;

	/**
	 * To save AMHI user details.
	 * 
	 * @param amhiRequest
	 */
	@Override
	public ResponseDTO<?> sweepInRequest(SweepInAccountRequest sweepInAccountRequest) {
		if (null == sweepInAccountRequest) {
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidRequestException();
		}
		log.info("SweepIn amount: {}", sweepInAccountRequest.getAmount());
		if(!sweepInAccountRequest.getAmount().contains(".") && Integer.parseInt(sweepInAccountRequest.getAmount())<0) {
            log.error("The amount entered should be positive");
            kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.NEGATIVE_AMOUNT);
            throw new NegativeAmountException();
        } else if(!sweepInAccountRequest.getAmount().contains(".") && Integer.parseInt(sweepInAccountRequest.getAmount())>upperSweepInLimit) {
            log.error("The amount entered should be less than defined maximum sweepIn amount");
            kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.UPPER_LIMIT_BREACH);
            throw new UpperLimitBreachException();
        }
			log.debug("SweepInRequest DB auditing starts with : {}", sweepInAccountRequest.toString());
			if(validationHelper.checkForRecordDublicationRefrence(sweepInAccountRequest.getPaymentRefId())) {
				AddonAccount addonAccount = validationHelper.checkForBlanceCustomer(sweepInAccountRequest.getAccountNo(), sweepInAccountRequest.getAmount());
				paymentServiceImplHelper.getCustomerProfile(sweepInAccountRequest.getAccountNo(), Constants.CONTENT_ID, sweepInAccountRequest.getChannel(), addonAccount.getAirtelAcountNumber());
				SuryodaySweepTxnDetails details = dbAuditingHelper.preAuditingSweepIn(sweepInAccountRequest);
				log.debug("[SweepInOutServiceImpl.sweepInRequest] | SuryodaySweepTxnDetails : {}",details);
				Response response = paymentService.suroydayInternalFundTransafer(sweepInAccountRequest.getPaymentRefId(), details);
				paymentServiceImplHelper.sweepInHelper(response, details);
				SweepInResponseDto dto = new SweepInResponseDto();
				dto.setAmount(""+details.getAmount());
				dto.setTxnDateTime(""+details.getCreatedOn().getTimeInMillis());
				dto.setTxnId(details.getApbTxnId());
				return CommonUtil.createGenericMeta(dto, Constants.REQUEST_SUCCESS,
					Constants.REQUEST_SUCCESS_CODE, Constants.REQUEST_SUCCESS_DESCRIPTION);
			}
			else {
				throw new DuplicateDataException();
			}
	}

	@Override
	public void tokenMoneyDebit(SweepInOutTokenMoneyRequest request) {
		log.debug("TokenMoneyDebit starts with : {}", request);
		SuryodaySweepTxnDetails details = dbAuditingHelper.tokenMoneySweepOutDbAuditing(request,
				Constants.TRANSACTION_DR);
		paymentService.internalFundTransfer(details);
	}

	@Override
	public void sweepOutSuroydayFT(AutoSwpAmtXferLog request) {
		log.debug("sweepOutSuroydayFT starts with : {}", request);
		paymentService.suryodayFundTransfer(dbAuditingHelper.sweepOutSuryodayFT(request, Constants.TRANSACTION_DR));
	}

	@Override
	public ResponseDTO<?> reconSweepInRequest(SweepInReconRequest sweepInReconRequest) throws JsonProcessingException {
		if (null == sweepInReconRequest) {
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidRequestException();
		}
		log.info("SweepIn Recon amount: {}", sweepInReconRequest.getAmount());
		if (Integer.parseInt(sweepInReconRequest.getAmount()) < 0) {
			log.error("The amount entered should be positive");
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.NEGATIVE_AMOUNT);
			throw new NegativeAmountException();
		}
		log.debug("SweepInRequest DB auditing starts with : {}", sweepInReconRequest.toString());
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository
				.findByRefrenceNumber(sweepInReconRequest.getRefrenceNo());
		log.info("suryodaySweepTxnDetails : {}", suryodaySweepTxnDetails);
		
		if(null == suryodaySweepTxnDetails) {
			throw new GenericException(Constants.RECON_ERR_CODE,Constants.RECON_ERR_MSG);
		}
		log.info("Getting account details:");
		AddonAccount accountDetails = addonAccountRepository
				.findByAccountNumber(suryodaySweepTxnDetails.getAccountNumber());
		log.info("accountDetails fetched by given account number: {}", accountDetails);
		ReconSweepInResponseDto dto = new ReconSweepInResponseDto();
		if ((StageCodes.SWEEPIN.toString()).equalsIgnoreCase(suryodaySweepTxnDetails.getFlow())
				&& (StageCodes.TIMEOUT.toString()).equalsIgnoreCase(suryodaySweepTxnDetails.getApbStatus())) {
			log.info("Going to auditing for recon request");
			suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,
					suryodaySweepTxnDetails);
			dto.setAbpTransactionStatus(Constants.EMPTY_STRING + suryodaySweepTxnDetails.getApbStatus());
			dto.setSuryodayTransactionStatus(Constants.EMPTY_STRING + suryodaySweepTxnDetails.getSuryodayStatus());
			dto.setCustomerAccountNo(Constants.EMPTY_STRING + accountDetails.getAirtelAcountNumber());
			log.info("dto response : {}", dto);
		  } else { 
			  return CommonUtil.createGenericMeta(dto, Constants.REQUEST_FAIL, Constants.REQUEST_FAIL_STRING, Constants.REQUEST_FAIL_DESCRIPTION);
			  }
		 
		return CommonUtil.createGenericMeta(dto, Constants.REQUEST_SUCCESS, Constants.REQUEST_SUCCESS_CODE,
				Constants.REQUEST_SUCCESS_DESCRIPTION);
	}

	@Override
	public ResponseDTO<?> reconSweepInRequest(ReconRequest sweepInReconRequest) throws JsonProcessingException {
		if (null == sweepInReconRequest) {
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.OBJ_NOT_FOUND);
			throw new InvalidRequestException();
		}
		log.info("SweepIn Recon2 amount: {}", sweepInReconRequest.getAmount());
		if (Integer.parseInt(sweepInReconRequest.getAmount()) < 0) {
			log.error("The amount entered should be positive");
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.NEGATIVE_AMOUNT);
			throw new NegativeAmountException();
		}
		log.info("ReconRequest2 DB auditing starts with the request: {}", sweepInReconRequest.toString());
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = suryodaySweepTxnDetailsRepository
				.findByRefrenceNumber(sweepInReconRequest.getRefrenceNo());
		log.info("suryodaySweepTxnDetails fetched by refrence number: {}", suryodaySweepTxnDetails);
		if(null == suryodaySweepTxnDetails) {
			throw new GenericException(Constants.RECON_ERR_CODE,Constants.RECON_ERR_MSG);
		}
		log.info("Getting account details:");
		AddonAccount accountDetails = addonAccountRepository
				.findByAccountNumber(sweepInReconRequest.getCustomerAccountNo());
		log.info("accountDetails fetched by given account number: {}", accountDetails);
			
		if(Constants.SWEEPIN.equalsIgnoreCase(sweepInReconRequest.getFlowName())) {
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				paymentService.internalFundTransferSweepIn(suryodaySweepTxnDetails);
				suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
				log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				paymentService.suroydayInternalFundTransafer(null, suryodaySweepTxnDetails);
				suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
				log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
				log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
				log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
		}
		else if(Constants.TOKENMONEY.equalsIgnoreCase(sweepInReconRequest.getFlowName())) {
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
					suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
			log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
				
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				SweepInOutTokenMoneyRequest moneyRequest = new SweepInOutTokenMoneyRequest();
		        moneyRequest.setAmount(Double.valueOf(sweepInReconRequest.getAmount()));
		        moneyRequest.setCodCustNatlNo(sweepInReconRequest.getCustomerAccountNo());
		        moneyRequest.setCustomerSyordayaAccount(sweepInReconRequest.getCustomerAccountNo());
		        moneyRequest.setRefrenceNumber(sweepInReconRequest.getRefrenceNo());
		        moneyRequest.setValueDate(Calendar.getInstance());
		        kafkaProducer.pushOnKafka(moneyRequest, env.getProperty("sweepout.token.money.topic.name"));
		        suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
				log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
		}
		else if(Constants.SWEEPOUT.equalsIgnoreCase(sweepInReconRequest.getFlowName())) {
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
		}
		else if(Constants.SWEEPINREFUND.equalsIgnoreCase(sweepInReconRequest.getFlowName())) {
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_FAIL_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getSuryodayStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
			if(Constants.REQUEST_SUCCESS_DESCRIPTION.equalsIgnoreCase(sweepInReconRequest.getApbStatus())) {
				 suryodaySweepTxnDetails = dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest, suryodaySweepTxnDetails);
					log.info("suryodaySweepTxnDetails: {} ", suryodaySweepTxnDetails);
			}
		}
	
			log.info("Going to hit sendEmail");
			smsUtil.sendEmail(sweepInReconRequest.getCustomerAccountNo(), suryodaySweepTxnDetails.getAmount(), suryodaySweepTxnDetails.getApbTxnId(), suryodaySweepTxnDetails.getValueDate());
			log.info("SendEmail process has done successfully");
			ReconSweepInResponseDto reconSweepInResponseDto = new ReconSweepInResponseDto();		
			reconSweepInResponseDto.setAbpTransactionStatus(Constants.EMPTY_STRING + suryodaySweepTxnDetails.getApbStatus());
			reconSweepInResponseDto.setSuryodayTransactionStatus(Constants.EMPTY_STRING + suryodaySweepTxnDetails.getSuryodayStatus());
			reconSweepInResponseDto.setCustomerAccountNo(Constants.EMPTY_STRING + accountDetails.getAirtelAcountNumber());
			log.info("reconSweepInResponseDto response : {}", reconSweepInResponseDto);
			return CommonUtil.createGenericMeta(reconSweepInResponseDto, Constants.REQUEST_SUCCESS, Constants.REQUEST_SUCCESS_CODE,
			Constants.REQUEST_SUCCESS_DESCRIPTION);
		}
	}	

