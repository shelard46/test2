package com.airtelbank.sweepinout.exception;



import com.airtelbank.sweepinout.dto.ResultDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class NotAPBCustomerException extends GenericException{
 
	private ResultDTO meta;
	private String errorCode;
	private String errorMessage;
	public NotAPBCustomerException(String errorCode, String errorMessage) {
		super(errorCode,errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;	
		
	}
}
