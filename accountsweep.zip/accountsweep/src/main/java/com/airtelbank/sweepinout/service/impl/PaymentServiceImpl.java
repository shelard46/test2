package com.airtelbank.sweepinout.service.impl;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.SuryodayIFTException;
import com.airtelbank.sweepinout.exception.SweepInOutException;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.helper.ValidationHelper;
import com.airtelbank.sweepinout.models.AdditionalDetails;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Before;
import com.airtelbank.sweepinout.models.Customer;
import com.airtelbank.sweepinout.models.DiffParams;
import com.airtelbank.sweepinout.models.FromActorDetails;
import com.airtelbank.sweepinout.models.FtEnquiryResponse;
import com.airtelbank.sweepinout.models.FtResponse;
import com.airtelbank.sweepinout.models.FundTransferRequest;
import com.airtelbank.sweepinout.models.FundTransferRetryRequest;
import com.airtelbank.sweepinout.models.Input;
import com.airtelbank.sweepinout.models.InputForEnquiry;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SessionContext;
import com.airtelbank.sweepinout.models.SessionContextForEnquiry;
import com.airtelbank.sweepinout.models.SupervisorContext;
import com.airtelbank.sweepinout.models.SurodayFundTransferRequest;
import com.airtelbank.sweepinout.models.SweepInResponseDto;
import com.airtelbank.sweepinout.models.ToActorDetails;
import com.airtelbank.sweepinout.service.PaymentService;
import com.airtelbank.sweepinout.service.SweepInOutService;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.GenericRedisProducer;
import com.airtelbank.sweepinout.utils.HttpUtils;
import com.airtelbank.sweepinout.utils.KafkaProducer;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.airtelbank.sweepinout.utils.StageCodes;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RefreshScope
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private HttpUtils httpUtils;

	@Autowired
	private DbAuditingHelper dbAuditingHelper;

	@Autowired
	private Environment env;

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private ValidationHelper validationHelper;
	
	@Value("${date.forward.value}")
	private int dateForward;

	@Value("${suryoday.url}")
	private String suryodayURL;

	@Autowired
	private SmsUtil smsUtil;

	@Value("${zadd.set.name.Suryoday}")
	private String suryodayZaddSet;

	@Autowired
	private PaymentServiceImplHelper paymentServiceImplHelper;

	@Autowired
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	private String pattern = "dd/MM/yyyy";

	@Autowired
	private KibanaErrorLogger kibanaLogger;
	
	@Autowired
	private SweepInOutService sweepInOutService;

	@Override
	public void internalFundTransfer(SuryodaySweepTxnDetails details) {
		log.info("internalFundTransfer start {}", details);
		dbAuditingHelper.internalFundTransferDbAuditing(details);
		Map<String, String> headers = CommonUtil.defaultJsonHadderInRequest();
		FundTransferRequest fundTransferRequest = fundTransferRequestObject(details, Constants.PAYMENT_MODE_REAL);
		String reqJson = new Gson().toJson(fundTransferRequest);
		String ftResponse = httpUtils.hitRequest(env.getProperty("config.ft.url"), reqJson, String.class, headers,
				HttpMethod.POST, false);
		if (ftResponse != null) {
			updateRecordAfterPayment(ftResponse, details);
		} else {
			FundTransferRetryRequest fundTransferRetryRequest = new FundTransferRetryRequest();
			fundTransferRetryRequest.setSuryodayTxnId(details.getId());
			fundTransferRetryRequest.setFundTransferRequest(fundTransferRequest);
			saveAPBFundTransaferRequestForRetry(fundTransferRetryRequest);
			log.info("No Data From Fund Transfer Payment Api");
		}
	}

	@Override
	public void suryodayFundTransfer(SuryodaySweepTxnDetails details) {
		log.info("suryodayFundTransfer start {}", details);
		dbAuditingHelper.SuryodayFundTransferBeforDbAuditing(details);
		dbAuditingHelper.updateSurodayAccountBlance(details);
		paymentServiceImplHelper.sweepOutFinalAudit(suroydayInternalFundTransafer(details.getRefrenceNumber(), details),
				details);
	}

	private FundTransferRequest fundTransferRequestObject(SuryodaySweepTxnDetails details, String mode) {
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		DiffParams diffParams = new DiffParams();
		FromActorDetails fromActorDetails = new FromActorDetails();
		ToActorDetails toActorDetails = new ToActorDetails();
		AdditionalDetails additionalDetails = new AdditionalDetails();
		fundTransferRequest.setAmount(details.getAmount());
		fundTransferRequest.setChannel(details.getChannel());
		diffParams.setDiffParam1("");
		fromActorDetails.setAccountNo(details.getAddonAccount().getAirtelAcountNumber());
		fundTransferRequest.setLatitude("0");
		fundTransferRequest.setLongitude("0");
		fundTransferRequest.setPaymentMode(mode);
		fundTransferRequest.setPaymentRefId(details.getRefrenceNumber());
		fundTransferRequest.setPurposeCode(env.getProperty("ft.purposeCode"));
		fundTransferRequest.setSourceId(env.getProperty("ft.sourceId.out"));
		fundTransferRequest.setSourceIpAdd(env.getProperty("ft.sourceIpAdd"));
		toActorDetails.setAccountNo(env.getProperty("ft.accNo"));
		toActorDetails.setAccountType("GL");
		fundTransferRequest.setTxnCode(env.getProperty("ft.txnCode.out"));
		additionalDetails.setSms("");
		fundTransferRequest.setDiffParams(diffParams);
		fundTransferRequest.setFromActorDetails(fromActorDetails);
		fundTransferRequest.setToActorDetails(toActorDetails);
		fundTransferRequest.setAdditionalDetails(additionalDetails);
		return fundTransferRequest;
	}

	private FundTransferRequest sweepInFundTransferRequestObject(SuryodaySweepTxnDetails details, String mode) {
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		DiffParams diffParams = new DiffParams();
		FromActorDetails fromActorDetails = new FromActorDetails();
		ToActorDetails toActorDetails = new ToActorDetails();
		AdditionalDetails additionalDetails = new AdditionalDetails();
		fundTransferRequest.setAmount(details.getAmount());
		fundTransferRequest.setChannel(details.getChannel());
		diffParams.setDiffParam1("");
		fromActorDetails.setAccountNo(env.getProperty("ft.accNo"));
		fundTransferRequest.setLatitude("0");
		fundTransferRequest.setLongitude("0");
		fundTransferRequest.setPaymentMode(mode);
		fundTransferRequest.setPaymentRefId(details.getRefrenceNumber());
		fundTransferRequest.setPurposeCode(env.getProperty("ft.purposeCde"));
		fundTransferRequest.setSourceId(env.getProperty("ft.sourceId"));
		fundTransferRequest.setSourceIpAdd(env.getProperty("ft.sourceIpAdd"));
		toActorDetails.setAccountNo(details.getAddonAccount().getAirtelAcountNumber());
		toActorDetails.setAccountType("CUS");
		fundTransferRequest.setTxnCode(env.getProperty("ft.txnCode"));
		additionalDetails.setSms("");
		fundTransferRequest.setDiffParams(diffParams);
		fundTransferRequest.setFromActorDetails(fromActorDetails);
		fundTransferRequest.setToActorDetails(toActorDetails);
		fundTransferRequest.setAdditionalDetails(additionalDetails);
		return fundTransferRequest;
	}

	@Override
	public void updateRecordAfterPayment(String ftResponse, SuryodaySweepTxnDetails details) {
		try {
			Gson gsonObj = new Gson();
			FtResponse ftRes = gsonObj.fromJson(ftResponse, FtResponse.class);
			log.info("[PaymentServiceImpl.updateRecordAfterPayment] | Internal Fund Transfer Response :: {}",ftRes);
			if (ftRes.getMeta().getStatus().equals(Constants.REQUEST_SUCCESS_STRING)) {
				log.info("Fund Transfer Payment Successful");
				dbAuditingHelper.internalFundTransferSuccess(details, ftRes.getData().getFtTxnId());
				sendDataForSweepout(details);
			} else if (ftRes.getMeta().getStatus().equals(Constants.REQUEST_FAIL_STRING)) {
				log.info("Fund Transfer Payment failed");
				dbAuditingHelper.internalFundTransferFailure(details, ftRes.getData().getMessage(),
						ftRes.getData().getFtTxnId());
			}
		} catch (Exception e) {
			log.error("updateRecordAfterPayment {}", e.getCause());
		}
	}

	public void sendDataForSweepout(SuryodaySweepTxnDetails details) throws Exception {
		
		log.info("[PaymentServiceImpl.sendDataForSweepout] | customerId :: {}", details.getAddonAccount().getCustomerId());
		
		//Invoke CustomerProfile to determine custType
		Customer customer = paymentServiceImplHelper.getCustomerProfile(details.getAddonAccount().getCustomerNatalId(), Constants.CONTENT_ID, 
				Constants.DEFAULT_CHANNEL, details.getAddonAccount().getAirtelAcountNumber());
		String custType = customer.getCustomerType();
		
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos(details.getApbTxnId());
		Before after = new Before();
		after.setAmtAutoSwp("" + details.getAmount());
		after.setCodAcctNo(details.getAddonAccount().getAccountNumber());
		after.setCodCustId(details.getAddonAccount().getCustomerId());
		after.setCodAcctNo(details.getAddonAccount().getAirtelAcountNumber());
		after.setDatAutoSwp(CommonUtil.formatDate(env.getProperty("cbs.date.formate"), new Date()));
		after.setFlgCustTyp(custType);
		autoSwpAmtXferLog.setAfter(after);
		if (validationHelper.duplicateRecordCheck(autoSwpAmtXferLog)) {
			sweepInOutService.sweepOutSuroydayFT(autoSwpAmtXferLog);
		} else {
			log.info("SweepInOutTokenMoneyRequest duplicate record in kafka {}", autoSwpAmtXferLog);
		}
	}

	public void saveAPBFundTransaferRequestForRetry(FundTransferRetryRequest fundTransferRequest) {
		log.info("saveAPBFundTransaferRequestForRetry {}", fundTransferRequest);
		fundTransferRequest.setRetryCount(fundTransferRequest.getRetryCount() + 1);
		String zaddKey = env.getProperty("zadd.set.name");
		int retryPeriod = env.getProperty("zadd.retry.period.in.min", Integer.class);
		int hsetExpiryTimeInSec = env.getProperty("hset.record.expiry.in.sec", Integer.class);
		String member = fundTransferRequest.getFundTransferRequest().getPaymentRefId();
		GenericRedisProducer.addEntryToZadd(zaddKey, member, retryPeriod);
		GenericRedisProducer.addEntryToRedisHset(member, "value", fundTransferRequest, hsetExpiryTimeInSec);
	}

	public InputForEnquiry suryodayEnquiryObject(Input input, SuryodaySweepTxnDetails details) {
		InputForEnquiry enquiry = new InputForEnquiry();
		enquiry.setOperation("validateReferenceNumber");
		enquiry.setReferenceNumber(input.getSessionContext().getExternalReferenceNo());
		enquiry.setRetryCount(enquiry.getRetryCount() + 1);
		enquiry.setSuryodayTxnId(details.getId());
		SessionContextForEnquiry contextForEnquiry = new SessionContextForEnquiry();
		BeanUtils.copyProperties(input.getSessionContext(), contextForEnquiry);
		enquiry.setSessionContext(contextForEnquiry);
		return enquiry;
	}

	@Override
	public void saveSuryodayFundTransaferRequestForRetry(InputForEnquiry input) {
		log.info("saveSuryodayFundTransaferRequestForRetry {}", input);
		input.setRetryCount(input.getRetryCount() + 1);
		String zaddKey = env.getProperty("zadd.set.name.Suryoday");
		int retryPeriod = env.getProperty("zadd.retry.period.in.min.Suryoday", Integer.class);
		int hsetExpiryTimeInSec = env.getProperty("hset.record.expiry.in.sec.Suryoday", Integer.class);
		String member = input.getReferenceNumber();
		GenericRedisProducer.addEntryToZadd(zaddKey, member, retryPeriod);
		GenericRedisProducer.addEntryToRedisHset(member, "value", input, hsetExpiryTimeInSec);
	}

	private String transactionData1(SuryodaySweepTxnDetails details) {
		if (Constants.TRANSACTION_DR.equals(details.getTransactionType())) {
			return details.getAddonAccount().getAccountNumber() + "|" + details.getAmount() + "|"
					+ env.getProperty("suryoday.currency") + "|" + env.getProperty("suryoday.credit") + "|"
					+ env.getProperty("suryoday.const") + "|" + env.getProperty("suryoday.cr.msg") + "|"
					+ env.getProperty("suryoday.number");
		} else {
			return details.getAddonAccount().getAccountNumber() + "|" + details.getAmount() + "|"
					+ env.getProperty("suryoday.currency") + "|" + env.getProperty("suryoday.debit") + "|"
					+ env.getProperty("suryoday.const") + "|" + env.getProperty("suryoday.dr.msg") + "|"
					+ env.getProperty("suryoday.number");
		}
	}

	private String transactionData2(SuryodaySweepTxnDetails details) {
		if (Constants.TRANSACTION_DR.equals(details.getTransactionType())) {
			return "|" + details.getAmount() + "|" + env.getProperty("suryoday.currency") + "|"
					+ env.getProperty("suryoday.debit") + "|" + env.getProperty("suryoday.const") + "|"
					+ env.getProperty("suryoday.cr.msg") + "|" + env.getProperty("suryoday.number");
		} else {
			return "|" + details.getAmount() + "|" + env.getProperty("suryoday.currency") + "|"
					+ env.getProperty("suryoday.credit") + "|" + env.getProperty("suryoday.const") + "|"
					+ env.getProperty("suryoday.dr.msg") + "|" + env.getProperty("suryoday.number");
		}
	}

	@Override
	public Input createSurodayFundTransferRequest(String refId, SuryodaySweepTxnDetails details) {
		SurodayFundTransferRequest surodayFundTransferRequest = new SurodayFundTransferRequest();
		Input input = new Input();
		SessionContext sessionContext = new SessionContext();
		SupervisorContext supervisorContext = new SupervisorContext();
		supervisorContext.setPrimaryPassword(env.getProperty("suryoday.primaryPassword"));
		supervisorContext.setUserId(env.getProperty("suryoday.userId"));
		sessionContext.setSupervisorContext(supervisorContext);
		sessionContext.setChannel(env.getProperty("suryoday.channel"));
		sessionContext.setExternalReferenceNo(refId);
		input.setSessionContext(sessionContext);
		input.setLoggedInUserId(env.getProperty("suryoday.loggedInUserId"));
		input.setOperation("mfCollectionOrReversal");
		input.setRefNoCumFlag(refId + "|0");
		input.setTransactionData1(transactionData1(details));
		input.setTransactionData2(transactionData2(details));
		input.setValueDate(CommonUtil.formatDate(pattern, details.getValueDate().getTime()));
		surodayFundTransferRequest.setInput(input);
		return input;
	}

	/**
	 * 
	 * Funds transfer from SSFB to APB GL
	 */
	@Override
	public Response suroydayInternalFundTransafer(String refId, SuryodaySweepTxnDetails details) {
		if (refId.length() > Constants.MAX_LEN_REF_ID) {
			log.error("RefId length should not be greater than 20 {}: ", refId.length());
			kibanaLogger.addError(KibanaErrorLogger.LOGGING_TYPE.INVALID_REF_ID);
			throw new com.airtelbank.sweepinout.exception.InvalidRequestException("100",
					"The Length of refId should not be greater than 20");
		}
		Input fundTransferRequest = createSurodayFundTransferRequest(details.getRefrenceNumber(), details);
		String reqXML = "";
		try {
			reqXML = CommonUtil.convertToXMLInJAXB(fundTransferRequest, Input.class);
		} catch (Exception e) {
			log.error("Exception while converting {}", fundTransferRequest);
			throw new GenericException();
		}
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/xml");
		String res = httpUtils.hitRequest(suryodayURL, reqXML, String.class, headers, HttpMethod.POST, true);
		if (res == null) {
			dbAuditingHelper.updateSuryodayRetryStatus(details);
			saveSuryodayFundTransaferRequestForRetry(suryodayEnquiryObject(fundTransferRequest, details));
			throw new SweepInOutException("APB_SWI_021",
					"Sorry! Your transaction is pending to be credited, please try again later");
		}
		// this call handles both SSFB success/ SSFB specific failure
		return validationHelper.sweepinSuryodayIFTValidationError(res, details, true);
	}

	@Override
	public SweepInResponseDto internalFundTransferSweepIn(SuryodaySweepTxnDetails details) {
		log.info("internalFundTransferSweepIn {}", details);
		Map<String, String> headers = CommonUtil.defaultJsonHadderInRequest();
		FundTransferRequest fundTransferRequest = sweepInFundTransferRequestObject(details,
				Constants.PAYMENT_MODE_REAL);
		String reqJson = new Gson().toJson(fundTransferRequest);
		log.info("Going to hit fund transfer request: {} and headers: {}", reqJson, headers);
		String ftResponse = httpUtils.hitRequest(env.getProperty("config.ft.url"), reqJson, String.class, headers,
				HttpMethod.POST, false);
		log.info("response from fund transfer is: {} ", ftResponse);
		if (ftResponse != null) {
			if (!updateForFullSuccess(ftResponse, details)) {
				FundTransferRetryRequest fundTransferRetryRequest = new FundTransferRetryRequest();
				fundTransferRetryRequest.setFundTransferRequest(fundTransferRequest);
				fundTransferRetryRequest.setSuryodayTxnId(details.getId());
				dbAuditingHelper.updateInternalPayRetryStatus(details);
				saveAPBFundTransaferRequestForRetry(fundTransferRetryRequest);
			}
		} else {
			FundTransferRetryRequest fundTransferRetryRequest = new FundTransferRetryRequest();
			fundTransferRetryRequest.setFundTransferRequest(fundTransferRequest);
			fundTransferRetryRequest.setSuryodayTxnId(details.getId());
			dbAuditingHelper.updateInternalPayRetryStatus(details);
			saveAPBFundTransaferRequestForRetry(fundTransferRetryRequest);
			log.info("No Data From Fund Transfer Payment Api for sweepIn");
			throw new GenericException();
		}
		return null;
	}

	public SuryodaySweepTxnDetails refundAfterSweepInFail(SuryodaySweepTxnDetails details) {
		log.info("refundAfterSweepInFail {}", details);
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setRefrenceNumber(Constants.REF + "-" + details.getRefrenceNumber());
		suryodaySweepTxnDetails.setFlow(StageCodes.SWEEPINREFUND.toString());
		suryodaySweepTxnDetails.setTransactionType(Constants.TRANSACTION_DR);
		suryodaySweepTxnDetails.setChannel(details.getChannel());
		suryodaySweepTxnDetails.setAddonAccount(details.getAddonAccount());
		suryodaySweepTxnDetails.setAmount(details.getAmount());
		suryodaySweepTxnDetails.setCreatedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setValueDate(details.getValueDate());
		suryodaySweepTxnDetails.setSuryodayStatus(StageCodes.INITIATED.toString());
		log.info("refundAfterSweepInFail after save new object{}", suryodaySweepTxnDetails);
		return suryodaySweepTxnDetailsRepository.save(suryodaySweepTxnDetails);
	}

	public boolean updateForFullSuccess(String ftResponse, SuryodaySweepTxnDetails details) {
		Gson gsonObj = new Gson();
		FtResponse ftRes = gsonObj.fromJson(ftResponse, FtResponse.class);
		if (ftRes.getMeta().getStatus().equals(Constants.REQUEST_SUCCESS_STRING)) {
			log.info("Fund Transfer Payment Successful Response :: {}", ftRes);
			dbAuditingHelper.finalSuccessAudit(details, ftRes.getData().getFtTxnId());
			// Add SMS here.
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(Constants.CUSTOMER_MSISDN, details.getAddonAccount().getCustomerNatalId());
			map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_SUCCESS);
			map.put(Constants.SMS_NUMBER, details.getAddonAccount().getAirtelAcountNumber());
			map.put(Constants.SURYODAY_ACCOUNT_NO, details.getAccountNumber());
			map.put(Constants.TXN_AMOUNT, details.getAmount().toString());
			map.put(Constants.BALANCE, ftRes.getData().getAvailableBalance());
			map.put(Constants.SURYODAY_BLANCE, details.getSuryodayBln());
			map.put(Constants.TXN_DATE, CommonUtil.formatDate(LocalDateTime.now(), Constants.MESSAGE_DATE_FORMAT));
			map.put(Constants.APB_TXN_ID, details.getApbTxnId());
			if(Constants.CUR_ACCOUNT_TYPE.toUpperCase().equals(MDC.get(Constants.CUST_TYPE))) {
				map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
			}
			else {
				map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
			}
			smsUtil.sendSMSToUser(map);
		} else if (ftRes.getMeta().getStatus().equals(Constants.REQUEST_FAIL_STRING)) {
			log.info("Fund Transfer Payment Response failed :: {}", ftRes);
			if ("93097".equals(ftRes.getMeta().getCode()) || "FT_999".equals(ftRes.getMeta().getCode())
					|| "FT_028".equals(ftRes.getMeta().getCode())) {
				return false;
			} else {
				dbAuditingHelper.internalFundTransferFailure(details, ftRes.getMeta().getDescription(), null);
				// Refund initiated.
				SuryodaySweepTxnDetails suryodaySweepTxnDetails = refundAfterSweepInFail(details);
				dbAuditingHelper.updateSurodayAccountBlance(suryodaySweepTxnDetails);
				paymentServiceImplHelper.sweepOutFinalAudit(suroydayInternalFundTransafer(
						suryodaySweepTxnDetails.getRefrenceNumber(), suryodaySweepTxnDetails), suryodaySweepTxnDetails);
				throw new GenericException();
			}
		}
		return true;
	}

	public String internalFundTransferEnquery(FundTransferRequest consumerModel, SuryodaySweepTxnDetails details) {
		log.info("internalFundTransferEnquery start");
		Map<String, String> httpHeaders = new HashMap<String, String>();
		httpHeaders.put("contentId", Constants.CONTENT_ID);
		httpHeaders.put("channel", Constants.RAPP);
		String enquiryUrl = env.getProperty("config.ft.url") + "/" + consumerModel.getPaymentRefId() + "?sourceId="
				+ consumerModel.getSourceId() + "&txnCode=" + consumerModel.getTxnCode();
		return httpUtils.hitRequest(enquiryUrl, null, FtEnquiryResponse.class, httpHeaders, HttpMethod.GET, false);
	}

	@Override
	public void apbIFTRedisPayment(FundTransferRetryRequest consumerModel) {
		log.info("Method apbIFTRedisPayment");
		try {
			Optional<SuryodaySweepTxnDetails> details = suryodaySweepTxnDetailsRepository
					.findById(consumerModel.getSuryodayTxnId());
			if(!details.isPresent()) {
				throw new Exception("SuryodaySweepTxnDetails not found for suryoday txn Id");
			}
			if (consumerModel.getRetryCount() < Constants.RETRY_CNT) {
				String response = internalFundTransferEnquery(consumerModel.getFundTransferRequest(), details.get());
				if (response == null) {
					dbAuditingHelper.updateInternalPayRetryStatus(details.get());
					saveAPBFundTransaferRequestForRetry(consumerModel);
				} else {
					processPayment(response, details.get());
				}
			} else {
				removeFromRetry(consumerModel.getFundTransferRequest().getPaymentRefId(), "value",
						env.getProperty("zadd.set.name"));
				dbAuditingHelper.updateAPBStatus(details.get(), StageCodes.TIMEOUT.toString());
			}
		} catch (Exception e) {
			log.info("Exception at voltRedisPayment =" + e.getStackTrace());
		}
	}

	@SuppressWarnings("unlikely-arg-type")
	public void processPayment(String response, SuryodaySweepTxnDetails details) {
		ResponseDTO<?> dto = new Gson().fromJson(response, ResponseDTO.class);
		if (dto != null && Constants.REQUEST_SUCCESS == dto.getMeta().getStatus()) {
			log.info("Fund Transfer Payment Successful Response :: {}", dto);
			FtEnquiryResponse ftRes = (FtEnquiryResponse) dto.getData();
			dbAuditingHelper.internalFundTransferSuccess(details, ftRes.getFtTxnId());
			if (StageCodes.SWEEPIN.equals(details.getFlow())) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put(Constants.CUSTOMER_MSISDN, details.getAddonAccount().getCustomerNatalId());
				map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_SUCCESS);
				map.put(Constants.SURYODAY_ACCOUNT_NO, details.getAccountNumber());
				map.put(Constants.TXN_AMOUNT, details.getAmount().toString());
				map.put(Constants.SMS_NUMBER, details.getAddonAccount().getAirtelAcountNumber());
				if(Constants.CUR_ACCOUNT_TYPE.equalsIgnoreCase(MDC.get(Constants.CUST_TYPE))) {
					map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
				}
				else {
					map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
				}
				smsUtil.sendSMSToUser(map);
			} else if (StageCodes.TOKENMONEY.equals(details.getFlow())) {
				updateRecordAfterPayment(response, details);
			}
		} else if (dto != null && Constants.REQUEST_FAIL == dto.getMeta().getStatus()) {
			dbAuditingHelper.internalFundTransferFailure(details, dto.getMeta().getDescription(), null);
			if (StageCodes.SWEEPIN.equals(details.getFlow())) {
				SuryodaySweepTxnDetails suryodaySweepTxnDetails = refundAfterSweepInFail(details);
				dbAuditingHelper.updateSurodayAccountBlance(suryodaySweepTxnDetails);
				paymentServiceImplHelper.sweepOutFinalAudit(suroydayInternalFundTransafer(
						suryodaySweepTxnDetails.getRefrenceNumber(), suryodaySweepTxnDetails), suryodaySweepTxnDetails);
			}
		}
	}

	@Override
	public void suryodayIFTRetry(InputForEnquiry input) {
		log.info("Method suryodayIFTRetry {}", input.toString());
		Optional<SuryodaySweepTxnDetails> details = suryodaySweepTxnDetailsRepository
				.findById(input.getSuryodayTxnId());
		try {
			if(!details.isPresent()) {
				throw new Exception("SuryodaySweepTxnDetails not found for suryoday txn Id");
			}
			if (input.getRetryCount() < Constants.RETRY_CNT) {
				Response res = suroydayEnqueryForSweepInRetry(input, details.get());
				if (res != null) {
					if (StageCodes.SWEEPIN.toString().equalsIgnoreCase(details.get().getFlow())) {
						paymentServiceImplHelper.sweepInHelper(res, details.get());
					} else if (StageCodes.TOKENMONEY.toString().equalsIgnoreCase(details.get().getFlow())
							|| StageCodes.SWEEPOUT.toString().equalsIgnoreCase(details.get().getFlow())
							|| StageCodes.SWEEPINREFUND.toString().equalsIgnoreCase(details.get().getFlow())) {
						paymentServiceImplHelper.sweepOutFinalAudit(
								suroydayInternalFundTransafer(details.get().getRefrenceNumber(), details.get()),
								details.get());
					}
				}
			} else {
				dbAuditingHelper.updateSuryodaySweepInStatus(details.get(), null, StageCodes.TIMEOUT.toString());
				removeFromRetry(input.getReferenceNumber(), "value", env.getProperty("zadd.set.name.Suryoday"));
			}
		} catch (Exception e) {
			log.info("Exception at suryodayIFTRetry =" + e.getStackTrace());
			dbAuditingHelper.updateSuryodayRetryStatus(details.get());
			saveSuryodayFundTransaferRequestForRetry(input);
		}
	}

	public Response suroydayEnqueryForSweepInRetry(InputForEnquiry input, SuryodaySweepTxnDetails details) {
		String reqXML = "";
		try {
			reqXML = CommonUtil.convertToXMLInJAXB(input, InputForEnquiry.class);
			log.debug("reqXML to suryoday {}", reqXML);
			Map<String, String> headers = new HashMap<>();
			headers.put("Content-Type", "application/xml");
			log.info("Going to hit fund transfer request: {} and headers: {}", reqXML, headers);
			String res = httpUtils.hitRequest(env.getProperty("suryoday.base.url") , reqXML,
					String.class, headers, HttpMethod.POST, true);
			if (res == null) {
				dbAuditingHelper.updateSuryodayRetryStatus(details);
				saveSuryodayFundTransaferRequestForRetry(input);
			} else {
				SuryodayIFTException exception = validationHelper.suryodayFTValidation(res);
				if (exception == null) {
					return CommonUtil.convertToObjectFromXMLInJAXB(res, Response.class);
				} else {
					dbAuditingHelper.updateSuryodaySweepInStatus(details, null, StageCodes.FAILED.toString());
					removeFromRetry(input.getReferenceNumber(), "value", env.getProperty("zadd.set.name.Suryoday"));
				}
			}
		} catch (Exception e) {
			log.error("Exception while converting {}", input);
			dbAuditingHelper.updateSuryodayRetryStatus(details);
			saveSuryodayFundTransaferRequestForRetry(input);
		}
		return null;
	}

	public void removeFromRetry(String id, String value, String key) {
		log.info("removing record from redis.");
		GenericRedisProducer.removeEntryFromZadd(key, id);
		GenericRedisProducer.removeEntryFromRedisHashSet(id, value);
	}

}
