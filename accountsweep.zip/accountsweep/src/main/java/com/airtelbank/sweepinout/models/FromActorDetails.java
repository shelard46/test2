package com.airtelbank.sweepinout.models;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@RequiredArgsConstructor
@ToString
public class FromActorDetails {
	private String accountNo;
    private String accountType;

}
