package com.airtelbank.sweepinout.exception;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@ToString
@XmlRootElement(name = "Reason")
public class Reason {
	
	@XmlElement(name = "Message")
	private String Message;

	@XmlElement(name = "Code")
    private String Code;
}
