package com.airtelbank.sweepinout.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.models.RestRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@RefreshScope
public class HttpUtils {
	
	 private static final Logger logger = LoggerFactory.getLogger(HttpUtils.class);
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RestTemplate proxyRestTemplate;
	
	@Value("${rest.call.timeout:#{5000}}")
	private int restTemplateTimeout;
	
		
	@Autowired
	private ObjectMapper objectMapper;
	
	public <Req, Res> Res hitRequest(String url, Req requestObj, Class<Req> classObj, Map<String, String> headers, HttpMethod method, boolean proxyRequired)  {
		Object resultObj = null;
		HttpHeaders httpHeaders = new HttpHeaders();
		HttpEntity<?> entity = null;
		ResponseEntity<?> response=null;	
		if (headers != null && !headers.isEmpty()) {
			httpHeaders = new HttpHeaders();
			Set<String> headerKeySet = headers.keySet();
			for (String key : headerKeySet) {
				httpHeaders.add(key, headers.get(key));
			}
		}
		
		if (requestObj != null) {
			entity = new HttpEntity<>(requestObj, httpHeaders);
		} else {
			entity = new HttpEntity<>(httpHeaders);
		}

		try {
			if(proxyRequired) {
				response = proxyRestTemplate.exchange(url, method, entity, classObj);
			}else {
				response = restTemplate.exchange(url, method, entity, classObj);
			}
			resultObj = response.getBody();
		} catch (RestClientException e) {
			logger.error("Exception in Third Party API Call {}",e.getRootCause());
		}
		return (Res) resultObj;
	}
	

	/**
	 * Invoke post URL.
	 *
	 * @param endpoint the endpoint
	 * @param requestBody the request body
	 * @return the string
	 * @throws JsonProcessingException the json processing exception
	 */
	public String invokePostURL(String endpoint, Object requestBody)
			throws JsonProcessingException {
		long startTime = System.currentTimeMillis();
		logger.info("Hitting endpoint for email service" + endpoint + " with requestBody " + requestBody);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String response = "";
		HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(requestBody), headers);
		ResponseEntity<String> responseBody = restTemplate.exchange(endpoint, HttpMethod.POST, entity, String.class);
		logger.info("responseBody " + responseBody + " received after hitting the email service " + endpoint);
		if (responseBody != null) {
			response = responseBody.getBody();
		}
		logger.info("Total Time taken for hitting url : {} , {} " + endpoint,
				(System.currentTimeMillis() - startTime) + " milliseconds.");
		return response;
	}
	
	 public <T> ResponseEntity<ResponseDTO<T>> sendHttpRequest(RestRequest<T> req) throws RestClientException {
	        try {
	            String uri = null;
	            final Class<T> clazz = req.getResponseClass();
	            HttpMethod httpMethod = null;
	            Map<String, Object> params = null;
	            Object body = null;

	            HttpHeaders headers = new HttpHeaders();
	            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

	            //Adding headers
	            MultiValueMap<String, String> additionalHeaders = req.getHeaders();
	            if (additionalHeaders != null && !additionalHeaders.isEmpty()) {
	                headers.putAll(additionalHeaders);
	            }


	            if (req.getEntity() != null) {
	                body = req.getEntity();
	            }

	            HttpEntity<Object> entity = new HttpEntity<>(body, headers);
	            //mandatory parameters validation.
	            if (StringUtils.isNotBlank(req.getUri()) && req.getResponseClass() != null && req.getHttpMethod() != null) {
	                uri = req.getUri();
	                httpMethod = req.getHttpMethod();
	            } else {
	                throw new GenericException();
	            }

	            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uri);

	            if (req.getParams() != null) {
	                params = req.getParams();
	            }

	            //Adding queryParams
	            if (req.getQueryParams() != null) {
	                builder.queryParams(req.getQueryParams());
	            }

	            return restTemplate.exchange(builder.buildAndExpand(params).toUri(), httpMethod, entity, new ParameterizedTypeReference<ResponseDTO<T>>() {
	                @Override
	            	public Type getType() {
	                    return new MyParameterizedTypeImpl((ParameterizedType) super.getType(), new Type[]{clazz});
	                }
	            });
	        }catch(HttpStatusCodeException ex) {
	        	logger.error("Third Party API call fails");
	        	throw new GenericException();
	        }
	        catch (ResourceAccessException e) {
	            ResultDTO resultDTO = new ResultDTO();
	            resultDTO.setCode(String.valueOf(HttpStatus.GATEWAY_TIMEOUT));
	            resultDTO.setDescription(String.valueOf(restTemplateTimeout));
	            resultDTO.setStatus(Constants.REQUEST_FAIL);
	            ResponseDTO responseDTO = new ResponseDTO();
	            responseDTO.setMeta(resultDTO);
	        	StringWriter sw = new StringWriter();
				e.printStackTrace(new PrintWriter(sw));
				logger.error("Exception while gettting Rest Utilsl########## {}",sw.toString());
				throw new GenericException();
	        }
	    }
	    
	    public class MyParameterizedTypeImpl implements ParameterizedType {
	        private ParameterizedType delegate;
	        private Type[] actualTypeArguments;

	        MyParameterizedTypeImpl(ParameterizedType delegate, Type[] actualTypeArguments) {
	            this.delegate = delegate;
	            this.actualTypeArguments = actualTypeArguments;
	        }

	        @Override
	        public Type[] getActualTypeArguments() {
	            return actualTypeArguments;
	        }

	        @Override
	        public Type getRawType() {
	            return delegate.getRawType();
	        }

	        @Override
	        public Type getOwnerType() {
	            return delegate.getOwnerType();
	        }
	    }
	
}
