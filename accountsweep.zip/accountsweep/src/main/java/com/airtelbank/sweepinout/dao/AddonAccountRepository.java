package com.airtelbank.sweepinout.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airtelbank.sweepinout.dao.entities.AddonAccount;

public interface AddonAccountRepository extends JpaRepository<AddonAccount, Long> {
	
	AddonAccount findByAccountNumber(String accountNumber);
	AddonAccount findByCustomerNatalId(String customerNatalId);
	AddonAccount findByAirtelAcountNumber(String airtelAcountNumber);
}
