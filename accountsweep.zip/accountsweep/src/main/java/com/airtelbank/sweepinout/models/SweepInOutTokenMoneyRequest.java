package com.airtelbank.sweepinout.models;

import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class SweepInOutTokenMoneyRequest {
	
	private String codCustNatlNo;
	private String customerSyordayaAccount;
	private Calendar valueDate;
	private String refrenceNumber;
	private Double amount;
	
}
