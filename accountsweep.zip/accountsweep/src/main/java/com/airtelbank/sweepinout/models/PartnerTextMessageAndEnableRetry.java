package com.airtelbank.sweepinout.models;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * The Class PartnerTextMessageAndEnableRetry.
 */
@Getter
@Setter
@RequiredArgsConstructor
public class PartnerTextMessageAndEnableRetry {
	
	/** The text message. */
	private String textMessage;
	
	/** The enable retry. */
	private boolean enableRetry;
}
