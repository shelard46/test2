package com.airtelbank.sweepinout.config.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Component;

import com.aerospike.client.Log;
import com.airtelbank.sweepinout.models.LoggerModel;

@Component
public class KibanaErrorLogger {

	public enum LOGGING_TYPE {
		 DUPLICATE_TRANSACTION, INSUFFICIENT_FUND, INVALID_ACCOUNT_TYPE, INVALID_MIN_AMOUNT, INVALID_TRANSACTION, INVALID_ACCOUNT, NEGATIVE_AMOUNT, 
		 EXCEED_TRANSACTION_LIMIT, INVALID_BENEFICIARY, INACTIVE_ACCOUNT, DORMANT_ACCOUNT, ESCHEAT_ACCOUNT, CLOSED_ACCOUNT, DECEASED_CUST, 
		 RESTRICT_ACCOUNT, EXCEED_TRANS_LIMIT, RESTRICT_CUST, REQUIRED_USER_ID, INVALID_USER, OBJ_NOT_FOUND, DEF, INVALID_REF_ID, UPPER_LIMIT_BREACH,
		INVALID_AFTER_OBJECT;
	}

	@Autowired
	MessageSource messageSource;

	public void addError(LOGGING_TYPE handler) {
		try {
			LoggerModel loggerModel = SweepInOutThreadLocal.getValue();
			switch (handler) {
			case DUPLICATE_TRANSACTION:
				loggerModel.addError(messageSource.getMessage("code.suryoday.duplicate.transaction", null, null),
						messageSource.getMessage("code.suryoday.duplicate.transaction.desc", null, null));
				break;
			case INSUFFICIENT_FUND:
				loggerModel.addError(messageSource.getMessage("code.suryoday.insufficient.fund", null, null),
						messageSource.getMessage("code.suryoday.insufficient.fund.desc", null, null));
				break;
			case INVALID_ACCOUNT_TYPE:
				loggerModel.addError(messageSource.getMessage("code.suryoday.invalid.account.type", null, null),
						messageSource.getMessage("code.suryoday.invalid.account.type.desc", null, null));
				break;
			case INVALID_MIN_AMOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.invalid.min.amount", null, null),
						messageSource.getMessage("code.code.suryoday.invalid.min.amount.des", null, null));
				break;
			case INVALID_TRANSACTION:
				loggerModel.addError(messageSource.getMessage("code.suryoday.invalid.min.amount", null, null),
						messageSource.getMessage("code.code.suryoday.invalid.min.amount.desc", null, null));
				break;
			case INVALID_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.invalid.account", null, null),
						messageSource.getMessage("code.suryoday.invalid.account.desc", null, null));
				break;
			case NEGATIVE_AMOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.negative.amount", null, null),
						messageSource.getMessage("code.suryoday.negative.amount.desc", null, null));
				break;
			case EXCEED_TRANSACTION_LIMIT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.exceed.transaction.limit", null, null),
						messageSource.getMessage("code.suryoday.exceed.transaction.limit.desc", null, null));
				break;
			case INVALID_BENEFICIARY:
				loggerModel.addError(messageSource.getMessage("code.suryoday.invalid.beneficiary", null, null),
						messageSource.getMessage("code.suryoday.invalid.beneficiary.desc", null, null));
				break;
			case INACTIVE_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.inactive.account", null, null),
						messageSource.getMessage("code.suryoday.inactive.account.desc", null, null));
				break;
			case DORMANT_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.dormant.account", null, null),
						messageSource.getMessage("code.suryoday.dormant.account.desc", null, null));
				break;
			case ESCHEAT_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.escheat.account", null, null),
						messageSource.getMessage("code.suryoday.escheat.account.desc", null, null));
				break;
			case CLOSED_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.account.closed", null, null),
						messageSource.getMessage("code.suryoday.account.closed.desc", null, null));
				break;
			case DECEASED_CUST:
				loggerModel.addError(messageSource.getMessage("code.suryoday.customer.deceased", null, null),
						messageSource.getMessage("code.suryoday.customer.deceased.desc", null, null));
				break;
			case RESTRICT_ACCOUNT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.account.restrict", null, null),
						messageSource.getMessage("code.suryoday.account.restrict.desc", null, null));
				break;
			case EXCEED_TRANS_LIMIT:
				loggerModel.addError(messageSource.getMessage("code.suryoday.transaction.limit.exceed", null, null),
						messageSource.getMessage("code.suryoday.transaction.limit.exceed.desc", null, null));
				break;
			case RESTRICT_CUST:
				loggerModel.addError(
						messageSource.getMessage("code.suryoday.customer.restrict", null, null),
						messageSource.getMessage("code.suryoday.customer.restrict.desc", null, null));
				break;
			case REQUIRED_USER_ID:
				loggerModel.addError(
						messageSource.getMessage("code.suryoday.required.user.id", null, null),
						messageSource.getMessage("code.suryoday.required.user.id.desc", null, null));
				break;
			case INVALID_USER:
				loggerModel.addError(
						messageSource.getMessage("code.suryoday.invalid.user", null, null),
						messageSource.getMessage("code.suryoday.invalid.user.desc", null, null));
				break;
			case OBJ_NOT_FOUND:
				loggerModel.addError(
						messageSource.getMessage("code.suryoday.object.not.found", null, null),
						messageSource.getMessage("code.suryoday.object.not.found.desc", null, null));
				break;
			case INVALID_REF_ID:
				loggerModel.addError(
						messageSource.getMessage("code.suryoday.unidentified.error", null, null),
						messageSource.getMessage("code.suryoday.unidentified.error.desc", null, null));
				break;
			case UPPER_LIMIT_BREACH:
				loggerModel.addError(messageSource.getMessage("code.suryoday.upper.limit.error", null, null),
						messageSource.getMessage("code.suryoday.upper.limit.desc", null, null));
				break;

				case INVALID_AFTER_OBJECT:
					loggerModel.addError(messageSource.getMessage("invalid.after.object.errorCode", null, null),
							messageSource.getMessage("invalid.after.object.errorMessage", null, null));
					break;

			default:
				loggerModel.addError(messageSource.getMessage("code.suryoday.unidentified.error", null, null),
						messageSource.getMessage("code.suryoday.unidentified.error.desc", null, null));
				break;
			}
		} catch (NoSuchMessageException e) {
			Log.error(e.getMessage());
		}
	}
	
	public void addError(LOGGING_TYPE handler, String desc) {
		addError(handler);
		LoggerModel loggerModel = SweepInOutThreadLocal.getValue();
		loggerModel.getErrors().get(loggerModel.getErrors().size() - 1).setErrorDescription(desc);
	}

}
