package com.airtelbank.sweepinout.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoggerModel {

	private String serviceId;
	private String apiId;
	private String custMobileNo;
	private String contentId;
	private String tranId;
	private String amount;
	private String id1;
	private String id2;
	private String id3;
	private String id4;
	private String id5;
	private String id6;
	private String id7;
	private String id8;
	private String id9;
	private String id10;
	private long number1;
	private long number2;
	private long number3;
	private Date date1;
	private Date date2;
	Object requestData;
	Object responseData;
	private String responseCode;
	private Date totalTime;
	private List<LoggerError> errors = new ArrayList<>();
	private List<MethodStats> methods = new ArrayList<>();

	public void addMethod(String methodName, long time) {
		this.methods.add(new MethodStats(methodName, time));
	}

	public void addError(String code, String desc) {
		this.errors.add(new LoggerError(code, desc));
	}

	public void addError(String code, String desc, int status) {
		this.errors.add(new LoggerError(code, desc, status));
	}

	public static class LoggerError {

		private String errorCode;
		private String errorDescription;
		private int status;

		public LoggerError() {

		}

		public LoggerError(String errorCode, String errorDescription) {
			this.errorCode = errorCode;
			this.errorDescription = errorDescription;
		}

		public LoggerError(String errorCode, String errorDescription, int status) {
			this.errorCode = errorCode;
			this.errorDescription = errorDescription;
			this.status = status;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}

		public String getErrorDescription() {
			return errorDescription;
		}

		public void setErrorDescription(String errorDescription) {
			this.errorDescription = errorDescription;
		}

		@Override
		public String toString() {
			return " errorCode " + errorCode + " errorDescription " + errorDescription + " ";
		}
	}

	public static class MethodStats {
		private String methodName;
		private long methodTime;

		public String getMethodName() {
			return methodName;
		}

		public void setMethodName(String methodName) {
			this.methodName = methodName;
		}

		public long getMethodTime() {
			return methodTime;
		}

		public void setMethodTime(long methodTime) {
			this.methodTime = methodTime;
		}

		public MethodStats(String methodName, long methodTime) {
			this.methodName = methodName;
			this.methodTime = methodTime;
		}

	}

}
