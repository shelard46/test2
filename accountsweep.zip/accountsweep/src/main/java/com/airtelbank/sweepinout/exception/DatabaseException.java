package com.airtelbank.sweepinout.exception;

import com.airtelbank.sweepinout.dto.ResultDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DatabaseException extends RuntimeException{
	private ResultDTO meta;
	private String errorCode;
	private String errorMessage;
	
	public DatabaseException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;	
	}
}
