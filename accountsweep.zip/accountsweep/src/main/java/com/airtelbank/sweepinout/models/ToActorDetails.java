package com.airtelbank.sweepinout.models;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class ToActorDetails {
	private String accountNo;
    private String accountType;
}
