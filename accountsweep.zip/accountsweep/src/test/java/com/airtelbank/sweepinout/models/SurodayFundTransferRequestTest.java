package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SurodayFundTransferRequestTest {

	@Test
	public void surodayFundTransferRequestTest() {
		SurodayFundTransferRequest surodayFundTransferRequest = new SurodayFundTransferRequest();
		Input input = new Input();
 		SessionContext sessionContext = new SessionContext();
 		SupervisorContext supervisorContext = new SupervisorContext();
 		supervisorContext.setPrimaryPassword("");
 		supervisorContext.setUserId("");
 		sessionContext.setSupervisorContext(supervisorContext);
 		sessionContext.setChannel("");
 		sessionContext.setExternalReferenceNo("");
 		input.setSessionContext(sessionContext);
 		input.setLoggedInUserId("");
 		input.setOperation("mfCollectionOrReversal");
 		input.setRefNoCumFlag("");
 		
 		input.setTransactionData1("");
 		input.setTransactionData2("");
 		surodayFundTransferRequest.setInput(input);
 		surodayFundTransferRequest.toString();
 		SurodayFundTransferRequest surodayFundTransferRequest1 = new SurodayFundTransferRequest(new Input());
	}
}
