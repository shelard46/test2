package com.airtelbank.sweepinout.utils;


import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.protocol.HTTP;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.sweepinout.exception.ApplicationException;
import com.airtelbank.sweepinout.filter.ContentTypeTextToTextPlain;
import com.airtelbank.sweepinout.models.PartnerTextMessageAndEnableRetry;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
public class SmsUtilTest {
	
	
	@InjectMocks
	SmsUtil smsUtil;	
		
	@Mock
	private ObjectMapper objectMapper;
	
	@Mock
	private ContentTypeTextToTextPlain contentTypeTextToTextPlain;
	
	@Mock
	private HttpUtils httpUtil;
	
	@Test
	public void prepareSendEmailObjectTest() {
		ReflectionTestUtils.setField(smsUtil, "senderName", "senderName");
		ReflectionTestUtils.setField(smsUtil, "tpIntegrationsServiceId", "tpIntegrationsServiceId");
		ReflectionTestUtils.setField(smsUtil, "successResponseCode", "successResponseCode");
		ReflectionTestUtils.setField(smsUtil, "errorResponseCode", "errorResponseCode");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentFail", "smsTextSuryodayPaymentFail");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentSuccess", "smsTextSuryodayPaymentSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentHold", "smsTextSuryodayPaymentHold");
		ReflectionTestUtils.setField(smsUtil, "smsSendingEndpoint", "smsSendingEndpoint");
		ReflectionTestUtils.setField(smsUtil, "smsSentStatus", "smsSentStatus");
		ReflectionTestUtils.setField(smsUtil, "sweepoutSucess", "sweepoutSucess");
		ReflectionTestUtils.setField(smsUtil, "langId", "langId");
		ReflectionTestUtils.setField(smsUtil, "extRefNo", "extRefNo");
		ReflectionTestUtils.setField(smsUtil, "firstRecipient", "firstRecipient");
		ReflectionTestUtils.setField(smsUtil, "secondRecipient", "secondRecipient");
		ReflectionTestUtils.setField(smsUtil, "emailSender", "emailSender");
		ReflectionTestUtils.setField(smsUtil, "emailTempCode", "emailTempCode");
		ReflectionTestUtils.setField(smsUtil, "emailBodyKey", "emailBodyKey");
		ReflectionTestUtils.setField(smsUtil, "emailBodyValue", "emailBodyValue");
		ReflectionTestUtils.setField(smsUtil, "emailSubject", "emailSubject");
		ReflectionTestUtils.setField(smsUtil, "tokenmoneySucess", "tokenmoneySucess");
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentFail", "smsTextCurSuryodayPaymentFail");
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentSuccess", "smsTextCurSuryodayPaymentSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTestCurSweepOutSuccess", "smsTestCurSweepOutSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTestCurTokenMoneySuccess", "smsTestCurTokenMoneySuccess");
		smsUtil.prepareSendEmailObject("123456789", BigDecimal.ONE, "987654321", Calendar.getInstance());
	}
	
	@Test
	public void prepareSendSMSObjectTest() {
		PartnerTextMessageAndEnableRetry obj=new PartnerTextMessageAndEnableRetry();
		obj.setTextMessage("1221i2920");
		obj.setEnableRetry(true);
		smsUtil.prepareSendSMSObject(null, obj, "9876543221");
	}
	
	@Test
	public void sendEmailTest() throws JsonProcessingException {
		ReflectionTestUtils.setField(smsUtil, "senderName", "senderName");
		ReflectionTestUtils.setField(smsUtil, "tpIntegrationsServiceId", "tpIntegrationsServiceId");
		ReflectionTestUtils.setField(smsUtil, "successResponseCode", "successResponseCode");
		ReflectionTestUtils.setField(smsUtil, "errorResponseCode", "errorResponseCode");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentFail", "smsTextSuryodayPaymentFail");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentSuccess", "smsTextSuryodayPaymentSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentHold", "smsTextSuryodayPaymentHold");
		ReflectionTestUtils.setField(smsUtil, "smsSendingEndpoint", "smsSendingEndpoint");
		ReflectionTestUtils.setField(smsUtil, "smsSentStatus", "smsSentStatus");
		ReflectionTestUtils.setField(smsUtil, "sweepoutSucess", "sweepoutSucess");
		ReflectionTestUtils.setField(smsUtil, "langId", "langId");
		ReflectionTestUtils.setField(smsUtil, "extRefNo", "extRefNo");
		ReflectionTestUtils.setField(smsUtil, "firstRecipient", "firstRecipient");
		ReflectionTestUtils.setField(smsUtil, "secondRecipient", "secondRecipient");
		ReflectionTestUtils.setField(smsUtil, "emailSender", "emailSender");
		ReflectionTestUtils.setField(smsUtil, "emailTempCode", "emailTempCode");
		ReflectionTestUtils.setField(smsUtil, "emailBodyKey", "emailBodyKey");
		ReflectionTestUtils.setField(smsUtil, "emailBodyValue", "emailBodyValue");
		ReflectionTestUtils.setField(smsUtil, "emailSubject", "emailSubject");
		ReflectionTestUtils.setField(smsUtil, "tokenmoneySucess", "tokenmoneySucess");
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentFail", "smsTextCurSuryodayPaymentFail");
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentSuccess", "smsTextCurSuryodayPaymentSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTestCurSweepOutSuccess", "smsTestCurSweepOutSuccess");
		ReflectionTestUtils.setField(smsUtil, "smsTestCurTokenMoneySuccess", "smsTestCurTokenMoneySuccess");
		PartnerTextMessageAndEnableRetry obj=new PartnerTextMessageAndEnableRetry();
		obj.setTextMessage("1221i2920");
		obj.setEnableRetry(true);
		smsUtil.sendEmail("121243287", BigDecimal.ONE, "121876721",Calendar.getInstance());;
	}
	
	@Test
	public void sendSMSToUserTest() {
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentFail", "smsTextSuryodayPaymentFail");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_FAIL);
		map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest1() {
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentSuccess", "smsTextSuryodayPaymentSuccess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest2() {
		ReflectionTestUtils.setField(smsUtil, "smsTextSuryodayPaymentHold", "smsTextSuryodayPaymentHold");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_HOLD);
		map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest3() {
		ReflectionTestUtils.setField(smsUtil, "sweepoutSucess", "sweepoutSucess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPOUT_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest4() {
		ReflectionTestUtils.setField(smsUtil, "tokenmoneySucess", "tokenmoneySucess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.TOKENMONEY_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.SBA_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest5() {
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentFail", "smsTextCurSuryodayPaymentFail");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_FAIL);
		map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest6() {
		ReflectionTestUtils.setField(smsUtil, "smsTextCurSuryodayPaymentSuccess", "smsTextCurSuryodayPaymentSuccess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPIN_SURYODAY_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
		map.put(Constants.SMS_NUMBER, "9999999999");
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest7() {
		ReflectionTestUtils.setField(smsUtil, "smsTestCurSweepOutSuccess", "smsTestCurSweepOutSuccess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.SWEEPOUT_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
		map.put(Constants.SMS_NUMBER, "9999999999");
		smsUtil.sendSMSToUser(map);
	}
	
	@Test
	public void sendSMSToUserTest8() {
		ReflectionTestUtils.setField(smsUtil, "smsTestCurTokenMoneySuccess", "smsTestCurTokenMoneySuccess");
		Map<String, Object> map=new HashMap<>();
		map.put(Constants.SMS, Constants.TOKENMONEY_SUCCESS);
		map.put(Constants.CUST_TYPE, Constants.CUR_ACCOUNT_TYPE);
		smsUtil.sendSMSToUser(map);
	}
	
}
