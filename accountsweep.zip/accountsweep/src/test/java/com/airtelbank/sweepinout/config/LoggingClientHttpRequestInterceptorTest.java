package com.airtelbank.sweepinout.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.MultiValueMap;

import com.airtelbank.sweepinout.config.log.LoggingClientHttpRequestInterceptor;

@RunWith(MockitoJUnitRunner.class)
public class LoggingClientHttpRequestInterceptorTest {
	
	@InjectMocks
	LoggingClientHttpRequestInterceptor loggingClientHttpRequestInterceptor;	
	
	@Test
	public void interceptTest() throws IOException {
		   HttpRequest request = new HttpRequest() {
			
			@Override
			public HttpHeaders getHeaders() {
				MultiValueMap<String, String> headers = new HttpHeaders();
				headers.add("contentId", "12345");
				headers.add("channel", "RAPP");
				HttpHeaders httpHeaders=new HttpHeaders(headers);
				return httpHeaders;
			}
			
			@Override
			public URI getURI() {
				URI uri=null;
				try {
					uri = new URI("10.56.110.191/api/vi");
				} catch (URISyntaxException e) {
					e.printStackTrace();
				}
				return uri;
			}
			
			@Override
			public String getMethodValue() {
				return null;
			}
			
			@Override
			public HttpMethod getMethod() {
				return HttpMethod.POST;
			}
		};
		ClientHttpRequestExecution execution=new ClientHttpRequestExecution() {
			
			@Override
			public ClientHttpResponse execute(HttpRequest request, byte[] body) throws IOException {
				ClientHttpResponse clientHttpResponse=new ClientHttpResponse() {
					
					@Override
					public HttpHeaders getHeaders() {
						MultiValueMap<String, String> headers = new HttpHeaders();
						headers.add("Content-Type", "application/json");
						headers.add("contentId", "12345");
						headers.add("channel", "RAPP");
						HttpHeaders httpHeaders=new HttpHeaders(headers);
						return httpHeaders;
					}
					
					@Override
					public InputStream getBody() throws IOException {
						byte[] initialArray = { 0, 1, 2 };
					    InputStream targetStream = new ByteArrayInputStream(initialArray);
						return targetStream;
					}
					
					@Override
					public String getStatusText() throws IOException {
						return "OK";
					}
					
					@Override
					public HttpStatus getStatusCode() throws IOException {
						return HttpStatus.OK;
					}
					
					@Override
					public int getRawStatusCode() throws IOException {
						return 200;
					}
					
					@Override
					public void close() {
						// TODO Auto-generated method stub
						
					}
				};
				return clientHttpResponse;
			}
		};
		byte[] body = { 0, 1, 2 };
		loggingClientHttpRequestInterceptor.intercept(request, body, execution);
	}
	
}