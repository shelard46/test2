package com.airtelbank.sweepinout.models;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FundTransferRequestTest {
	@Test
	public void fundTransferRequest() {
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		fundTransferRequest.setSourceId("");
		fundTransferRequest.setAmount(BigDecimal.ONE);
		fundTransferRequest.setTxnGroupId("");
		fundTransferRequest.setSourceIpAdd("");
		FromActorDetails fromActorDetails=new FromActorDetails();
		fundTransferRequest.setFromActorDetails(fromActorDetails);
		fundTransferRequest.setPaymentMode("");
		fundTransferRequest.setLatitude("");
		fundTransferRequest.setChannel("");
		fundTransferRequest.setLimitDetails("");
		fundTransferRequest.setPaymentRefId("");
		DiffParams diffParams=new DiffParams();
		fundTransferRequest.setDiffParams(diffParams);
		ToActorDetails toActorDetails=new ToActorDetails();
		fundTransferRequest.setToActorDetails(toActorDetails);
		fundTransferRequest.setTxnCode("");
		fundTransferRequest.setPurposeCode("");
		fundTransferRequest.setLongitude("");
		fundTransferRequest.setRefundPaymentRefId("");
		fundTransferRequest.setReverseSc("");
		OnBehalfDetails onBehalfDetails=new OnBehalfDetails(); 
		fundTransferRequest.setOnBehalfDetails(onBehalfDetails);
		AdditionalDetails additionalDetails=new AdditionalDetails();
		fundTransferRequest.setAdditionalDetails(additionalDetails);
		assertEquals("",fundTransferRequest.getSourceId());
		assertEquals(BigDecimal.ONE,fundTransferRequest.getAmount());
		assertEquals("",fundTransferRequest.getTxnGroupId());
		assertEquals("",fundTransferRequest.getSourceIpAdd());
		assertEquals(fromActorDetails,fundTransferRequest.getFromActorDetails());
		assertEquals("",fundTransferRequest.getPaymentMode());
		assertEquals("",fundTransferRequest.getLatitude());
		assertEquals("",fundTransferRequest.getChannel());
		assertEquals("",fundTransferRequest.getLimitDetails());
		assertEquals("",fundTransferRequest.getPaymentRefId());
		assertEquals(diffParams,fundTransferRequest.getDiffParams());
		assertEquals(toActorDetails,fundTransferRequest.getToActorDetails());
		assertEquals("",fundTransferRequest.getTxnCode());
		assertEquals("",fundTransferRequest.getPurposeCode());
		assertEquals("",fundTransferRequest.getLongitude());
		assertEquals("",fundTransferRequest.getRefundPaymentRefId());
		assertEquals("",fundTransferRequest.getReverseSc());
		assertEquals(onBehalfDetails,fundTransferRequest.getOnBehalfDetails());
		assertEquals(additionalDetails,fundTransferRequest.getAdditionalDetails());
	}

}	
	