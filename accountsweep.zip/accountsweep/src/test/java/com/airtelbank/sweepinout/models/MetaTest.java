package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import com.sun.javafx.font.Metrics;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class MetaTest {
	@Test
	public void meta() {
		Meta meta = new Meta();
		
		meta.setCode("");
		meta.setDescription("");
		meta.setStatus("");		
	}
}

	