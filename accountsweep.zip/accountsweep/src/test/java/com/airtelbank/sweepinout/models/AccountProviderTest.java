package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dao.entities.AccountProvider;

@RunWith(SpringRunner.class)
public class AccountProviderTest {
	
	@Test
	public void accountProvider() {
	
	 AccountProvider accountProvider = new AccountProvider();
	 accountProvider.setCode("");
	 accountProvider.setId(0L);
	 accountProvider.setName("");
}
}
