package com.airtelbank.sweepinout.models;

import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;

@RunWith(SpringRunner.class)
public class SweepInOutResponseDtoTest {
	@Test
	public void sweepInOutResponseDto() {
		ResponseDTO<?> sweepInOutResponseDto = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
     	Data data = new Data();
     	meta.setCode("000");
     	meta.setDescription("SUCCESS");
     	meta.setStatus(0);
     	data.setAvailableBalance("");
     	data.setBalAfterTxn("");
     	data.setCharges("");
     	data.setHoldBalance("");
     	data.setFtTxnId("FT1914212127661");
		sweepInOutResponseDto.setMeta(meta);
		
	}
}

