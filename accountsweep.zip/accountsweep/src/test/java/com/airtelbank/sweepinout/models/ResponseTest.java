package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ResponseTest {
	@Test
	public void response() {
		Response response = new Response();
		TransactionStatus transactionStatus = new TransactionStatus();
		transactionStatus.setErrorCode("");
		transactionStatus.setExternalReferenceNo("");
		transactionStatus.setReplyCode("");
		transactionStatus.setReplyText("");
		response.setTransactionRefNumber("");
		response.setTransactionStatus(transactionStatus);
	}

}
