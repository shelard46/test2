package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ErrorResponseFundTransferTest {
	@Test
	public void errorResponseFundTransfer() {
		ErrorResponseFundTransfer errorResponseFundTransfer= new ErrorResponseFundTransfer();
		Exception ex = new Exception();
		Reason reason = new Reason();
		reason.setCode("");
		reason.setMessage("");
		ex.setErrorMessage("");
		ex.setErrorMessage("");
		ex.setReason(reason);
		ex.setResponse("");
		ex.setStackTrace("");
		errorResponseFundTransfer.setException(ex);
		errorResponseFundTransfer.toString();
		ErrorResponseFundTransfer errorResponseFundTransfer1= new ErrorResponseFundTransfer(new Exception());;
	}
}
