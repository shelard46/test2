package com.airtelbank.sweepinout.service;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.exception.CustomerValidationException;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.models.AccountResponse;
import com.airtelbank.sweepinout.models.Balance;
import com.airtelbank.sweepinout.models.Customer;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.TransactionStatus;
import com.airtelbank.sweepinout.service.impl.PaymentServiceImplHelper;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.HttpUtils;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.airtelbank.sweepinout.utils.StageCodes;

@RunWith(MockitoJUnitRunner.class)
public class PaymentServiceImplHelperTest {


	@InjectMocks
	PaymentServiceImplHelper paymentServiceImplHelper;

	@Mock
	private DbAuditingHelper dbAuditingHelper;

	@Mock
	private PaymentService paymentService;

	@Mock
	private SmsUtil smsUtil;

	@Mock
	private HttpUtils httpUtil;

	@Mock
	private MessageSource messageSource;

	@Test
	public void sweepInHelperTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails=new SuryodaySweepTxnDetails();
		Response res=new Response();
		TransactionStatus status= new TransactionStatus();
		status.setErrorCode("0");
		res.setTransactionStatus(status);
		paymentServiceImplHelper.sweepInHelper(res, suryodaySweepTxnDetails);
	}

	@Test
	public void sweepInHelperTest1() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails=new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAccountNumber("282178");
		suryodaySweepTxnDetails.setAmount(BigDecimal.ONE);
		AddonAccount addonAccount=new AddonAccount();
		addonAccount.setAirtelAcountNumber("28612821");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);

		Response res=new Response();
		TransactionStatus status= new TransactionStatus();
		status.setErrorCode("1");
		res.setTransactionStatus(status);
		when(dbAuditingHelper.updateSuryodaySweepInStatus(suryodaySweepTxnDetails, res.getTransactionRefNumber(), StageCodes.FAILED.toString())).thenReturn(suryodaySweepTxnDetails);
		paymentServiceImplHelper.sweepInHelper(res, suryodaySweepTxnDetails);
	}

	@Test
	public void getCustomerProfiletest() {
		try {
		paymentServiceImplHelper.getCustomerProfile("17521521", "21712821", "RAPP","17521521");
		}catch(Exception e) {

		}
	}

	@Test
	public void getAccountsDetailsTest() {
		try {
			List<AccountResponse> accountList= new LinkedList<AccountResponse>();
			AccountResponse accountResponse=new AccountResponse();
			accountResponse.setAccountNumber("17521521");
			accountResponse.setStatus("REGULAR");
			accountList.add(accountResponse);
			paymentServiceImplHelper.getAccountsDetails(new Customer(), accountList,"17521521");
		}catch(Exception e) {

		}
	}

	@Test
	public void sweepOutFinalAuditTest() {

		SuryodaySweepTxnDetails suryodaySweepTxnDetails =new SuryodaySweepTxnDetails();
		Response response = new Response();
		TransactionStatus transactionStatus = new TransactionStatus();
		transactionStatus.setErrorCode("0");
		response.setTransactionStatus(transactionStatus);
		suryodaySweepTxnDetails.setFlow("TOKENMONEY");
		AddonAccount addonAccount =new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543321");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		BigDecimal val2 = new BigDecimal("62567878.9768");
		suryodaySweepTxnDetails.setAmount(val2);
		suryodaySweepTxnDetails.setSuryodayBln("123");
		suryodaySweepTxnDetails.setApbTxnId("abc");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		Mockito.when(dbAuditingHelper.updateSuryodaySuccessSweepOut(suryodaySweepTxnDetails,response)).thenReturn(suryodaySweepTxnDetails);
		paymentServiceImplHelper.sweepOutFinalAudit(response, suryodaySweepTxnDetails);
	}

	@Test
	public void sweepOutFinalAuditTest1() {

		SuryodaySweepTxnDetails suryodaySweepTxnDetails =new SuryodaySweepTxnDetails();
		Response response = new Response();
		TransactionStatus transactionStatus = new TransactionStatus();
		transactionStatus.setErrorCode("1");
		response.setTransactionStatus(transactionStatus);
		suryodaySweepTxnDetails.setFlow("TOKENMONEY");
		AddonAccount addonAccount =new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543321");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		BigDecimal val2 = new BigDecimal("62567878.9768");
		suryodaySweepTxnDetails.setAmount(val2);
		suryodaySweepTxnDetails.setSuryodayBln("123");
		suryodaySweepTxnDetails.setApbTxnId("abc");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
	//	Mockito.when(dbAuditingHelper.updateSuryodaySuccessSweepOut(suryodaySweepTxnDetails,response)).thenReturn(suryodaySweepTxnDetails);
		paymentServiceImplHelper.sweepOutFinalAudit(response, suryodaySweepTxnDetails);
	}

	@Test(expected = CustomerValidationException.class)
	public void getCustomerProfileTest() {
		List<String> channelList = new ArrayList<>();
		channelList.add("ABC");
		ReflectionTestUtils.setField(paymentServiceImplHelper, "customerAppChannel", channelList);
		AccountResponse accountResponse = new AccountResponse();
		ResultDTO meta2 = new ResultDTO();
		ResponseDTO<Customer> response = new ResponseDTO<Customer>();
		Balance balance = new Balance();
		Customer customer = new Customer();
		meta2.setCode("000");
		meta2.setStatus(0);
		ArrayList<AccountResponse> accountList = new ArrayList<>();

		accountResponse.setAccountNumber("9876543212");
		AddonAccount addonAccount =new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543212");
		accountResponse.setStatus("REGULAR");
		accountResponse.setBalance(balance);
		accountList.add(accountResponse);
		customer.setAccountList(accountList);
		customer.setCustomerType("abc");
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		//customer.setAccountList(Arrays.asList(accountResponse));
		response.setData(customer);
		response.setMeta(meta2);
		ResponseEntity<?> responseEntity = new ResponseEntity<>(
				response,
			    header,
			    HttpStatus.OK
			);
		  Mockito.doReturn(responseEntity).when(httpUtil).sendHttpRequest(Mockito.any());
		  Mockito.when(messageSource.getMessage(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn("abc");
		paymentServiceImplHelper.getCustomerProfile("abc","abc","ABC","9876543212");


	}
}
