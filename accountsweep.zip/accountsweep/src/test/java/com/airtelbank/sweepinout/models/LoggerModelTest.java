package com.airtelbank.sweepinout.models;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class LoggerModelTest {
	@Test
	public void loggerModel() {
		LoggerModel loggerModel = new LoggerModel();
		loggerModel.setAmount("");
		loggerModel.setApiId("");
		loggerModel.setContentId("");
		loggerModel.setCustMobileNo("");
		loggerModel.setDate1(new Date());
		loggerModel.setDate2(new Date());
		loggerModel.setId1("");
		loggerModel.setId10("");
		loggerModel.setId2("");
		loggerModel.setId3("");
		loggerModel.setId4("");
		loggerModel.setId5("");
		loggerModel.setId6("");
		loggerModel.setId7("");
		loggerModel.setId8("");
		loggerModel.setId9("");
		loggerModel.setNumber1(0L);
		loggerModel.setNumber2(0L);
		loggerModel.setNumber3(0L);
		loggerModel.setRequestData("");
		loggerModel.setResponseCode("");
		loggerModel.setResponseData("");
		loggerModel.setServiceId("");
		loggerModel.setTotalTime(new Date());
		loggerModel.setTranId("");
	}
}


	