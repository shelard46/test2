package com.airtelbank.sweepinout.config;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.config.log.SweepInOutThreadLocal;
import com.airtelbank.sweepinout.config.log.KibanaErrorLogger.LOGGING_TYPE;
import com.airtelbank.sweepinout.models.LoggerModel;

@RunWith(MockitoJUnitRunner.class)
public class KibanaErrorLoggerTest {
	
	@InjectMocks
	KibanaErrorLogger kibanaErrorLogger;
	
	@Mock
	MessageSource messageSource;
	
	@Test
	public void addErrorTest() throws IOException {
		LoggerModel loggerModel = new LoggerModel();
		SweepInOutThreadLocal.setValue(loggerModel);
		kibanaErrorLogger.addError(LOGGING_TYPE.UPPER_LIMIT_BREACH);
	}
	
	@Test
	public void addErrorDefaultTest() throws IOException {
		LoggerModel loggerModel = new LoggerModel();
		SweepInOutThreadLocal.setValue(loggerModel);
		kibanaErrorLogger.addError(LOGGING_TYPE.DEF);
	}
}