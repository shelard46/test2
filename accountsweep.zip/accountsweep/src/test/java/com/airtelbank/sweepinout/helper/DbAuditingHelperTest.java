package com.airtelbank.sweepinout.helper;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.AccountBalanceRepository;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.InvalidCustomerException;
import com.airtelbank.sweepinout.exception.InvalidRequestException;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Before;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;

@RunWith(MockitoJUnitRunner.class)
public class DbAuditingHelperTest {

	@InjectMocks
	private DbAuditingHelper dbAuditingHelper;

	@Mock
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	@Mock
	private AddonAccountRepository addonAccountRepository;

	@Mock
	private AccountBalanceRepository accountBalanceRepository;

	@Mock
	private KibanaErrorLogger kibanaLogger;

	@Mock
	private Environment env;

	@Test
	public void tokenMoneySweepOutDbAuditingTest() {
		SweepInOutTokenMoneyRequest sweepInOutTokenMoneyRequest=new SweepInOutTokenMoneyRequest();
		sweepInOutTokenMoneyRequest.setAmount(1.00);
		dbAuditingHelper.tokenMoneySweepOutDbAuditing(sweepInOutTokenMoneyRequest, "1234");
	}

	@Test
	public void internalFundTransferDbAuditingTest() {
		dbAuditingHelper.internalFundTransferDbAuditing(new SuryodaySweepTxnDetails());
	}

	@Test
	public void SuryodayFundTransferBeforDbAuditingTest() {
		dbAuditingHelper.SuryodayFundTransferBeforDbAuditing(new SuryodaySweepTxnDetails());
	}

	@Test
	public void internalFundTransferSuccessTest() {
		dbAuditingHelper.internalFundTransferSuccess(new SuryodaySweepTxnDetails(),"133761");
	}

	@Test
	public void finalSuccessAuditTest() {
		dbAuditingHelper.finalSuccessAudit(new SuryodaySweepTxnDetails(),"133761");
	}

	@Test
	public void internalFundTransferFailureTest() {
		dbAuditingHelper.internalFundTransferFailure(new SuryodaySweepTxnDetails(),"13126215","133761");
	}

	@Test
	public void suryodayFundTransferFailureTest() {
		dbAuditingHelper.suryodayFundTransferFailure(new SuryodaySweepTxnDetails(),"133761");
	}

	@Test
	public void sweepOutSuryodayFTTest() {
		AutoSwpAmtXferLog autoSwpAmtXferLog=new AutoSwpAmtXferLog();
		Before before=new Before();
		before.setCodAcctNo("122712178");
		before.setAmtAutoSwp("1.00");
		before.setDatAutoSwp("12-09-2020");
		before.setFlgCustTyp("abc");
		autoSwpAmtXferLog.setBefore(before);
		autoSwpAmtXferLog.setAfter(before);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.anyString())).thenReturn(new AddonAccount());
		when(env.getProperty(Mockito.anyString())).thenReturn("dd-MM-YYYY");
		dbAuditingHelper.sweepOutSuryodayFT(autoSwpAmtXferLog,"133761");
	}

	@Test
	public void sweepOutSuryodayFTTest1() {
		AutoSwpAmtXferLog autoSwpAmtXferLog=new AutoSwpAmtXferLog();
		SuryodaySweepTxnDetails suryodayTranc= new SuryodaySweepTxnDetails();
		Before before=new Before();
		suryodayTranc.setAccountNumber("123");
		before.setCodAcctNo("122712178");
		before.setAmtAutoSwp("1.00");
		before.setDatAutoSwp("12-09-2020");
		before.setFlgCustTyp("abc");
		autoSwpAmtXferLog.setBefore(before);
		autoSwpAmtXferLog.setAfter(before);
		//	when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.anyString())).thenReturn(suryodayTranc);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.anyString())).thenReturn(new AddonAccount());
		when(env.getProperty(Mockito.anyString())).thenReturn("dd-MM-YYYY");
		dbAuditingHelper.sweepOutSuryodayFT(autoSwpAmtXferLog,"133761");
	}
	@Test(expected = NullPointerException.class)
	public void sweepOutSuryodayFTTest2() {
		AutoSwpAmtXferLog autoSwpAmtXferLog=new AutoSwpAmtXferLog();
		SuryodaySweepTxnDetails suryodayTranc= new SuryodaySweepTxnDetails();
		Before before=new Before();
		suryodayTranc.setAccountNumber("123");
		before.setCodAcctNo("122712178");
		before.setAmtAutoSwp("1.00");
		before.setDatAutoSwp("12-09-2020");
		before.setFlgCustTyp(null);
		autoSwpAmtXferLog.setBefore(before);
		autoSwpAmtXferLog.setAfter(before);
		dbAuditingHelper.sweepOutSuryodayFT(autoSwpAmtXferLog,"133761");
	}


	@Test
	public void preAuditingSweepInTest() {
		SweepInAccountRequest sweepInAccountRequest=new SweepInAccountRequest();
		sweepInAccountRequest.setAmount("200.00");
		when(addonAccountRepository.findByCustomerNatalId(Mockito.any())).thenReturn(new AddonAccount());
		dbAuditingHelper.preAuditingSweepIn(sweepInAccountRequest);
	}

	@Test
	public void updateSuryodaySweepInStatusTest() {
		dbAuditingHelper.updateSuryodaySweepInStatus(new SuryodaySweepTxnDetails(),"133761","SUCCESS");
	}

	@Test
	public void updateSuryodayRetryStatusTest() {
		dbAuditingHelper.updateSuryodayRetryStatus(new SuryodaySweepTxnDetails());
	}

	@Test
	public void updateInternalPayRetryStatusTest() {
		dbAuditingHelper.updateInternalPayRetryStatus(new SuryodaySweepTxnDetails());
	}

	@Test
	public void updateSuryodaySuccessSweepOutTest() {
		Response response=new Response();
		response.setTransactionRefNumber("18218712");
		dbAuditingHelper.updateSuryodaySuccessSweepOut(new SuryodaySweepTxnDetails(),response);
	}

	@Test
	public void updateFtRefrenceNumberTest() {
		dbAuditingHelper.updateFtRefrenceNumber(new SuryodaySweepTxnDetails(),"175217");
	}

	@Test
	public void updateAPBStatusTest() {
		dbAuditingHelper.updateAPBStatus(new SuryodaySweepTxnDetails(),"SUCCESS");
	}

	@Test
	public void internalFundTransferFailureForReconTest() {
		dbAuditingHelper.internalFundTransferFailureForRecon(new SuryodaySweepTxnDetails(),"7126712");
	}

	@Test
	public void suryodayFundTransferFailureForReconTest() {
		dbAuditingHelper.suryodayFundTransferFailureForRecon(new SuryodaySweepTxnDetails());
	}

	@Test
	public void updateSurodayAccountBlanceTest() {
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountNumber("9876543210");
		addonAccount.setCustomerId("12567");
		addonAccount.setCustomerNatalId("345678");
		details.setAccountNumber("9876543210");
		BigDecimal amount = new BigDecimal("62567878.9768");
		details.setAmount(amount);
		details.setAddonAccount(addonAccount);
		details.setTransactionType("Dr");
		AccountBalance accountBlance = new AccountBalance();
		accountBlance.setBalanceAmount(null);
		BigDecimal balanceAmount = new BigDecimal("62567878.9768");
		accountBlance.setPreviousBalance(balanceAmount);
		accountBlance.setPreviousBalance(balanceAmount);
		//	when(accountBalanceRepository.findByAddonAccount(Mockito.any())).thenReturn(accountBlance);
		dbAuditingHelper.updateSurodayAccountBlance(details);
	}

	@Test
	public void updateSurodayAccountBlanceTest1() {
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountNumber("9876543210");
		addonAccount.setCustomerId("12567");
		addonAccount.setCustomerNatalId("345678");
		details.setAccountNumber("9876543210");
		BigDecimal amount = new BigDecimal("62567878.9768");
		details.setAmount(amount);
		details.setAddonAccount(addonAccount);
		details.setTransactionType("Dr");
		AccountBalance accountBlance = new AccountBalance();
		accountBlance.setBalanceAmount(null);
		BigDecimal balanceAmount = new BigDecimal("62567878.9768");
		accountBlance.setPreviousBalance(balanceAmount);
		accountBlance.setPreviousBalance(balanceAmount);
		when(accountBalanceRepository.findByAddonAccount(Mockito.any())).thenReturn(accountBlance);
		dbAuditingHelper.updateSurodayAccountBlance(details);
	}

	@Test(expected = GenericException.class)
	public void updateSurodayAccountBlanceTest2() {
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountNumber("9876543210");
		addonAccount.setCustomerId("12567");
		addonAccount.setCustomerNatalId("345678");
		details.setAccountNumber("9876543210");
		BigDecimal amount = new BigDecimal("62567878.9768");
		details.setAmount(amount);
		details.setAddonAccount(addonAccount);
		details.setTransactionType("Cr");
		AccountBalance accountBlance = new AccountBalance();
		accountBlance.setBalanceAmount(null);
		BigDecimal balanceAmount = new BigDecimal("62567878.9768");
		accountBlance.setPreviousBalance(balanceAmount);
		accountBlance.setPreviousBalance(balanceAmount);
		when(accountBalanceRepository.findByAddonAccount(Mockito.any())).thenReturn(accountBlance);
		dbAuditingHelper.updateSurodayAccountBlance(details);
	}

	@Test(expected = InvalidCustomerException.class)
	public void SuccessAuditingReconSweepInTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepInReconRequest sweepInReconRequest = new SweepInReconRequest();
		sweepInReconRequest.setStatus("SUCCESS");
		sweepInReconRequest.setAirtelTransactionId("1234565");
		dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,suryodaySweepTxnDetails);

	}
	@Test
	public void SuccessAuditingReconSweepInTest1() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepInReconRequest sweepInReconRequest = new SweepInReconRequest();
		sweepInReconRequest.setCustomerAccountNo("1235");
		sweepInReconRequest.setStatus("FAIL");
		sweepInReconRequest.setAirtelTransactionId(null);
		AddonAccount addonAccount = new AddonAccount();
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,suryodaySweepTxnDetails);

	}

	@Test
	public void SuccessAuditingReconSweepInTest2() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepInReconRequest sweepInReconRequest = new SweepInReconRequest();
		sweepInReconRequest.setCustomerAccountNo("1235");
		sweepInReconRequest.setStatus("FAIL");
		sweepInReconRequest.setAirtelTransactionId("1234");
		AddonAccount addonAccount = new AddonAccount();
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,suryodaySweepTxnDetails);
	}


}
