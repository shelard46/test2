package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class PartnerTextMessageAndEnableRetryTest {
	@Test
	public void partnerTextMessageAndEnableRetryTest() {
		PartnerTextMessageAndEnableRetry partnerTextMessageAndEnableRetry = new PartnerTextMessageAndEnableRetry();
		partnerTextMessageAndEnableRetry.setEnableRetry(false);
		partnerTextMessageAndEnableRetry.setTextMessage("");
	}

}
