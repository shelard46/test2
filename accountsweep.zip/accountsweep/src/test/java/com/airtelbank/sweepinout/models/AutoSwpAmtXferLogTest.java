package com.airtelbank.sweepinout.models;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dto.ResponseDTO;


@RunWith(SpringRunner.class)
public class AutoSwpAmtXferLogTest {	
	
	@Test
	public void testSweepInOutRequest() {
		
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		Before before = new Before();
		before.setAmtAutoSwp("");
		before.setCodAcctNo("");
		before.setCodCustId("");
		before.setCodAcctNo("");
		autoSwpAmtXferLog.setAfter(before);
		autoSwpAmtXferLog.setCurrentts("");
		autoSwpAmtXferLog.setOptype("");
		autoSwpAmtXferLog.setPos("");
		autoSwpAmtXferLog.getTable();
	}
}
