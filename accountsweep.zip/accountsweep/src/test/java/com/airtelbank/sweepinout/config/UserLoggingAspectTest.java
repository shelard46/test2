package com.airtelbank.sweepinout.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.JoinPoint.StaticPart;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.SourceLocation;
import org.aspectj.runtime.internal.AroundClosure;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.airtelbank.sweepinout.config.log.UserLoggingAspect;
import com.airtelbank.sweepinout.service.impl.SweepInOutServiceImpl;
import com.airtelbank.sweepinout.utils.CommonUtil;

@RunWith(MockitoJUnitRunner.class)
public class UserLoggingAspectTest {
	
	@InjectMocks
	private UserLoggingAspect userLoggingAspect;

	@Test
	public void aroundServiceTest() throws Throwable {
		ProceedingJoinPoint joinPoint=new ProceedingJoinPoint() {
			
			@Override
			public String toShortString() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public String toLongString() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object getThis() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object getTarget() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public StaticPart getStaticPart() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public SourceLocation getSourceLocation() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Signature getSignature() {
				Signature methodSignature = new Signature() {
					
					@Override
					public String toShortString() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public String toLongString() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public String getName() {
						return "customerProfile";
					}
					
					@Override
					public int getModifiers() {
						// TODO Auto-generated method stub
						return 0;
					}
					
					@Override
					public String getDeclaringTypeName() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public Class getDeclaringType() {
						return SweepInOutServiceImpl.class;
					}
				};
				return methodSignature;
			}
			
			@Override
			public String getKind() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object[] getArgs() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public void set$AroundClosure(AroundClosure arc) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public Object proceed(Object[] args) throws Throwable {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object proceed() throws Throwable {
				// TODO Auto-generated method stub
				return null;
			}
		};
		userLoggingAspect.aroundService(joinPoint);
		userLoggingAspect.aroundController(joinPoint);
		userLoggingAspect.aroundUtils(joinPoint);
		userLoggingAspect.aroundHelper(joinPoint);
		userLoggingAspect.aroundDao(joinPoint);
		userLoggingAspect.aroundException(joinPoint);
	}
	
	@Test
	public void test() {
		userLoggingAspect.serviceExecution();
		userLoggingAspect.utilsExecution();
		userLoggingAspect.helperExecution();
		userLoggingAspect.controllerExecution();
		userLoggingAspect.daoExecution();
		userLoggingAspect.exceptionExecution();
	}
	
}
