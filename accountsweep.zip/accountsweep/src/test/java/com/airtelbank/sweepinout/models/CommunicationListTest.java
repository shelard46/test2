package com.airtelbank.sweepinout.models;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CommunicationListTest {
	@Test
	public void data() {
		CommunicationList communicationList = new CommunicationList();
		communicationList.setAdditionalProperty("", "");
		communicationList.setApplicationCode("");
		communicationList.setApplicationKey("");
		communicationList.setAttachment("");
		communicationList.setBlackOutEndTime("");
		communicationList.setBlackOutStartTime("");
		communicationList.setCategory("");
		communicationList.setContent("");
		communicationList.setCustomClassName("");
		communicationList.setDeliveryReportRequired(false);
		communicationList.setEndDate("");
		communicationList.setExternalRefNo("");
		communicationList.setFrequency("");
		communicationList.setIndex(0);
		communicationList.setLangId("");
		communicationList.setMaskingRegex("");
		communicationList.setMaskingRequired(false);
		communicationList.setMax("");
		communicationList.setMaxRetryCount(0);
		communicationList.setMode("");
		communicationList.setRef1("");
		communicationList.setRef2("");
		communicationList.setRef4("");
		communicationList.setRef4("");
		assertEquals("",communicationList.getAdditionalProperties().get(""));
		assertEquals("",communicationList.getApplicationCode());
		assertEquals("",communicationList.getApplicationKey());
		assertEquals("",communicationList.getAttachment());
		assertEquals("",communicationList.getBlackOutEndTime());
		assertEquals("",communicationList.getBlackOutStartTime());
		assertEquals("",communicationList.getCategory());
		assertEquals("",communicationList.getContent());
		assertEquals("",communicationList.getCustomClassName());
		assertEquals(false,communicationList.getDeliveryReportRequired());
		assertEquals("",communicationList.getEndDate());
		assertEquals("",communicationList.getExternalRefNo());
		assertEquals("",communicationList.getFrequency());
		assertEquals("",communicationList.getLangId());
		assertEquals("",communicationList.getMaskingRegex());
		assertEquals(false,communicationList.getMaskingRequired());
		assertEquals("",communicationList.getMax());
		assertEquals("",communicationList.getMode());
		assertEquals("",communicationList.getRef1());
		assertEquals("",communicationList.getRef2());
		assertEquals("",communicationList.getRef4());
		assertEquals("",communicationList.getRef4());

	}
}
