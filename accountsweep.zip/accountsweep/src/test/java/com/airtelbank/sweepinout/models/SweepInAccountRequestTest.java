package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SweepInAccountRequestTest {
	@Test
	public void sweepInAccountRequest() {
		
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
        sweepInAccountRequest.setAccountNo("9811001033");
        sweepInAccountRequest.setAmount("1");
        sweepInAccountRequest.setChannel("RAPP");
        sweepInAccountRequest.setNarration("");
        sweepInAccountRequest.setPaymentRefId("FE1238994456509");
        sweepInAccountRequest.setPurposeCode("test");
        sweepInAccountRequest.setRetailerNo("");
        sweepInAccountRequest.setSourceId("test");
		
	}

}
