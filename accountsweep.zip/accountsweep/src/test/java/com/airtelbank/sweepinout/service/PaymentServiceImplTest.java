package com.airtelbank.sweepinout.service;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.http.protocol.HTTP;
import org.jasypt.commons.CommonUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.Constants;
import com.airtelbank.sweepinout.utils.GenericRedisProducer;
import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.ApplicationException;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.SweepInOutException;
import com.airtelbank.sweepinout.filter.ContentTypeTextToTextPlain;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.helper.ValidationHelper;
import com.airtelbank.sweepinout.models.AdditionalDetails;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Before;
import com.airtelbank.sweepinout.models.Data;
import com.airtelbank.sweepinout.models.DiffParams;
import com.airtelbank.sweepinout.models.FromActorDetails;
import com.airtelbank.sweepinout.models.FtResponse;
import com.airtelbank.sweepinout.models.FundTransferRequest;
import com.airtelbank.sweepinout.models.FundTransferRetryRequest;
import com.airtelbank.sweepinout.models.Input;
import com.airtelbank.sweepinout.models.InputForEnquiry;
import com.airtelbank.sweepinout.models.Meta;
import com.airtelbank.sweepinout.models.SessionContext;
import com.airtelbank.sweepinout.models.SupervisorContext;
import com.airtelbank.sweepinout.models.SurodayFundTransferRequest;
import com.airtelbank.sweepinout.models.SweepInResponseDto;
import com.airtelbank.sweepinout.models.ToActorDetails;
import com.airtelbank.sweepinout.service.impl.PaymentServiceImpl;
import com.airtelbank.sweepinout.service.impl.PaymentServiceImplHelper;
import com.airtelbank.sweepinout.utils.HttpUtils;
import com.airtelbank.sweepinout.utils.KafkaProducer;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.airtelbank.sweepinout.utils.StageCodes;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sun.javafx.font.Metrics;

@RunWith(MockitoJUnitRunner.class)
public class PaymentServiceImplTest {
	public static MockedStatic<CommonUtil> mockedSettings;
	public static MockedStatic<GenericRedisProducer> mockedredis;
	@InjectMocks
	PaymentServiceImpl paymentServiceImpl;

	@Mock
	private HttpUtils httpUtils;

	@Mock
	private DbAuditingHelper dbAuditingHelper;

	@Mock
	private Environment env;

	@Mock
	private KafkaProducer kafkaProducer;

	@Mock
	private ValidationHelper validationHelper;

	@Mock
	private SmsUtil smsUtil;

	@Mock
	private PaymentServiceImplHelper paymentServiceImplHelper;

	@Mock
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	@Mock
	private KibanaErrorLogger kibanaLogger;

	@Mock
	private SweepInOutService sweepInOutService;

	@Autowired
	private Gson gson;

	@Mock
	private FtResponse ftRes;

	@BeforeClass
	public static void init() {

		// mockedSettings = mockStatic(CommonUtil.class);
		mockedredis = mockStatic(GenericRedisProducer.class);
	}

	@Test
	public void updateRecordAfterPaymentTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAddonAccount(new AddonAccount());
		paymentServiceImpl.updateRecordAfterPayment("{\"meta\":{\"status\":\"0\"},\"data\":{\"ftTxnId\":\"133261\"}}",
				suryodaySweepTxnDetails);
	}

	@Test
	public void updateRecordAfterPaymentTest2() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAddonAccount(new AddonAccount());
		paymentServiceImpl.updateRecordAfterPayment("{\"meta\":{\"status\":\"1\"},\"data\":{\"ftTxnId\":\"133261\"}}",
				suryodaySweepTxnDetails);
	}

	@Test
	public void updateRecordAfterPaymentTest3() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAddonAccount(new AddonAccount());
		paymentServiceImpl.updateRecordAfterPayment("{\"meta\":{\"status\":\"0\"},\"data\":{\"ftTxnId\":\"133261\"}}",
				suryodaySweepTxnDetails);
	}

	@Test
	public void internalFundTransferTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();

		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		FundTransferRetryRequest fundTransferRetryRequest = new FundTransferRetryRequest();
		DiffParams diffParams = new DiffParams();
		FromActorDetails fromActorDetails = new FromActorDetails();
		ToActorDetails toActorDetails = new ToActorDetails();
		AdditionalDetails additionalDetails = new AdditionalDetails();
		AddonAccount addonAccount = new AddonAccount();
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		suryodaySweepTxnDetails.setRefrenceNumber("12345");
		addonAccount.setAirtelAcountNumber("9876543210");
		BigDecimal val2 = new BigDecimal("62567878.9768");
		fundTransferRequest.setAmount(val2);
		fundTransferRequest.setChannel("RAPP");
		diffParams.setDiffParam1("123");
		fromActorDetails.setAccountNo(addonAccount.getAirtelAcountNumber());
		fundTransferRequest.setLatitude("0");
		fundTransferRequest.setLongitude("0");
		fundTransferRequest.setPaymentMode("11");
		fundTransferRequest.setPaymentRefId("abc");
		fundTransferRequest.setPurposeCode(env.getProperty("ft.purposeCode"));
		fundTransferRequest.setSourceId(env.getProperty("ft.sourceId.out"));
		fundTransferRequest.setSourceIpAdd(env.getProperty("ft.sourceIpAdd"));
//		when(this.env.getProperty("MyProp", Integer.class)).thenReturn(123);
		Mockito.doReturn(123).when(env).getProperty(Mockito.any(), (Class<Object>) Mockito.any());
		Mockito.doReturn("abc").when(env).getProperty(Mockito.any());
		GenericRedisProducer.addEntryToZadd("abc", "abc", 123);
		paymentServiceImpl.internalFundTransfer(suryodaySweepTxnDetails);

	}

	@Test(expected = GenericException.class)
	public void internalFundTransferSweepInTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepInResponseDto sweepInResponseDto = new SweepInResponseDto();
		sweepInResponseDto.setAmount("123");
		sweepInResponseDto.setTxnDateTime("123");
		BigDecimal val2 = new BigDecimal("62567878.9768");
		suryodaySweepTxnDetails.setAmount(val2);
		suryodaySweepTxnDetails.setChannel("RAPP");
		suryodaySweepTxnDetails.setRefrenceNumber("123");
		suryodaySweepTxnDetails.setChannel("RAPP");
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543321");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		DiffParams diffParams = new DiffParams();
		FromActorDetails fromActorDetails = new FromActorDetails();
		ToActorDetails toActorDetails = new ToActorDetails();
		AdditionalDetails additionalDetails = new AdditionalDetails();
		fundTransferRequest.setAmount(suryodaySweepTxnDetails.getAmount());
		fundTransferRequest.setChannel(suryodaySweepTxnDetails.getChannel());
		diffParams.setDiffParam1("");
		fromActorDetails.setAccountNo(env.getProperty("ft.accNo"));
		fundTransferRequest.setLatitude("0");
		fundTransferRequest.setLongitude("0");
		fundTransferRequest.setPaymentMode("Abc");
		fundTransferRequest.setPaymentRefId(suryodaySweepTxnDetails.getRefrenceNumber());
		fundTransferRequest.setPurposeCode(env.getProperty("ft.purposeCde"));
		fundTransferRequest.setSourceId(env.getProperty("ft.sourceId"));
		fundTransferRequest.setSourceIpAdd(env.getProperty("ft.sourceIpAdd"));
		toActorDetails.setAccountNo(suryodaySweepTxnDetails.getAddonAccount().getAirtelAcountNumber());
		toActorDetails.setAccountType("CUS");
		fundTransferRequest.setTxnCode(env.getProperty("ft.txnCode"));
		additionalDetails.setSms("");
		fundTransferRequest.setDiffParams(diffParams);
		fundTransferRequest.setFromActorDetails(fromActorDetails);
		fundTransferRequest.setToActorDetails(toActorDetails);
		fundTransferRequest.setAdditionalDetails(additionalDetails);
//		when(this.env.getProperty("MyProp", Integer.class)).thenReturn(123);
		Mockito.doReturn(123).when(env).getProperty(Mockito.any(), (Class<Object>) Mockito.any());
		Mockito.doReturn("abc").when(env).getProperty(Mockito.any());

		paymentServiceImpl.internalFundTransferSweepIn(suryodaySweepTxnDetails);
	}

	@Test(expected = SweepInOutException.class)
	public void suryodayFundTransferTest() {

		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setCurrentStatus("ABC");
		suryodaySweepTxnDetails.setSuryodayStatus("ABC");
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setRefrenceNumber("1234");
		suryodaySweepTxnDetails.setValueDate(Calendar.getInstance());
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543321");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		AccountBalance accountBlance = new AccountBalance();
		Mockito.doReturn(123).when(env).getProperty(Mockito.any(), (Class<Object>) Mockito.any());
		Mockito.doReturn("abc").when(env).getProperty(Mockito.any());
		SurodayFundTransferRequest surodayFundTransferRequest = new SurodayFundTransferRequest();
		Input input = new Input();
		SessionContext sessionContext = new SessionContext();
		SupervisorContext supervisorContext = new SupervisorContext();
		supervisorContext.setPrimaryPassword(env.getProperty("suryoday.primaryPassword"));
		supervisorContext.setUserId(env.getProperty("suryoday.userId"));
		sessionContext.setSupervisorContext(supervisorContext);
		sessionContext.setChannel("ABC");
		sessionContext.setExternalReferenceNo("ABC");
		input.setSessionContext(sessionContext);
		input.setLoggedInUserId(env.getProperty("suryoday.loggedInUserId"));
		input.setOperation("mfCollectionOrReversal");
		input.setRefNoCumFlag("ABC");
		input.setTransactionData1("ABC");
		input.setTransactionData2("ABC");

		input.setValueDate("ABC");
		surodayFundTransferRequest.setInput(input);

		paymentServiceImpl.suryodayFundTransfer(suryodaySweepTxnDetails);
	}

	@Test
	public void refundAfterSweepInFailTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setRefrenceNumber("1324");
		suryodaySweepTxnDetails.setFlow(StageCodes.SWEEPINREFUND.toString());
		suryodaySweepTxnDetails.setTransactionType(Constants.TRANSACTION_DR);
		suryodaySweepTxnDetails.setChannel("RAPP");
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAirtelAcountNumber("9876543321");
		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
		BigDecimal val2 = new BigDecimal("62567878.9768");
		suryodaySweepTxnDetails.setAmount(val2);
		suryodaySweepTxnDetails.setCreatedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setModifiedOn(Calendar.getInstance());
		suryodaySweepTxnDetails.setValueDate(Calendar.getInstance());
		suryodaySweepTxnDetails.setSuryodayStatus("abc");
		paymentServiceImpl.refundAfterSweepInFail(suryodaySweepTxnDetails);
	}

	@Test
	public void removeFromRetryTest() {

		paymentServiceImpl.removeFromRetry("123", "123", "123");
	}

	@Test
	public void apbIFTRedisPaymentTest() {
		FundTransferRetryRequest consumerModel = new FundTransferRetryRequest();
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAccountNumber("1234567890");
		Optional<SuryodaySweepTxnDetails> details = Optional.of(suryodaySweepTxnDetails);
		consumerModel.setSuryodayTxnId(0);
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		consumerModel.setFundTransferRequest(fundTransferRequest);
		when(suryodaySweepTxnDetailsRepository.findById(Mockito.any())).thenReturn(details);
		// when(paymentServiceImpl.internalFundTransferEnquery(Mockito.any(),Mockito.any())).thenReturn("abc");

		paymentServiceImpl.apbIFTRedisPayment(consumerModel);

	}

	@Test(expected = Exception.class)
	public void suryodayIFTRetryTest() {
		InputForEnquiry consumerModel = new InputForEnquiry();
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAccountNumber("1234567890");
		Optional<SuryodaySweepTxnDetails> details = Optional.of(suryodaySweepTxnDetails);
		consumerModel.setSuryodayTxnId(0);
		FundTransferRequest fundTransferRequest = new FundTransferRequest();
		// consumerModel.setFundTransferRequest(fundTransferRequest);
		// when(suryodaySweepTxnDetailsRepository.findById(Mockito.any())).thenReturn(details);
		// when(paymentServiceImpl.internalFundTransferEnquery(Mockito.any(),Mockito.any())).thenReturn("abc");
		paymentServiceImpl.suroydayEnqueryForSweepInRetry(consumerModel, details.get());
		// Mockito.doReturn(123).when(env).getProperty(Mockito.any(), (Class<Integer>)
		// Mockito.any());
		// when(this.env.getProperty("MyProp", Integer.class)).thenReturn(123);

		paymentServiceImpl.suryodayIFTRetry(consumerModel);
	}

	//	@Test
	//	public void updateForFullSuccessTest() {
	//		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
	//		FtResponse ff = new FtResponse();
	//		Meta meta = new Meta();
	//		Data data = new Data();
	//		meta.setStatus("0");
	//		meta.setCode("123");
	//		meta.setDescription("as");
	//		meta.setStatus("234");
	//		data.setFtTxnId("12345");
	//		data.setBalAfterTxn("123");
	//		data.setCharges("123");
	//		data.setFtTxnId("123");
	//		data.setHoldBalance("123");
	//		data.setMessage("123");
	//		ff.setData(data);
	//		ff.setMeta(meta);
	//		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
	//		autoSwpAmtXferLog.setPos("1234");
	//		AddonAccount addonAccount = new AddonAccount();
	//		addonAccount.setCustomerId("987654321");
	//		addonAccount.setAccountNumber("876543");
	//		addonAccount.setAirtelAcountNumber("1234567");
	//		suryodaySweepTxnDetails.setAddonAccount(addonAccount);
	//		Before after = new Before();
	//		after.setAmtAutoSwp("12345");
	//		after.setCodAcctNo("12345");
	//		after.setCodCustId("12345");
	//		after.setCodAcctNo("12345");
	//		when(env.getProperty(Mockito.anyString())).thenReturn("yyyy-MM-dd HH:mm:ss");
	//		autoSwpAmtXferLog.setAfter(after);
	//		dbAuditingHelper.internalFundTransferSuccess(suryodaySweepTxnDetails, "12345");
	//		paymentServiceImpl.sendDataForSweepout(suryodaySweepTxnDetails);
	//		when(gson.fromJson(Mockito.anyString(),eq(FtResponse.class))).thenReturn(ff);
	//	//	  Mockito.doReturn(ff).when(gson).fromJson(Mockito.anyString(),Mockito.any());
	//		paymentServiceImpl.updateForFullSuccess("23456", suryodaySweepTxnDetails);
	//	}

}
