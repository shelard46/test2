package com.airtelbank.sweepinout.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.airtelbank.sweepinout.dto.ResponseDTO;
import com.airtelbank.sweepinout.dto.ResultDTO;
import com.airtelbank.sweepinout.models.Data;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.airtelbank.sweepinout.service.PaymentService;
import com.airtelbank.sweepinout.service.SweepInOutService;
import com.airtelbank.sweepinout.service.impl.SweepInOutServiceImpl;
import com.airtelbank.sweepinout.utils.KafkaProducer;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@WebMvcTest(value = SweepInOutController.class)
public class SweepInOutControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Mock
	private SweepInOutService sweepInOutService;

	@Mock
	private PaymentService paymentService;

	@Mock
	private KafkaProducer kafkaProducer;

	@Mock
	private Environment env;

	@Mock
	private SweepInOutServiceImpl sweepInOutServiceImpl;

	@InjectMocks
	private SweepInOutController sweepInOutController;

	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(sweepInOutController).build();
	}

	public static <T> Answer<T> createAnswer(final T value) {
		Answer<T> dummy = new Answer<T>() {
			@Override
			public T answer(InvocationOnMock invocation) throws Throwable {
				return value;
			}
		};
		return dummy;
	}

	@Test
	public void testSweepInRequest() throws Exception {

		SweepInAccountRequest sweepInAccountRequest = getSweepInAccountRequest();
		SweepInAccountRequest sweepInCurrAccountRequest =getSweepInAccountRequestForCurr();

		ResponseDTO<?> response = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
		Data data = new Data();
		meta.setCode("000");
		meta.setDescription("SUCCESS");
		meta.setStatus(0);
		data.setAvailableBalance("");
		data.setBalAfterTxn("");
		data.setCharges("");
		data.setHoldBalance("");
		data.setFtTxnId("FT1914212127661");
		response.setMeta(meta);
		Mockito.when(sweepInOutService.sweepInRequest(Mockito.any())).thenAnswer(createAnswer(response));
		mockMvc.perform(post("/v1/extraccount/transfer/sweepIn")
				.content(new ObjectMapper().writeValueAsString(sweepInAccountRequest))
				.header("Content-Type", "application/json")).andExpect(status().isOk());

		mockMvc.perform(post("/v1/extraccount/transfer/sweepIn")
				.content(new ObjectMapper().writeValueAsString(sweepInCurrAccountRequest))
				.header("Content-Type", "application/json")).andExpect(status().isOk());
	}

	@Test
	public void testSweepInRequestException() throws Exception {

		SweepInAccountRequest sweepInAccountRequest = getSweepInAccountRequest();
		SweepInAccountRequest sweepInCurrAccountRequest =getSweepInAccountRequestForCurr();

		mockMvc.perform(post("/v1/extraccount/transfer/sweepIn")
				.content(new ObjectMapper().writeValueAsString(sweepInAccountRequest))
				.header("Content-Type", "application/json")).andExpect(status().is5xxServerError());

		mockMvc.perform(post("/v1/extraccount/transfer/sweepIn")
				.content(new ObjectMapper().writeValueAsString(sweepInCurrAccountRequest))
				.header("Content-Type", "application/json")).andExpect(status().is5xxServerError());
	}

	@Test
	public void testSweepOutRequest() throws Exception {
		SweepInAccountRequest req = getSweepInAccountRequest();
		mockMvc.perform(post("/v1/extraccount/transfer/sweepOut").content(new ObjectMapper().writeValueAsString(req))
				.contentType("application/json").accept("application/json")).andExpect(status().isOk());
	}

	@Test
	public void tokenMoneyTest() throws Exception {
		SweepInAccountRequest req = getSweepInAccountRequest();
		mockMvc.perform(post("/v1/extraccount/transfer/tokenMoney").content(new ObjectMapper().writeValueAsString(req))
				.contentType("application/json").accept("application/json")).andExpect(status().isOk());
	}



	private SweepInAccountRequest getSweepInAccountRequest() {
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
		sweepInAccountRequest.setAccountNo("9811001033");
		sweepInAccountRequest.setAmount("1");
		sweepInAccountRequest.setChannel("RAPP");
		sweepInAccountRequest.setNarration("");
		sweepInAccountRequest.setPaymentRefId("FE1238994456509");
		sweepInAccountRequest.setPurposeCode("test");
		sweepInAccountRequest.setRetailerNo("");
		sweepInAccountRequest.setSourceId("test");
		return sweepInAccountRequest;
	}

	private SweepInAccountRequest getSweepInAccountRequestForCurr() {
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
		sweepInAccountRequest.setAccountNo("9803995175");
		sweepInAccountRequest.setAmount("1");
		sweepInAccountRequest.setChannel("RAPP");
		sweepInAccountRequest.setNarration("");
		sweepInAccountRequest.setPaymentRefId("FE1238994456510");
		sweepInAccountRequest.setPurposeCode("test");
		sweepInAccountRequest.setRetailerNo("");
		sweepInAccountRequest.setSourceId("test");
		return sweepInAccountRequest;
	}
	private SweepInReconRequest getSweepInReconRequest() {
		SweepInReconRequest sweepInAccountRecon = new SweepInReconRequest();
		sweepInAccountRecon.setAirtelTransactionId("9811001033");
		sweepInAccountRecon.setAmount("1");
		sweepInAccountRecon.setCustomerAccountNo("RAPP");
		sweepInAccountRecon.setRefrenceNo("123456");
		sweepInAccountRecon.setStatus("FE1238994456509");

		return sweepInAccountRecon;
	}

	private ReconRequest getReconRequest() {
		ReconRequest reconRequest = new ReconRequest();
		reconRequest.setAirtelTransactionId("9811001033");
		reconRequest.setAmount("1");
		reconRequest.setCustomerAccountNo("RAPP");
		reconRequest.setRefrenceNo("123456");
		reconRequest.setStatus("FE1238994456509");

		return reconRequest;
	}


	@Test
	public void testSweepInRequest2() throws Exception {

		SweepInReconRequest sweepInReconRequest = getSweepInReconRequest();

		ResponseDTO<?> response = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
		Data data = new Data();
		meta.setCode("000");
		meta.setDescription("SUCCESS");
		meta.setStatus(1);
		data.setAvailableBalance("");
		data.setBalAfterTxn("");
		data.setCharges("");
		data.setHoldBalance("");
		data.setFtTxnId("FT1914212127661");
		response.setMeta(meta);
		Mockito.when(sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest)).thenAnswer(createAnswer(response));
		mockMvc.perform(post("/v1/extraccount/transfer/recon/sweepIn/")
				.content(new ObjectMapper().writeValueAsString(sweepInReconRequest))
				.header("Content-Type", "application/json")).andExpect(status().isInternalServerError());
	}

	@Test
	public void testSweepInRequest1() throws Exception {

		ReconRequest reconRequest = getReconRequest();

		ResponseDTO<?> response = new ResponseDTO<>();
		ResultDTO meta = new ResultDTO();
		Data data = new Data();
		meta.setCode("000");
		meta.setDescription("SUCCESS");
		meta.setStatus(1);
		data.setAvailableBalance("");
		data.setBalAfterTxn("");
		data.setCharges("");
		data.setHoldBalance("");
		data.setFtTxnId("FT1914212127661");
		response.setMeta(meta);
		Mockito.when(sweepInOutServiceImpl.reconSweepInRequest(reconRequest)).thenAnswer(createAnswer(response));
		mockMvc.perform(post("/v1/extraccount/transfer/recon/sweepIn/")
				.content(new ObjectMapper().writeValueAsString(reconRequest))
				.header("Content-Type", "application/json")).andExpect(status().isInternalServerError());
	}
}