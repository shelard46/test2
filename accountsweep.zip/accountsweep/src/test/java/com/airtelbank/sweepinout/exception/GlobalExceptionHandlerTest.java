package com.airtelbank.sweepinout.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.sweepinout.dto.ResultDTO;


@RunWith(MockitoJUnitRunner.class)
public class GlobalExceptionHandlerTest {
	
	@InjectMocks
	private GlobalExceptionHandler globalExceptionHandler;

	@Mock
	private MessageSource messageSource;
	
	@Test
	public void handleUpperLimitExceptionTest() {
		ReflectionTestUtils.setField(globalExceptionHandler, "upperSweepInLimit", "90000");
		UpperLimitBreachException upperLimitBreachException=new UpperLimitBreachException();
		upperLimitBreachException.setMeta(new ResultDTO());
		upperLimitBreachException.setErrorCode("100");
		upperLimitBreachException.setErrorMessage("UpperLimitBreachException");
		globalExceptionHandler.handleUpperLimitException(new UpperLimitBreachException("100","UpperLimitBreachException"));
	}
	
	@Test
	public void handleCustomerValidationExceptionTest() {
		globalExceptionHandler.handleCustomerValidationException(new CustomerValidationException("100","CustomerValidationException"));
	}

}
