package com.airtelbank.sweepinout.models;

import java.util.LinkedList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CustomerTest {
	@Test
	public void customer() {
		Customer customer=new Customer();
		customer.setAccountList(new LinkedList<>());
		customer.setCustomerType("SBA");
		customer.toString();
		Customer customer1=new Customer(new LinkedList<>(),"SBA");
	}
}
