package com.airtelbank.sweepinout.service;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.DuplicateDataException;
import com.airtelbank.sweepinout.exception.UpperLimitBreachException;
import com.airtelbank.sweepinout.helper.DbAuditingHelper;
import com.airtelbank.sweepinout.helper.ValidationHelper;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.ReconRequest;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.models.SweepInReconRequest;
import com.airtelbank.sweepinout.service.impl.PaymentServiceImplHelper;
import com.airtelbank.sweepinout.service.impl.SweepInOutServiceImpl;
import com.airtelbank.sweepinout.utils.KafkaProducer;
import com.airtelbank.sweepinout.utils.SmsUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

@RunWith(MockitoJUnitRunner.class)
public class SweepInOutServiceImplTest {

	@InjectMocks
	SweepInOutServiceImpl sweepInOutServiceImpl;

	@Mock
	private KibanaErrorLogger kibanaLogger;

	@Mock
	private DbAuditingHelper dbAuditingHelper;

	@Mock
	private PaymentService paymentService;

	@Mock
	private PaymentServiceImplHelper paymentServiceImplHelper;

	@Mock
	private ValidationHelper validationHelper;

	@Mock
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	@Mock
	private AddonAccountRepository addonAccountRepository;

	@Mock
	private SmsUtil smsUtil;

	@Mock
	private KafkaProducer kafkaProducer;

	@Mock
	private Environment env;

	@Test
	public void sweepInRequestTest() {
		ReflectionTestUtils.setField(sweepInOutServiceImpl, "upperSweepInLimit", 90000);
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
		sweepInAccountRequest.setAmount("300");
		sweepInAccountRequest.setAccountNo("87654456");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(validationHelper.checkForRecordDublicationRefrence(Mockito.any())).thenReturn(true);
		when(validationHelper.checkForBlanceCustomer(Mockito.anyString(),Mockito.anyString())).thenReturn(accountDetails);
		when(dbAuditingHelper.preAuditingSweepIn(Mockito.any())).thenReturn(details);
		sweepInOutServiceImpl.sweepInRequest(sweepInAccountRequest);
	}

	@Test(expected = DuplicateDataException.class)
	public void sweepInRequestExceptionTest() {
		ReflectionTestUtils.setField(sweepInOutServiceImpl, "upperSweepInLimit", 90000);
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
		sweepInAccountRequest.setAmount("300");
		sweepInAccountRequest.setAccountNo("87654456");
		sweepInOutServiceImpl.sweepInRequest(sweepInAccountRequest);
	}

	@Test
	public void reconSweepInRequestTest() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}

	@Test
	public void reconSweepInRequestTestCheck() throws JsonProcessingException {
		SweepInReconRequest sweepInReconRequest = new SweepInReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}

	@Test
	public void reconSweepInRequestTest1() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPIN");
		sweepInReconRequest.setSuryodayStatus("SUCCESS");
		sweepInReconRequest.setApbStatus("FAIL");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}
	@Test
	public void reconSweepInRequestTest2() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPIN");
		sweepInReconRequest.setSuryodayStatus("FAIL");
		sweepInReconRequest.setApbStatus("SUCCESS");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}

	@Test
	public void reconSweepInRequestTokenTest1() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("TOKENMONEY");
		sweepInReconRequest.setSuryodayStatus("SUCCESS");
		sweepInReconRequest.setApbStatus("FAIL");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");

		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}
	@Test
	public void reconSweepInRequestTokenTest2() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("TOKENMONEY");
		sweepInReconRequest.setSuryodayStatus("FAIL");
		sweepInReconRequest.setApbStatus("SUCCESS");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");

		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}

	@Test
	public void reconSweepInRequestSweepTest1() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPOUT");
		sweepInReconRequest.setSuryodayStatus("SUCCESS");
		sweepInReconRequest.setApbStatus("FAIL");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}
	@Test
	public void reconSweepInRequestSweepTest2() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPOUT");
		sweepInReconRequest.setSuryodayStatus("FAIL");
		sweepInReconRequest.setApbStatus("SUCCESS");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}

	@Test
	public void reconSweepInRequestFundTest1() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPINREFUND");
		sweepInReconRequest.setSuryodayStatus("FAIL");
		sweepInReconRequest.setApbStatus("SUCCESS");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}
	@Test
	public void reconSweepInRequestFundTest2() throws JsonProcessingException {
		ReconRequest sweepInReconRequest = new ReconRequest();
		sweepInReconRequest.setAirtelTransactionId("765434567");
		sweepInReconRequest.setAmount("300");
		sweepInReconRequest.setCustomerAccountNo("96456789");
		sweepInReconRequest.setFlowName("SWEEPINREFUND");
		sweepInReconRequest.setSuryodayStatus("FAIL");
		sweepInReconRequest.setApbStatus("SUCCESS");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		details.setValueDate(Calendar.getInstance());
		AddonAccount accountDetails = new AddonAccount();
		accountDetails.setAirtelAcountNumber("765432345");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(accountDetails);
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(details);
		Mockito.when(dbAuditingHelper.SuccessAuditingReconSweepIn(sweepInReconRequest,details)).thenReturn(details);
		sweepInOutServiceImpl.reconSweepInRequest(sweepInReconRequest);
	}



	@Test(expected= UpperLimitBreachException.class)
	public void sweepInRequestUpperLimitTest() {
		ReflectionTestUtils.setField(sweepInOutServiceImpl, "upperSweepInLimit", 90000);
		SweepInAccountRequest sweepInAccountRequest = new SweepInAccountRequest();
		sweepInAccountRequest.setAmount("100000");
		sweepInAccountRequest.setAccountNo("87654456");
		SuryodaySweepTxnDetails details = new SuryodaySweepTxnDetails();
		BigDecimal a = new BigDecimal("3000.00");
		details.setAmount(a);
		details.setApbTxnId("7643456");
		details.setCreatedOn(Calendar.getInstance());
		sweepInOutServiceImpl.sweepInRequest(sweepInAccountRequest);
	}

	@Test
	public void tokenMoneyDebitTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepInOutTokenMoneyRequest sweepInOutTokenMoneyRequest=new SweepInOutTokenMoneyRequest();
		Mockito.when(dbAuditingHelper.tokenMoneySweepOutDbAuditing(Mockito.any(),Mockito.any())).thenReturn(suryodaySweepTxnDetails);
		paymentService.internalFundTransfer(suryodaySweepTxnDetails);
		sweepInOutServiceImpl.tokenMoneyDebit(sweepInOutTokenMoneyRequest);

	}

	@Test
	public void sweepOutSuroydayFTTest() {

		AutoSwpAmtXferLog autoSwpAmtXferLog=new AutoSwpAmtXferLog();
		sweepInOutServiceImpl.sweepOutSuroydayFT(autoSwpAmtXferLog);

	}

}
