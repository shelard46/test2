package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SupervisorContextTest {
	@Test
	public void supervisorContext() {
		SupervisorContext supervisorContext = new SupervisorContext();
		supervisorContext.setPrimaryPassword("");
		supervisorContext.setUserId("");
		
	}

}
