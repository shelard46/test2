package com.airtelbank.sweepinout.models;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ExceptionTest {
	@Test
	public void meta() {
		Exception ex = new Exception();
		Reason reason = new Reason();
		reason.setCode("");
		reason.setMessage("");
		ex.setErrorMessage("");
		ex.setErrorCode("");
		ex.setReason(reason);
		ex.setResponse("");
		ex.setStackTrace("");
		assertEquals("",ex.getErrorMessage());
		assertEquals("",ex.getErrorMessage());
		assertEquals("",ex.getReason().getCode());
		assertEquals("",ex.getReason().getCode());
		assertEquals("",ex.getResponse());
	}
}

