package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class DataTest {
	@Test
	public void data() {
		Data data = new Data();
		data.setAvailableBalance("");
    	data.setBalAfterTxn("");
    	data.setCharges("");
    	data.setHoldBalance("");
    	data.setFtTxnId("FT1914212127661");
		 
	}
}

