package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dao.entities.AccountProvider;

@RunWith(SpringRunner.class)
public class TransactionStatusTest {
	
	@Test
	public void transactionStatus() {
	
	 TransactionStatus transactionStatus = new TransactionStatus();
	 transactionStatus.setErrorCode("");
	 transactionStatus.setExternalReferenceNo("");
	 transactionStatus.setReplyCode("");
	 transactionStatus.setReplyText("");
}
}
