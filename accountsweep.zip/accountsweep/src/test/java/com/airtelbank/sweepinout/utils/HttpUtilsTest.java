package com.airtelbank.sweepinout.utils;


import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.http.protocol.HTTP;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.airtelbank.sweepinout.exception.ApplicationException;
import com.airtelbank.sweepinout.filter.ContentTypeTextToTextPlain;
import com.airtelbank.sweepinout.models.Customer;
import com.airtelbank.sweepinout.models.RestRequest;
import com.airtelbank.sweepinout.models.SweepInAccountRequest;
import com.airtelbank.sweepinout.models.SweepInResponseDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
public class HttpUtilsTest {
	
	
	@InjectMocks
	HttpUtils httpUtils;	
	
	@Mock
	private RestTemplate restTemplate;

	@Mock
	private RestTemplate proxyRestTemplate;
	
	@Mock
	private ObjectMapper objectMapper;
		
	@Test
	public void hitRequestTest() throws Exception {
		Map<String, String> headers = new HashMap<>();
		headers.put("contentId", "12345");
		headers.put("channel", "RAPP");
		HttpHeaders httpHeaders = new HttpHeaders();
		if (headers != null && !headers.isEmpty()) {
			httpHeaders = new HttpHeaders();
			Set<String> headerKeySet = headers.keySet();
			for (String key : headerKeySet) {
				httpHeaders.add(key, headers.get(key));
			}
		}
		ResponseEntity<?> response=new ResponseEntity("123456",HttpStatus.OK);
		HttpEntity<?> entity= new HttpEntity<>("12345667", httpHeaders);
		when(proxyRestTemplate.exchange("10.56.110.191", HttpMethod.POST,entity,String.class)).thenReturn((ResponseEntity<String>) response);
		httpUtils.hitRequest("10.56.110.191", "12345667",String.class, headers, HttpMethod.POST, true);
	}
	
	@Test
	public void invokePostURLTest() throws JsonProcessingException {
		httpUtils.invokePostURL("10.56.110.191", new SendSMS());
	}
	
	@Test
	public void sendHttpRequestTest() throws JsonProcessingException {
		MultiValueMap<String, String> headers = new HttpHeaders();
		headers.add(Constants.CONTENTID, "123467");
		headers.add(Constants.CHANNEL, "RAPP");

		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
		queryParams.add("accounts", String.valueOf(true));

		Map<String, Object> params = new HashMap<>();
		params.put("customerId", "123456");
		RestRequest<Customer> request = RequestCreationUtil.createRestRequest("http://10.56.110.191/api/v1", HttpMethod.GET,
				null, Customer.class, params, headers, queryParams);
		httpUtils.sendHttpRequest(request);
	}
}
