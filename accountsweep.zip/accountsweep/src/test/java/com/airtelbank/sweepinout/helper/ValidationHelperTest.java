package com.airtelbank.sweepinout.helper;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.record.TimestampType;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dao.AccountBalanceRepository;
import com.airtelbank.sweepinout.dao.AddonAccountRepository;
import com.airtelbank.sweepinout.dao.SuryodaySweepTxnDetailsRepository;
import com.airtelbank.sweepinout.dao.entities.AccountBalance;
import com.airtelbank.sweepinout.dao.entities.AddonAccount;
import com.airtelbank.sweepinout.dao.entities.SuryodaySweepTxnDetails;
import com.airtelbank.sweepinout.exception.GenericException;
import com.airtelbank.sweepinout.exception.LowBlanceException;
import com.airtelbank.sweepinout.exception.SuryodayIFTException;
import com.airtelbank.sweepinout.exception.SweepInOutException;
import com.airtelbank.sweepinout.models.AutoSwpAmtXferLog;
import com.airtelbank.sweepinout.models.Before;
import com.airtelbank.sweepinout.models.Response;
import com.airtelbank.sweepinout.models.SweepInOutTokenMoneyRequest;
import com.airtelbank.sweepinout.utils.CommonUtil;
import com.airtelbank.sweepinout.utils.GenericRedisProducer;
import com.airtelbank.sweepinout.utils.StageCodes;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
public class ValidationHelperTest {
	public static MockedStatic<CommonUtil> mockedSettings;
	@Mock
	private SuryodaySweepTxnDetailsRepository suryodaySweepTxnDetailsRepository;

	@Mock
	private AddonAccountRepository addonAccountRepository;

	@Mock
	private AccountBalanceRepository accountBalanceRepository;

	@InjectMocks
	ValidationHelper validationHelper;

	@Mock
	private Environment env;

	@Mock
	private DbAuditingHelper dbAuditingHelper;

	@Mock
	private StageCodes stageCodes;

	@BeforeClass
	public static void init() {

		mockedSettings = mockStatic(CommonUtil.class);

	}

	@Test
	public void duplicateRecordCheckTrueTest() {
		SweepInOutTokenMoneyRequest req = new SweepInOutTokenMoneyRequest();
		req.setCustomerSyordayaAccount("9876543456");
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountCIFNumber("765432345");
		addonAccount.setAccountNumber("987654566");
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(addonAccount);
		Boolean res = validationHelper.duplicateRecordCheck(req);
		assertEquals(true, res);
	}

	@Test
	public void duplicateRecordCheckFalseTest() {
		SweepInOutTokenMoneyRequest req = new SweepInOutTokenMoneyRequest();
		req.setCustomerSyordayaAccount("9876543456");
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountCIFNumber("765432345");
		addonAccount.setAccountNumber("987654566");
		SuryodaySweepTxnDetails sweepTxnDetails = new SuryodaySweepTxnDetails();
		sweepTxnDetails.setAccountNumber("98765456");
		List<SuryodaySweepTxnDetails> detailsList = new ArrayList<>();
		detailsList.add(sweepTxnDetails);
		when(addonAccountRepository.findByAccountNumber(Mockito.any())).thenReturn(addonAccount);
		when(suryodaySweepTxnDetailsRepository.findByAddonAccount(Mockito.any())).thenReturn(detailsList);
		Boolean res = validationHelper.duplicateRecordCheck(req);
		assertEquals(false, res);
	}

	@Test  (expected = LowBlanceException.class)
	public void checkForBlanceCustomerTest() {
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountCIFNumber("765432345");
		addonAccount.setAccountNumber("987654566");
		AccountBalance accountBalance = new AccountBalance();
		accountBalance.setAccountNumber("987654566");
		accountBalance.setBalanceAmount(BigDecimal.valueOf(100));
		when(addonAccountRepository.findByCustomerNatalId(Mockito.anyString())).thenReturn(addonAccount);
		when(accountBalanceRepository.findByAddonAccount(Mockito.any())).thenReturn(accountBalance);
		BigDecimal amnt = new BigDecimal("1000");
		mockedSettings.when(() -> CommonUtil.roundOff(Mockito.any())).thenReturn(amnt);
		validationHelper.checkForBlanceCustomer("123456", "900");
	}

	@Test(expected = SweepInOutException.class)
	public void checkForBlanceCustomerTest1() {
		AddonAccount addonAccount = new AddonAccount();
		addonAccount.setAccountCIFNumber("765432345");
		addonAccount.setAccountNumber("987654566");
		AccountBalance accountBalance = new AccountBalance();
		accountBalance.setAccountNumber("987654566");
		accountBalance.setBalanceAmount(BigDecimal.valueOf(1000));
		when(addonAccountRepository.findByCustomerNatalId(Mockito.anyString())).thenReturn(addonAccount);
		when(accountBalanceRepository.findByAddonAccount(Mockito.any())).thenReturn(null);
		BigDecimal amnt = new BigDecimal("100");
		mockedSettings.when(() -> CommonUtil.roundOff(Mockito.any())).thenReturn(amnt);
		validationHelper.checkForBlanceCustomer("123456", "900");
	}

	@Test
	public <T> void printTopicMetaTest() {
		ConsumerRecord<String, T> payLoad = new ConsumerRecord<String, T>("test", 1, 100, 1000,
				TimestampType.NO_TIMESTAMP_TYPE, 1000, 1000, 1000, "test", (T) "test");
		validationHelper.printTopicMeta(payLoad);
	}

	@Test
	public void duplicateRecordCheckTest() {

		AddonAccount addonAccount = new AddonAccount();
		SuryodaySweepTxnDetails SweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepTxnDetails.setAccountNumber("1134");
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = new ArrayList<>();
		suryodaySweepTxnDetails.add(SweepTxnDetails);
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos("abc");
		SweepTxnDetails.setFlow("TOKENMONEY");
		SweepTxnDetails.setApbStatus("SUCCESSFUL");
		SweepTxnDetails.setSuryodayStatus("TO_BE_INITIATED");
		when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.any())).thenReturn(SweepTxnDetails);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		Boolean res = validationHelper.duplicateRecordCheck(autoSwpAmtXferLog);
		assertEquals(false, res);
	}

	@Test
	public void duplicateRecordCheckTest1() {

		AddonAccount addonAccount = new AddonAccount();
		SuryodaySweepTxnDetails SweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepTxnDetails.setAccountNumber("1134");
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = new ArrayList<>();
		suryodaySweepTxnDetails.add(SweepTxnDetails);
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos("abc");
		SweepTxnDetails.setFlow("TOKENMONEY");
		SweepTxnDetails.setApbStatus("SUCCESSFUL");
		SweepTxnDetails.setSuryodayStatus("TO_BE_INITIATED");
		Before after = new Before();
		after.setDatAutoSwp("2022-12-11 12:22:33");
		after.setCodAcctNo("234567");
		autoSwpAmtXferLog.setAfter(after);
		mockedSettings.when(() -> CommonUtil.StringToDate(Mockito.anyString(),Mockito.anyString())).thenReturn(new Date());

		when(env.getProperty(Mockito.anyString())).thenReturn("yyyy-MM-dd HH:mm:ss");
		when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.any())).thenReturn(SweepTxnDetails);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		Boolean res = validationHelper.duplicateRecordCheck(autoSwpAmtXferLog);
		assertEquals(true, res);
	}

	@Test
	public void duplicateRecordCheckTest2() {

		AddonAccount addonAccount = new AddonAccount();
		SuryodaySweepTxnDetails SweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepTxnDetails.setAccountNumber("1134");
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = new ArrayList<>();
		suryodaySweepTxnDetails.add(SweepTxnDetails);
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos("abc");
		SweepTxnDetails.setFlow("TOKENMONEY");
		SweepTxnDetails.setApbStatus("SUCCESSFUL");
		SweepTxnDetails.setSuryodayStatus("TO_BE_INITIATED");
		Before after = new Before();
		after.setDatAutoSwp("2022-12-11 12:22:33");
		after.setCodAcctNo("234567");
		autoSwpAmtXferLog.setBefore(after);
		mockedSettings.when(() -> CommonUtil.StringToDate(Mockito.anyString(),Mockito.anyString())).thenReturn(new Date());

		when(env.getProperty(Mockito.anyString())).thenReturn("yyyy-MM-dd HH:mm:ss");
		when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.any())).thenReturn(SweepTxnDetails);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		Boolean res = validationHelper.duplicateRecordCheck(autoSwpAmtXferLog);
		assertEquals(true, res);
	}

	@Test
	public void duplicateRecordCheckTest3() {

		AddonAccount addonAccount = new AddonAccount();
		SuryodaySweepTxnDetails SweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepTxnDetails.setAccountNumber("1134");
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = new ArrayList<>();
		suryodaySweepTxnDetails.add(SweepTxnDetails);
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos("abc");
		SweepTxnDetails.setFlow("TOKENMONEY");
		SweepTxnDetails.setApbStatus("SUCCESSFUL");
		SweepTxnDetails.setSuryodayStatus("TO_BE_INITIATED");
		Before after = new Before();
		after.setDatAutoSwp("2022-12-11 12:22:33");
		after.setCodAcctNo("234567");
		autoSwpAmtXferLog.setBefore(after);
		mockedSettings.when(() -> CommonUtil.StringToDate(Mockito.anyString(),Mockito.anyString())).thenReturn(new Date());

		when(env.getProperty(Mockito.anyString())).thenReturn("yyyy-MM-dd HH:mm:ss");
		when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.any())).thenReturn(SweepTxnDetails);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		when(suryodaySweepTxnDetailsRepository.findByAddonAccountAndFlowAndValueDate(Mockito.any(),Mockito.anyString(),Mockito.any())).thenReturn(null);
		Boolean res = validationHelper.duplicateRecordCheck(autoSwpAmtXferLog);
		assertEquals(true, res);
	}

	@Test
	public void duplicateRecordCheckTest4() {

		AddonAccount addonAccount = new AddonAccount();
		SuryodaySweepTxnDetails SweepTxnDetails = new SuryodaySweepTxnDetails();
		SweepTxnDetails.setAccountNumber("1134");
		List<SuryodaySweepTxnDetails> suryodaySweepTxnDetails = new ArrayList<>();
		suryodaySweepTxnDetails.add(SweepTxnDetails);
		AutoSwpAmtXferLog autoSwpAmtXferLog = new AutoSwpAmtXferLog();
		autoSwpAmtXferLog.setPos("abc");
		SweepTxnDetails.setFlow("TOKENMONEY");
		SweepTxnDetails.setApbStatus("SUCCESSFUL");
		SweepTxnDetails.setSuryodayStatus("TO_BE_INITIATED");
		Before after = new Before();
		after.setDatAutoSwp("2022-12-11 12:22:33");
		after.setCodAcctNo("234567");
		autoSwpAmtXferLog.setBefore(after);
		mockedSettings.when(() -> CommonUtil.StringToDate(Mockito.anyString(),Mockito.anyString())).thenReturn(new Date());

		when(env.getProperty(Mockito.anyString())).thenReturn("yyyy-MM-dd HH:mm:ss");
		when(suryodaySweepTxnDetailsRepository.findByApbTxnId(Mockito.any())).thenReturn(SweepTxnDetails);
		when(addonAccountRepository.findByAirtelAcountNumber(Mockito.any())).thenReturn(addonAccount);
		when(suryodaySweepTxnDetailsRepository.findByAddonAccountAndFlowAndValueDate(Mockito.any(),Mockito.anyString(),Mockito.any())).thenReturn(SweepTxnDetails);
		Boolean res = validationHelper.duplicateRecordCheck(autoSwpAmtXferLog);
		assertEquals(false, res);
	}

	@Test
	public void checkForRecordDublicationRefrenceTest() {
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		suryodaySweepTxnDetails.setAccountNumber("12345678");
		suryodaySweepTxnDetails.setRefrenceNumber("456");
		when(suryodaySweepTxnDetailsRepository.findByRefrenceNumber(Mockito.any())).thenReturn(suryodaySweepTxnDetails);
		Boolean res = validationHelper.checkForRecordDublicationRefrence("test");
		assertEquals(false, res);
	}

	@Test
	public void suryodayFTValidationTest() {
		SuryodayIFTException ex = new SuryodayIFTException();
		ex.setErrorCode("1515");
		mockedSettings.when(() -> CommonUtil.convertToObjectFromXMLInJAXB(Mockito.any(), Mockito.any())).thenReturn(ex);
		validationHelper.suryodayFTValidation("test");
	}

	@Test
	public void suryodayFTValidationTest1() {
		SuryodayIFTException ex = new SuryodayIFTException();
		ex.setErrorCode("1515");
		mockedSettings.when(() -> CommonUtil.convertToObjectFromXMLInJAXB(Mockito.any(), Mockito.any()))
		.thenReturn(null);
		validationHelper.suryodayFTValidation("test");
	}

	@Test(expected = GenericException.class)
	public void sweepinSuryodayIFTValidationErrorTest() {
		SuryodayIFTException ex = new SuryodayIFTException();
		SuryodaySweepTxnDetails suryodaySweepTxnDetails = new SuryodaySweepTxnDetails();
		Response res = new Response();
		ex.setErrorCode("1515");
		mockedSettings.when(() -> CommonUtil.convertToObjectFromXMLInJAXB(Mockito.any(), Mockito.any()))
		.thenReturn(ex);
		validationHelper.sweepinSuryodayIFTValidationError("abc", suryodaySweepTxnDetails, true);
	}

}
