package com.airtelbank.sweepinout.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.dao.entities.AddonAccountType;

@RunWith(SpringRunner.class)
public class AddonAccountTypeTest {
	
	@Test
	public void addonAccountType() {
		
		 AddonAccountType addonAccountType = new AddonAccountType();
		 addonAccountType.setCode("");
		 addonAccountType.setId(0L);
		 addonAccountType.setName("");

	}

}
