package com.airtelbank.sweepinout.models;

import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SweepInOutTokenMoneyRequestTest {
	@Test
	public void sweepInOutTokenMoneyRequest() {
		SweepInOutTokenMoneyRequest sweepInOutTokenMoneyRequest = new SweepInOutTokenMoneyRequest();
		sweepInOutTokenMoneyRequest.setAmount(0.0);
		sweepInOutTokenMoneyRequest.setCodCustNatlNo("");
		sweepInOutTokenMoneyRequest.setCustomerSyordayaAccount("");
		sweepInOutTokenMoneyRequest.setRefrenceNumber("");
		sweepInOutTokenMoneyRequest.setValueDate(Calendar.getInstance());
	}
}