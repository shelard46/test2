package com.airtelbank.sweepinout.models;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FtEnquiryResponseTest {
	@Test
	public void ftEnquiryResponse() {
		FtEnquiryResponse ftEnquiryResponse = new FtEnquiryResponse();
		ftEnquiryResponse.setAmount(new BigDecimal(0));
		ftEnquiryResponse.setAvailableBalance(new BigDecimal(0));
		ftEnquiryResponse.setBalAfterTxn(new BigDecimal(0));
		ftEnquiryResponse.setChannel("");
		ftEnquiryResponse.setCharges(new BigDecimal(0));
		ftEnquiryResponse.setFtTxnId("");
		ftEnquiryResponse.setHoldBalance(new BigDecimal(0));
		ftEnquiryResponse.setPurposeCode("");
		ftEnquiryResponse.setSourceId("");
		ftEnquiryResponse.setTxnCode("");
		ftEnquiryResponse.setTxnDateTime(new Date());
		
	}

}	
	