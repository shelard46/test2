package com.airtelbank.sweepinout.helper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.MessageSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.airtelbank.sweepinout.config.log.KibanaErrorLogger;
import com.airtelbank.sweepinout.exception.SweepInOutException;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
public class ErrorHandlerTest {

	@Mock
	private MessageSource messageSource;

	@Mock
	private KibanaErrorLogger kibanaErrorLogger;

	@InjectMocks
	ErrorHandler errorHandler;

	@Test(expected = SweepInOutException.class)
	public void sweepInOutErrorHandlerTest() {
		errorHandler.sweepInOutErrorHandler("-9949", "");

	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest2743Case() {
		errorHandler.sweepInOutErrorHandler("2743", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest7606Case() {
		errorHandler.sweepInOutErrorHandler("7606", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest7549Case() {
		errorHandler.sweepInOutErrorHandler("7549", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest3103Case() {
		errorHandler.sweepInOutErrorHandler("3103", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest7774Case() {
		errorHandler.sweepInOutErrorHandler("7774", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700511Case() {
		errorHandler.sweepInOutErrorHandler("700511", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700512Case() {
		errorHandler.sweepInOutErrorHandler("700512", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700506Case() {
		errorHandler.sweepInOutErrorHandler("700506", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest3310Case() {
		errorHandler.sweepInOutErrorHandler("3310", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest3308Case() {
		errorHandler.sweepInOutErrorHandler("3308", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest55Case() {
		errorHandler.sweepInOutErrorHandler("55", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTestCase() {
		errorHandler.sweepInOutErrorHandler("", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTestDefaultCase() {
		errorHandler.sweepInOutErrorHandler("1234", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest2858Case() {
		errorHandler.sweepInOutErrorHandler("2858", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest2849Case() {
		errorHandler.sweepInOutErrorHandler("2849", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700530Case() {
		errorHandler.sweepInOutErrorHandler("700530", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700106Case() {
		errorHandler.sweepInOutErrorHandler("700106", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700110Case() {
		errorHandler.sweepInOutErrorHandler("700110", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest700140Case() {
		errorHandler.sweepInOutErrorHandler("700140", "");
	}

	@Test(expected = SweepInOutException.class)
	public void errorHandlerTest3309Case() {
		errorHandler.sweepInOutErrorHandler("3309", "");
	}

}
